var reqPayLoad = context.targetRequest.body.asJSON;
var cartid = context.getVariable("cartId");

context.setVariable('dataType', 'postUpdateCartStatus');

if (reqPayLoad != null)
{
	if (cartid == '1000')
	{
		context.setVariable("objectId", "001");
	}
	else if (cartid == '1300')
	{
		context.setVariable("objectId", "002");
	}
	else if (cartid == '1506')
	{
		context.setVariable("objectId", "005");
	}
	else if (cartid == '1525')
	{
		context.setVariable("objectId", "004");
	}
}
