var zipCode=context.getVariable("request.queryparam.zipCode");

if(zipCode!=null && zipCode=='98006'){  
  		context.setVariable("dataType","phoneNumberEligibilityCheck");
      	context.setVariable("objectId","98006");  
}else if(zipCode!=null && zipCode=='98004'){      
		context.setVariable("dataType","phoneNumberEligibilityCheck");
      	context.setVariable("objectId","98004");
}  