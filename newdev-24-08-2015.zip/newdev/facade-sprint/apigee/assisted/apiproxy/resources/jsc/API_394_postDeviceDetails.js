var reqPayLoad = context.targetRequest.body.asJSON
var customerId = context.getVariable("objectId");
context.setVariable("dataType","postDeviceDetails");
if(customerId != null && customerId == '9876543210')
{
	if(reqPayLoad!=null)
		{
		  if(reqPayLoad.imei=='012345678901231' && reqPayLoad.blockedStatus=='Blocked')
		  {
				context.setVariable("objectId", "001");
		  }
		   else if(reqPayLoad.imei=='012345678901232' && reqPayLoad.blockedStatus=='No blocked found')
		   {
				context.setVariable("objectId", "002");
		  }
		}
}