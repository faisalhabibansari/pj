var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","SaveMemo");

var token = context.getVariable('request.header.token')

if(token=='gx0qdkdds32' || token=='fx00wmdlxw0')
{
context.setVariable("objectId", "001");
}
else
{
context.setVariable("objectId", "000");
}
