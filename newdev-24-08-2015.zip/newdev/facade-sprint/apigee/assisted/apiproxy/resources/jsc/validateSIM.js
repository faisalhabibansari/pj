//var sim = context.getVariable("SIMNumber");
var sim=context.getVariable("request.queryparam.SIMNumber");

context.setVariable("dataType","validateSim");

if(sim != null){
   
  context.setVariable("objectId", sim);
}
//context.setVariable("objectId", "1234567891011121314151");

