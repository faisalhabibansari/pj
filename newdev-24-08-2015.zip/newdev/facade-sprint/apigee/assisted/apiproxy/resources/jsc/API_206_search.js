var type = context.getVariable("request.queryparam.type");
var taxId = context.getVariable("request.queryparam.taxId");
var name = context.getVariable("request.queryparam.name");
var page = context.getVariable("request.queryparam.page");
var offset = context.getVariable("request.queryparam.offset");
var msisdn = context.getVariable("request.queryparam.msisdn");
var email = context.getVariable("request.queryparam.email");
var accountId = context.getVariable("request.queryparam.accountId");
context.setVariable("dataType", "search");

if (type != null)
{
	if (taxId != null)
	{
		context.setVariable("objectId", taxId);
	}
	else if (name != null && page == null && offset == null)
	{
		context.setVariable("objectId", name);
	}
	else if (name != null && page != null && offset != null)
	{
		if (page == 2 && offset == 10)
		{
			context.setVariable("objectId", name);
		}
	}
	else if (msisdn != null)
	{
		context.setVariable("objectId", msisdn);
	}
	else if (email != null && email == 'abc@gmail.com')
	{
		context.setVariable("objectId", "001");
	}
	else if (email != null && email == 'steve.glinert@gmail.com')
	{
		context.setVariable("objectId", "002");
	}

	else if (accountId != null)
	{
		context.setVariable("objectId", accountId);
	}
}
