var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType",'CreateCustomerAndAccount');
if(reqPayLoad!=null){
	if(reqPayLoad.firstName=='Roshan' && reqPayLoad.type=='postpaid')
	{
		context.setVariable("objectId","003");
	}
	else if(reqPayLoad.firstName=='Roshan' && reqPayLoad.type=='prepaid')
	{
		context.setVariable("objectId","004");
	}
	else if(reqPayLoad.firstName=='Roshan')
	{
    context.setVariable("objectId","002");
	}
	else 
	{
		context.setVariable("objectId","001");
    }
}