var request_payload = context.targetRequest.body.asJSON
var diff = request_payload.deviceAssessmentAnswers[0].answer.answerText;
var diff1 = request_payload.deviceAssessmentAnswers[1].answer.answerText;
var diff2 = request_payload.deviceAssessmentAnswers[2].answer.answerText;

context.setVariable("dataType", "saveAssessmentResponse");

if(diff=="Yes" || diff=="NO"){    
      context.setVariable("objectId","102"); 
}else {
  
  if(diff1=="Yes"){
    context.setVariable("objectId","103");
  }
  else {
    if(diff=="YES" && diff1=="NO" && diff2=="YES"){
    context.setVariable("objectId","104");
  }
    else if(diff=="YES" && diff1=="YES" && diff2=="YES"){
    context.setVariable("objectId","101");
    }
  }
}