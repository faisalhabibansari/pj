var reqPayLoad = context.targetRequest.body.asJSON
customerId=reqPayLoad.customerId;
context.setVariable("dataType","CreditCheck");
if(reqPayLoad!=null){
  context.setVariable("objectId", customerId);
}else{
  context.setVariable("objectId", "");
}