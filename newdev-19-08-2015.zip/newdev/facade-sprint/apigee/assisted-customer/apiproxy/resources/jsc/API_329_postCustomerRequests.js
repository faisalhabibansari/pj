var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
var request_payload = '';
if(context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var type = request_payload.type;
context.setVariable("dataType", "postCustomerRequests");
if(type =='adjustment') {
	if(customerId=='425435' && accountId=='123456678')
	{
		context.setVariable("objectId", "adjustment001");
	}
	else if(customerId=='741852' && accountId=='123123789')
	{
		if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='20' && request_payload.sendToSupervisor===false)
		{
			context.setVariable("objectId", "adjustment852001");
		}
		else if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='80' && request_payload.sendToSupervisor===false)
		{
			context.setVariable("objectId", "adjustment852002");
		}
		else if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='60' && request_payload.sendToSupervisor===false && request_payload.hasOwnProperty('supervisorLogin') && request_payload.supervisorLogin.password=='Cartwheel4$')
		{
			context.setVariable("objectId", "adjustment852003");
		}
		else if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='60' && request_payload.sendToSupervisor===true)
		{
			context.setVariable("objectId", "adjustment852004");
		}
		else if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='60' && request_payload.sendToSupervisor===false && request_payload.hasOwnProperty('supervisorLogin') && request_payload.supervisorLogin.password=='Cartwheel4')
		{
			context.setVariable("objectId", "adjustment852005");
		}
		else if(request_payload.hasOwnProperty('adjusted') && request_payload.adjusted.amount=='16' && request_payload.sendToSupervisor===false)
		{
			context.setVariable("objectId", "adjustment852006");
		}
		else
		{
			context.setVariable("objectId", "adjustment002");
		}
	}
	else if(customerId=='963852' && accountId=='123456670')
	{
		context.setVariable("objectId", "adjustment003");
	}
	else if(customerId=='55555' && accountId=='12345667')
	{
		context.setVariable("objectId", "adjustment004");
	}
	else if(customerId=='982564' && accountId=='123457788')
	{
		context.setVariable("objectId", "adjustment005");
	}
	else if(customerId=='1241' && accountId=='123123')
	{
		context.setVariable("objectId", "adjustment006");
	}
	else
	{
	context.setVariable("objectId", "1001");
	}
	
}else if(type =='credit') {
	if(customerId=='425435' && accountId=='123456678')
	{
		context.setVariable("objectId", "credit001");
	}
	else if(customerId=='741852' && accountId=='123123789')
	{
		if(request_payload.amount=='40' && request_payload.sendToSupervisor===false)
		{
			context.setVariable("objectId", "credit852001");	
		}
		else if(request_payload.amount=='80' && request_payload.sendToSupervisor===false)
		{
			context.setVariable("objectId", "credit852002");	
		}
		else if(request_payload.amount=='65' && request_payload.sendToSupervisor===false && request_payload.hasOwnProperty('supervisorLogin') && request_payload.supervisorLogin.password=='Cartwheel4$')
		{
			context.setVariable("objectId", "credit852003");	
		}
		else if(request_payload.amount=='90' && request_payload.sendToSupervisor===true)
		{
			context.setVariable("objectId", "credit852004");	
		}
		else if(request_payload.amount=='65' && request_payload.sendToSupervisor===false && request_payload.hasOwnProperty('supervisorLogin') && request_payload.supervisorLogin.password=='Cartwheel4')
		{
			context.setVariable("objectId", "credit852005");	
		}
		else
		{
			context.setVariable("objectId", "credit002");
		}
	}
	else if(customerId=='963852' && accountId=='123456670')
	{
		context.setVariable("objectId", "credit003");
	}
	else if(customerId=='55555' && accountId=='12345667')
	{
		context.setVariable("objectId", "credit004");
	}
	else if(customerId=='1241' && accountId=='123123')
	{
		context.setVariable("objectId", "credit005");
	}
	else if(customerId=='982564' && accountId=='123457788')
	{
		context.setVariable("objectId", "credit006");
	}
	else
	{
		context.setVariable("objectId", "1002");
	}
	
}else if(type =='Payment Dispute') {
	context.setVariable("objectId", "1003");

}else if(type =='hold collection'|| type =='Misapplied Payment' || type =='Bill Copy') {
	context.setVariable("objectId", "1004");

}
else if(type =='Negative File Request') {
	context.setVariable("objectId", "1005");

}
else if(type =='Fraud Routing') {
	context.setVariable("objectId", "1006");

}
else if(type =='Missing Payment') {
  if(request_payload.paymentMethod=='Debit')
  {
	context.setVariable("objectId", "1008");
  }
  else if(request_payload.paymentMethod=='Credit')
  {
	context.setVariable("objectId", "1009");
  }
  else
  {
	context.setVariable("objectId", "1007");
	}

}