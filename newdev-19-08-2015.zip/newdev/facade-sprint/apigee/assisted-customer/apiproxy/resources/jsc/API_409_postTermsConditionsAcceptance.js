var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType",'postTermsConditionsAcceptance');

if(reqPayLoad!=null)
{
	if(reqPayLoad.reptNTId=='JWalker123')
	{
		context.setVariable("objectId","001");
	}
}