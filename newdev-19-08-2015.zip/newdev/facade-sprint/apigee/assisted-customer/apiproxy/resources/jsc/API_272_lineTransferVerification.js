var request_payload = '';

if(context.getVariable('request.content')!=null && context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var accountNumber = request_payload.accountNumber;

if(accountNumber!= null && accountNumber=='18891'){
    context.setVariable("objectId", "18891"); 
	context.setVariable("dataType","lineTransferVerification");
}
else if (accountNumber!= null && accountNumber=='18892')
{
    context.setVariable("objectId", "18892"); 
	context.setVariable("dataType","lineTransferVerification");
}
else if (accountNumber!= null && accountNumber=='18893')
{
    context.setVariable("objectId", "18893"); 
	context.setVariable("dataType","lineTransferVerification");
} 