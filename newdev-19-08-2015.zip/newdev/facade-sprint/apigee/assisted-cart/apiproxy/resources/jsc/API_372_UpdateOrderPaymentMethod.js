var reqPayLoad = context.targetRequest.body.asJSON
var objectId = context.getVariable("orderId");
context.setVariable("dataType","UpdateOrderPaymentMethod");
if(reqPayLoad!=null && reqPayLoad!=''){
context.setVariable("objectId",objectId);
}
    else{
   context.setVariable("objectId","000");
    }