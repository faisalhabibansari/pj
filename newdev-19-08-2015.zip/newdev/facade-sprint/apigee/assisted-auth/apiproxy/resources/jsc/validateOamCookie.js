// 1. get oam cookie from post body
var oam_auth_cookie_name = context.getVariable('request.formparam.oam_auth_cookie_name');
var oam_auth_cookie_value = context.getVariable('request.formparam.oam_auth_cookie_value');
var protected_resource = context.getVariable('request.formparam.protected_resource');

// normalize protected resource name
if (protected_resource.indexOf("nonprod-172-28-t-2a-rett-eelb-374783017.us-west-2.elb.amazonaws.com") > -1)
{
	protected_resource = "https://nonprod-172-28-t-2a-rett-eelb-374783017.us-west-2.elb.amazonaws.com/index.html";
}

else if (protected_resource.indexOf("retailtechweb.rebellion") > -1)
{
	protected_resource = "https://nonprod-172-28-t-2a-rett-eelb-374783017.us-west-2.elb.amazonaws.com/index.html";
}

else if (protected_resource.indexOf("nonprod-172-28-t-2a-caret-eelb-1882017468.us-west-2.elb.amazonaws.com") > -1)
{
	protected_resource = "https://nonprod-172-28-t-2a-caret-eelb-1882017468.us-west-2.elb.amazonaws.com/index.html";
}

else if (protected_resource.indexOf("caretechweb.rebellion") > -1)
{
	protected_resource = "https://caretechweb.rebellion.t-mobile.com/index.html";
}

context.setVariable('protected_resource', protected_resource);

// build oam cookie for call
var cookie = oam_auth_cookie_name + "=" + oam_auth_cookie_value;

context.setVariable('oam_auth_cookie', cookie);

// ////////see functions in "validateOamCookieLib.js" //////////

// main
requestProtectedResource();
