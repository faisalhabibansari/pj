var type=context.getVariable("request.queryparam.type");
var planId=context.getVariable("request.queryparam.planId");
var serviceId=context.getVariable("request.queryparam.serviceId");
var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
var lineId=context.getVariable("lineId");

context.setVariable("dataType","getProductSuggestions");

if(customerId=='12345' && accountId=='9832723' && lineId=='2234459987'){
    if(type=='service'){
        context.setVariable("objectId", "11111");  
    }else if(type=='plan'){
        context.setVariable("objectId", "22222");  
    }else{
        context.setVariable("objectId", "000");  
    }
}else if(customerId=='12345' && accountId=='9832723' && lineId=='2061234567'){
    if(type=='service'){
        context.setVariable("objectId", "33333");  
    }else if(type=='plan'){
        context.setVariable("objectId", "44444");  
    }else{
        context.setVariable("objectId", "000");  
    }
}else if(customerId=='12345' && accountId=='9876543' && lineId=='4251234567'){
    if(type=='service'){
        context.setVariable("objectId", "55555");  
    }else if(type=='plan'){
        context.setVariable("objectId", "66666");  
    }else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='12345' && accountId=='9832723' && lineId=='2234459001')
    {
        context.setVariable("objectId", "12345");  
    }
else if(customerId=='12345' && accountId=='123123' && lineId=='4251234567'){
    if(type=='service'){
        context.setVariable("objectId", "77777");  
    }else if(type=='plan'){
      context.setVariable("objectId", "88888"); } 
    else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='12345' && accountId=='123123' && lineId=='2234459987'){
    if(type=='service'){
        context.setVariable("objectId", "99999");  
    }else if(type=='plan'){
        context.setVariable("objectId", "999999");  
    }else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='12345' && accountId=='123123' && lineId=='2061231236'){
    if(type=='service'){
        context.setVariable("objectId", "9");  
    }else if(type=='plan'){
        context.setVariable("objectId", "99");  
    }else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='12345' && accountId=='123123' && lineId=='2061231235'){
    if(type=='service'){
        context.setVariable("objectId", "99999999");  
    }else if(type=='plan'){
        context.setVariable("objectId", "999");  
    }else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='12345' && accountId=='123123' && lineId=='2061231237'){
    if(type=='service'){
        context.setVariable("objectId", "1");  
    }else if(type=='plan'){
        context.setVariable("objectId", "2");  
    }else{
        context.setVariable("objectId", "000");
    }  
}
else if(customerId=='1234570' && accountId=='1234123' && lineId=='2234459987'){
    if(type=='service'){
        context.setVariable("objectId", "scenario8service");  
    }else if(type=='plan'){
        context.setVariable("objectId", "scenario7plan");  
    }else{
        context.setVariable("objectId", "000");
    }  
}

else if(customerId=='1234570' && accountId=='1234123' && lineId=='2061231235'){
    if(type=='service'){
        context.setVariable("objectId", "scenario10service");  
    }else if(type=='plan'){
        context.setVariable("objectId", "scenario9plan");  
    }else{
        context.setVariable("objectId", "000");
    }  
}


else if(customerId=='1234570' && accountId=='1234123' && lineId=='2061231236'){
    if(type=='service'){
        context.setVariable("objectId", "scenario12service");  
    }else if(type=='plan'){
        context.setVariable("objectId", "scenario11plan");  
    }else{
        context.setVariable("objectId", "000");
    }  
}

else if(customerId=='1234570' && accountId=='1234123' && lineId=='2061231237'){
    if(type=='plan'){
        context.setVariable("objectId", "scenario13");  
    }else if(type=='service'){
        context.setVariable("objectId", "scenario14");  
    }else{
        context.setVariable("objectId", "000");
    }  
}

else if(customerId=='1234' && accountId=='55555' && lineId=='2234459987'){
     if(type=='service'){
        context.setVariable("objectId", "service55555");  
     }else if(type=='plan'){
       context.setVariable("objectId", "plan55555");}
}

else if(customerId=='1234' && accountId=='55555' && lineId=='2061231235'){
     if(type=='service'){
        context.setVariable("objectId", "service2061231235");  
     }else if(type=='plan'){
       context.setVariable("objectId", "plan2061231235");}
}
else if(customerId=='1234' && accountId=='55555' && lineId=='2061231236'){
     if(type=='service'){
        context.setVariable("objectId", "service2061231236");  
     }else if(type=='plan'){
       context.setVariable("objectId", "plan2061231236");}
}
else if(customerId=='1234' && accountId=='55555' && lineId=='2061231234'){
     if(type=='planGroups'){
       context.setVariable("objectId", "planGroups1234");}
}
else if(customerId=='963852' && accountId=='123456670' && lineId=='4251234568'){
     if(type=='serviceGroups'){
        if(serviceId)
            {   
                context.setVariable("objectId","serviceGroups963852001");
            }
        else
            {
                context.setVariable("objectId", "serviceGroups963852");
            }
          
     }else if(type=='planGroups'){
        if(planId)
            {   
                context.setVariable("objectId","planGroups963852001");
            }
        else
            {
                context.setVariable("objectId", "planGroups963852");
            }
        }
}
else if(customerId=='963852' && accountId=='123456670' && lineId=='2061231234'){
     if(type=='serviceGroups'){
        if(serviceId)
            {   
                context.setVariable("objectId","serviceGroups963852001");
            }
        else
            {
                context.setVariable("objectId", "serviceGroups2061231234"); 
            }
        }
     else if(type=='planGroups'){
        if(planId)
            {   
                context.setVariable("objectId","planGroups963852001");
            }
        else
            {
                context.setVariable("objectId", "planGroups2061231234");
            }
        
       }
}
else if(customerId=='963853' && accountId=='123456670' && lineId=='2061231234'){
     if(type=='serviceGroups'){
        context.setVariable("objectId", "serviceGroups963853");  
     }else if(type=='planGroups'){
       context.setVariable("objectId", "planGroups963853");}
}
else if(customerId=='425435' && accountId=='123456678'){
    if(lineId=='4254357788'){
         if(type=='serviceGroups'){
            context.setVariable("objectId", "serviceGroups4254357788");  
         }else if(type=='planGroups'){
           context.setVariable("objectId", "planGroups4254357788");}
    }
    else if(lineId=='4254354466'){
         if(type=='serviceGroups'){
            context.setVariable("objectId", "serviceGroups4254354466");  
         }else if(type=='planGroups'){
           context.setVariable("objectId", "planGroups4254354466");}
    }
    else if(lineId=='4254352233'){
         if(type=='serviceGroups'){
            context.setVariable("objectId", "serviceGroups4254352233");  
         }else if(type=='planGroups'){
           context.setVariable("objectId", "planGroups4254352233");}
    }
}
else{
    context.setVariable("objectId", "000");   
} 
