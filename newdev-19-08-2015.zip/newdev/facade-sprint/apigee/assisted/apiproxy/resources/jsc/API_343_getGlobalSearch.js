var q=context.getVariable("request.queryparam.q"); 
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");
//var type=context.getVariable("request.queryparam.type");


context.setVariable("dataType","getGlobalSearch");

if(q == "Galaxy S5" && limit == null) { 
context.setVariable('objectId', '001'); 
} 
else if(q == "Galaxi S5" && limit == null) { 
context.setVariable('objectId', '002'); 
} 
else if(q == "Galaxy S5" && limit =="9" && offset == "1") { 
context.setVariable('objectId', '003'); 
} 
else if(q == "Galaxi S5" && limit =="9" && offset == "1") { 
context.setVariable('objectId', '004'); 
} 
else if(q == "Galaxy S5" && limit =="9" && offset == "2") { 
context.setVariable('objectId', '005'); 
}
else if(q == "Galaxi S5" && limit =="9" && offset == "2") { 
context.setVariable('objectId', '006'); 
} 
else if(q == "Galaxy S5" && limit =="9" && offset == "3") { 
context.setVariable('objectId', '007'); 
} 
else if(q == "Galaxi S5" && limit =="9" && offset == "3") { 
context.setVariable('objectId', '008'); 
} 
//else if(type=="global" && q=="Samsung") { 
//context.setVariable('objectId', '009'); 
//} 
