var imei=context.getVariable("request.queryparam.imei");
var carrier=context.getVariable("request.queryparam.carrier");
var maker=context.getVariable("request.queryparam.maker");
var model=context.getVariable("request.queryparam.model");

if(imei!=null && imei!='')
{
   context.setVariable('objectId', '0001');
}
else if(imei==null || imei=='')
{
   if((carrier==null && maker==null && model==null)||(carrier=='Sprint' && maker=='Apple' && model=='iPhone 4'))
  {
   context.setVariable('objectId', '0002');
  }
  else if(carrier=='Verizon' && maker=='Apple' && model=='iPhone 6 Plus')
  {
   context.setVariable('objectId', '0001');
  }
  else if(carrier=='Verizon' && maker=='Apple' && model=='Other')
  {
   context.setVariable('objectId', '0003');
  }
}
context.setVariable("dataType","compatibilityCheck");




/*var imei=context.getVariable("request.queryparam.imei");

if(imei!=null && imei!=''){
context.setVariable('objectId', '0001');
}else if(imei==null || imei==''){
context.setVariable('objectId', '0002');
}
context.setVariable("dataType","compatibilityCheck");*/