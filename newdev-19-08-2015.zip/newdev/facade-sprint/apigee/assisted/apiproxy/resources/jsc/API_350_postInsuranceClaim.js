var req_payload = context.targetRequest.body.asJSON
var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
var lineId=context.getVariable("lineId");

context.setVariable("dataType", "postInsuranceClaim");
context.setVariable("objectId", "0000")

/* if(req_payload!=null)
{
  if(customerId=='1202' && accountId=='123123' && lineId=='2061237482' && req_payload.imei=='001089000057482' && req_payload.msisdn =='2061237482')
  {
      context.setVariable("objectId", "0002");
  }
  else if(customerId=='1205' && accountId=='123123' && lineId=='2061238566' && req_payload.imei=='001089000050119' && req_payload.msisdn =='2061238566')
  {
      context.setVariable("objectId", "0003");
  }
  else if(req_payload.imei!=null && req_payload.returnUrl!=null && req_payload.claimType!=null && req_payload.timeStamp!=null && req_payload.email!=null)
  {
      context.setVariable("objectId", "0001");
  }
  else
  {
      context.setVariable("objectId", "0000");
  }
} */