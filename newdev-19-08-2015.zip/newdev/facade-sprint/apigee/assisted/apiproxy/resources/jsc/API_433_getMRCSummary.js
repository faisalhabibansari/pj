var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

context.setVariable("dataType","getMRCSummary");

if(customerId=='1234570' && accountId=='1234123')
{
    context.setVariable("objectId","001");
}
