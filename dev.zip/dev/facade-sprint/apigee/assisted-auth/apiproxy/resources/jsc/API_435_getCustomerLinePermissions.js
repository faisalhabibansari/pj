var id  = context.getVariable('msisdn');

context.setVariable('dataType', 'getCustomerLinePermissions');

context.setVariable('objectId', id);
