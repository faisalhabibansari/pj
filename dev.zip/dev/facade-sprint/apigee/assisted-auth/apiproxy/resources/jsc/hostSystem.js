/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Script: To identify customer segmentation
// Request Query Parameters: accountId || msisdn || sim || imsi
// Response: { custSegmentationResponse }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Currently pointing to mock host system base path as the core hostSystem service is not available

var basePathUrl = "https://rebelliondev-dev01.apigee.net/v1";

//var basePathUrl = 'https://<endpoint_once_available>/api/v1';

var resourceUrl = "/LineOfService/segmentation";

//Currently pointing to mock host system resource as the core hostSystem service is not available
//var resourceUrl = '/api/v1/LineOfService/segmentation';

var queryParamDelim = '?';
var qryString = "";

//Grab query parameter corresponding to accountId
//var accountId = "";
//accountId = context.proxyRequest.queryParams['accountId'];
var accountId = context.getVariable("request.queryparam.accountId");

//Grab query parameter corresponding to msisdn

//var msisdn = "";
//msisdn = context.proxyRequest.queryParams['msisdn'];
var msisdn = context.getVariable("request.queryparam.msisdn");

//Grab query parameter corresponding to sim
//var sim = "";
//sim = context.proxyRequest.queryParams['sim'];
var sim = context.getVariable("request.queryparam.sim");

//Grab query parameter corresponding to imsi
//var imsi = "";
//imsi = context.proxyRequest.queryParams['imsi'];
var imsi = context.getVariable("request.queryparam.imsi");

if(accountId!=undefined && accountId!=null)
{  	
  	qryString = "";
	qryString = queryParamDelim + 'AccountNumber=' + accountId;
  	context.setVariable('qryStringWithAccId',JSON.stringify(qryString));
}

if(msisdn!=undefined && msisdn!=null)
{
	qryString = "";
  	qryString = queryParamDelim + 'MobileNumber=' + msisdn;
	context.setVariable('qryStringWithMsisdn',JSON.stringify(qryString));  
}


if(sim!=undefined && sim!=null)
{  
  qryString = "";
  qryString = queryParamDelim + 'SIM=' + sim;
  context.setVariable('qryStringWithsim',JSON.stringify(qryString));  
}

if(imsi!=undefined && imsi!=null)
{
	qryString = "";
  	qryString = queryParamDelim + 'IMSI=' + imsi;
  	context.setVariable('qryStringWithImsi',JSON.stringify(qryString));  
}

context.setVariable('qryStringJSON',JSON.stringify(qryString));
var url = basePathUrl + resourceUrl + qryString;
context.setVariable('urlJSON',JSON.stringify(url));

//var iam_token = context.getVariable('iam_access_token');

//var headers = {"Authorization:Bearer": iam_token};

// get utilties
var utilities = context.getVariable('utilities');

//Grabbing core base path
var settingsObject = context.getVariable('settingsObject');

//Grabbing set headers for pass to core services
var headers = utilities.safePath.get(settingsObject, 'headers.care');

//Grabbing set headers for pass to core services
//var headers = context.getVariable('headers');

context.setVariable('headersJSON',JSON.stringify(headers));
var myRequest = new Request(url,"GET",headers);

var req = httpClient.send(myRequest);

req.waitForComplete();

var response = req.getResponse();

if(response.status == 200) 
{

var segmentationCode = response.headers['SegmentationCode'];
context.setVariable('SegmentationCodeJSON', JSON.stringify(segmentationCode));

var custSegmentationResponse = {"response" : ""};


if(segmentationCode=="T")
{
  
    custSegmentationResponse.response = "processInRebellion";
    custSegmentationResponse.dataCenterSegmentationId = "Titan";
}
    
if(segmentationCode=="P")
{  
    custSegmentationResponse.response = "processInRebellion";
    custSegmentationResponse.dataCenterSegmentationId = "Polaris";
}
    
if(segmentationCode=="R")
{  
    custSegmentationResponse.response = "redirectToEService";
    //Prepaid-RPX
}
  
if(segmentationCode=="S")
{  
    custSegmentationResponse.response = "redirectToEService";
    //Postpaid-Samson
}
    
if(segmentationCode=="I")
{
    custSegmentationResponse.response = "redirectToEService";
    //InMigration-Samson
}
    
    
if(segmentationCode=="J")
{
    custSegmentationResponse.response = "redirectToEService";
    //InMigration-RPX
}
    
if(segmentationCode=="K")
{
    custSegmentationResponse.response = "redirectToEService";
    //InMigration-Metro
}
    
if(segmentationCode=="U")
{
    custSegmentationResponse.response = "redirectToEService";
    //Unknown
}
    

context.setVariable('custSegmentationResponseJSON', JSON.stringify(custSegmentationResponse));
context.proxyResponse.content = JSON.stringify(custSegmentationResponse);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*var url = 'https://uat.account.tmus.net/userprofile/p/v1/userinfo';



var msisdn = context.proxyRequest.queryParams['msisdn'];
var iam_token = context.getVariable('iam_access_token');


var headers = {"Authorization:Bearer": iam_token};


var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);

req.waitForComplete();
var response = req.getResponse();

if(response.status == 200) {
 var result = response.content;
 context.setVariable("iam_profile", result);
 context.setVariable("msisdn", context.getVariable("iam_profile").associated_lines.line[0].MSISDN);
 
  if(context.getVariable("MSISDN") == "tel:+19392161519") {
  response.content = '{"response" : "redirectToEService", "BAN":"12312", "MSISDN": "9392161519"}';
} else {
  
  response.content = '{"response" : "processInRebellion" , "profile": "'+ Context.getVariable("iam_profile").asJSON +'" , "iam_access_token" : "' + Context.getVariable("access_token") +'" , "dataCenterSegmentationId" : "titan"}'; 
} 
}*/

/*
var msisdn = context.proxyRequest.queryParams['msisdn'];

if(msisdn == '9392161519') {
  response.content = '{"response" : "redirectToQv", "oam_cookie":"234jkhlk2342343", "BAN":"12312", "MSISDN": "9392161519"}';
} else {
  response.content = '{"response" : "processInRebellion" , "dataCenterSegmentationId" : "titan"}'; 
}
*/