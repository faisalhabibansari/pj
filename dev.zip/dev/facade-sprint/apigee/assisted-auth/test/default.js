var subproxy = "assisted-auth";

var globalEnvHeader = require('../../common-proxy/test/global_test_header.js');
var env = globalEnvHeader.setTestEnv(process.env.env, subproxy);
var assert = require('chai').assert, expect = require('chai').expect, supertest = require('supertest'), facade = supertest(env);

console.log("");
console.log(' env = ' + env);

// STANDARD HEADER ABOVE -- BELOW FOR TESTS ---------------------------------------------------------------------

