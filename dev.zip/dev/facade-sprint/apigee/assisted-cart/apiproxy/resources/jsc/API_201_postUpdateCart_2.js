var id = context.getVariable("objectId");
var reqPayLoad = context.targetRequest.body.asJSON;

var requestJSON = '';

if(reqPayLoad!=null&&reqPayLoad!='') {
  requestJSON = JSON.stringify(reqPayLoad);
}

/*if(id!=null && id == '7780') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1) 
     {
        context.setVariable("objectId","103");
     }
  }
}*/
if(id!=null && id == '1509') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
    {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234567") != -1) 
     {
        context.setVariable("objectId","0041");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456670") != -1) 
     {
        context.setVariable("objectId","0044");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456678") != -1) 
     {
        context.setVariable("objectId","0042");
     }
        else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1 && requestJSON.indexOf("4251234571") != -1) 
     {
        context.setVariable("objectId","103");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1) 
     {
        context.setVariable("objectId","0043");
         }
        
   }
}

else if(id!=null && id == '1690'){
  context.setVariable("objectId","093");}
else if(id!=null && id == '1685'){
    if(reqPayLoad.payments[0].cardNumber=='12345678901234')
    {
      context.setVariable("objectId","094");
    }
  }

else if(id!=null && id == '4444')
{
    if(reqPayLoad.cartLines instanceof Array) 
        {
            if(reqPayLoad.cartLines.length==3) 
            {
              if(requestJSON.indexOf("456786") != -1) 
              {
               context.setVariable("objectId","085");
              }
              else if(requestJSON.indexOf("456787") != -1) 
              {
               context.setVariable("objectId","086");
              }
            }
            else if(reqPayLoad.cartLines.length==2) 
            {
              if(requestJSON.indexOf("456785") != -1) 
              {
               context.setVariable("objectId","087");
              }
              else if(requestJSON.indexOf("456787") != -1) 
              {
               context.setVariable("objectId","087");
              }
            }
            else if(reqPayLoad.cartLines.length==1) 
            {
              if(requestJSON.indexOf("456785") != -1) 
              {
               context.setVariable("objectId","088");
              }
              else if(requestJSON.indexOf("123991") != -1) 
              {
               context.setVariable("objectId","092");
              }
             
            }
        }
}
/*else if(id!=null && id == '1551') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==2 && reqPayLoad.cartLines[0].items[0].productId=='101' && reqPayLoad.cartLines[0].items[1].productId=='111') 
     {
        context.setVariable("objectId","105");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items[0].productId=='101') 
     {
        context.setVariable("objectId","109");
     }
  }
}
*/
else if(id!=null && id == '1530'){
  context.setVariable("objectId","106");
}
else if(id!=null && id == '1531'){
  if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId=='30') 
     {
        context.setVariable("objectId","107");
     }
  }
}
else if(id!=null && id == '1561'){
  if (reqPayLoad.hasOwnProperty('shipping'))
  {
    if(reqPayLoad.shipping.address.type=='shipping') 
     {
        context.setVariable("objectId","108");
     }
  }
}
else if(id!=null && id == '1539'){
  if (reqPayLoad.actionCode=="Remove" && reqPayLoad.additionalFunds=="30")
  {
        context.setVariable("objectId","0115");
  }
}
else if(id!=null && id == '1540'){
  if (reqPayLoad.actionCode=="Remove" && reqPayLoad.additionalFunds=="120")
  {
        context.setVariable("objectId","0116");
  }
}
else if(id!=null && id == '1532'){
  if(reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
    if(reqPayLoad.items.length==4)
    {
       context.setVariable("objectId","0117");
    }
  }
}
else
{
  context.setVariable("objectId",id);
}
