var customerID = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
context.setVariable("dataType", 'getBillingOptions');
if (customerID == '1234' && accountId == '123123')
{
	context.setVariable("objectId", "001");
}
else if (customerID == '1234570' && accountId == '123123')
{
	context.setVariable("objectId", "002");
}
else if (customerID == '1234570' && accountId == '1234123')
{
	context.setVariable("objectId", "003");
}
else if (customerID == '234234234' && accountId == '9876543')
{
	context.setVariable("objectId", "004");
}
else if (customerID == '234234235' && accountId == '9876543')
{
	context.setVariable("objectId", "005");
}
else if (customerID == '761' && accountId == '4000000606')
{
	context.setVariable("objectId", "006");
}
else if (customerID == '760' && accountId == '4000000605')
{
	context.setVariable("objectId", "007");
}
else if (customerID == '756' && accountId == '4000000601')
{
	context.setVariable("objectId", "008");
}

// ---For QT-----

else if (customerID == '656' && accountId == '4000000568')
{
	context.setVariable("objectId", "009");
}
else if (customerID == '659' && accountId == '4000000569')
{
	context.setVariable("objectId", "010");
}
else if (customerID == '660' && accountId == '4000000570')
{
	context.setVariable("objectId", "011");
}
else if (customerID == '661' && accountId == '4000000571')
{
	context.setVariable("objectId", "012");
}

else if (customerID == '3000000034' && accountId == '4000000572')
{
	context.setVariable("objectId", "013");
}

else if (customerID == '3000000007' && accountId == '4000000548')
{
	context.setVariable("objectId", "014");
}

else if (customerID == '3000000008' && accountId == '4000000549')
{
	context.setVariable("objectId", "015");
}

else if (customerID == '3000000050' && accountId == '4000000583')
{
	context.setVariable("objectId", "016");
}

else if (customerID == '3000000035' && accountId == '4000000573')
{
	context.setVariable("objectId", "017");
}

else if (customerID == '3000000036' && accountId == '4000000574')
{
	context.setVariable("objectId", "018");
}

else if (customerID == '3000000037' && accountId == '4000000575')
{
	context.setVariable("objectId", "019");
}

else if (customerID == '3000000038' && accountId == '4000000576')
{
	context.setVariable("objectId", "020");
}

else if (customerID == '3000000039' && accountId == '4000000577')
{
	context.setVariable("objectId", "021");
}

else if (customerID == '3000000041' && accountId == '4000000579')
{
	context.setVariable("objectId", "022");
}