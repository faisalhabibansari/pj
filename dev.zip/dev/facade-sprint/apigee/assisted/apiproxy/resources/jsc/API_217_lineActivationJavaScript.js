var reqPayload = context.targetRequest.body.asJSON
var custId = context.getVariable("customerId");
var accId = context.getVariable("accountId");
var lineId = context.getVariable("lineId");

if (reqPayload != null && reqPayload != '')
{

	var accountType = reqPayload.accountType;
	var selectedPhoneNumber = reqPayload.selectedPhoneNumber;

	if (custId == '100' && accId == '200' && lineId == '2061234567')
	{
		context.setVariable("objectId", "2061234567");
	}
	else if (custId == '1234570' && accId == '1234123' && lineId == '2065551234' && accountType == 'Prepaid')
	{
		context.setVariable("objectId", "001");
	}
	else if (custId == '1234570' && accId == '1234123' && lineId == '2065551234' && accountType == 'Postpaid')
	{
		context.setVariable("objectId", "002");
	}
	else if (custId == '1234566' && accId == '1230123' && lineId == '2062227777' && accountType == 'Postpaid')
	{
		context.setVariable("objectId", "003"); // 1
	}
	else if (custId == '1234567' && accId == '1330124' && lineId == '2162228888' && accountType == 'Postpaid')
	{
		context.setVariable("objectId", "004"); // 2
	}
	else if (custId == '1234569' && accId == '1330125' && lineId == '2162228889' && accountType == 'Prepaid'
			&& selectedPhoneNumber != '4253212928')
	{
		context.setVariable("objectId", "005"); // 3
	}
	else if (custId == '1234570' && accId == '1330125' && lineId == '2162228889' && accountType == 'Prepaid'
			&& selectedPhoneNumber != '4256032225')
	{
		context.setVariable("objectId", "006"); // 4
	}
	else if (custId == '1234566' && accId == '1230123' && lineId == '2062227777' && selectedPhoneNumber == '2063381111')
	{
		context.setVariable("objectId", "007"); // 5
	}
	else if (custId == '1234567' && accId == '1330124' && lineId == '2162228888' && selectedPhoneNumber == '4256032222')
	{
		context.setVariable("objectId", "008"); // 6
	}
	else if (custId == '1234569' && accId == '1330125' && lineId == '2162228889' && selectedPhoneNumber == '2062503333')
	{
		context.setVariable("objectId", "009"); // 7
	}
	else if (custId == '1234570' && accId == '1330125' && lineId == '2162228889' && selectedPhoneNumber == '4256032222')
	{
		context.setVariable("objectId", "010");
	}
	else if (custId == '1234571' && accId == '1230171' && lineId == '2062227771' && selectedPhoneNumber == '4253212928')
	{
		context.setVariable("objectId", "011");
	}
	else if (custId == '1234571' && accId == '1230171' && lineId == '2062227771' && selectedPhoneNumber == '2063381111')
	{
		context.setVariable("objectId", "012");
	}
	else if (custId == '1234571' && accId == '1230171' && lineId == '2062227771' && selectedPhoneNumber == '2063381112')
	{
		context.setVariable("objectId", "013");
	}
	else if (custId == '1234572' && accId == '1230172' && lineId == '2062227772' && selectedPhoneNumber == '4256032222')
	{
		context.setVariable("objectId", "014");
	}
	else if (custId == '1234572' && accId == '1230172' && lineId == '2062227772' && selectedPhoneNumber == '4256032223')
	{
		context.setVariable("objectId", "015");
	}
	else if (custId == '1234572' && accId == '1230172' && lineId == '2062227772' && selectedPhoneNumber == '4253212928')
	{
		context.setVariable("objectId", "016");
	}
	else if (custId == '1234569' && accId == '1330125' && lineId == '2162228889' && selectedPhoneNumber == '4253212928')
	{
		context.setVariable("objectId", "017");
	}
	else if (custId == '1234570' && accId == '1330125' && lineId == '2162228889' && selectedPhoneNumber == '4256032225')
	{
		context.setVariable("objectId", "018");
	}
}
else
{
	context.setVariable("objectId", "");
}