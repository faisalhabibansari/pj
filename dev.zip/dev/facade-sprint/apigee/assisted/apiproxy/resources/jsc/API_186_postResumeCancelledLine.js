var reqPayLoad = context.targetRequest.body.asJSON

var customerId=context.getVariable("customerId");

context.setVariable("dataType","postResumeCancelledLine");

if(reqPayLoad!=null)
{	
    var JSON_STRING = JSON.stringify(reqPayLoad);
	if(customerId=='741852')
	{
       if(JSON_STRING.indexOf("1123123790") != -1 && JSON_STRING.indexOf("123190") != -1 && JSON_STRING.indexOf("123191") != -1)
	   {
        context.setVariable("objectId","001");
	   }
      else if(JSON_STRING.indexOf("1123123790") != -1 && JSON_STRING.indexOf("123190") != -1)
	   {
        context.setVariable("objectId","002");
	   }
      else if(JSON_STRING.indexOf("1123123790") != -1 && JSON_STRING.indexOf("123191") != -1)
	   {
        context.setVariable("objectId","003");
	   }
	}
    else
	{
        context.setVariable("objectId","000");
	}
} 
else
{
  context.setVariable("objectId","000");
}