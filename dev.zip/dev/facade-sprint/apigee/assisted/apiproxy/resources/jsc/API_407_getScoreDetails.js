//Get 'objectId' from the context
var objectId = context.getVariable("lineId");
context.setVariable("objectId", objectId);

context.setVariable("dataType",'getScoreDetails'); 
