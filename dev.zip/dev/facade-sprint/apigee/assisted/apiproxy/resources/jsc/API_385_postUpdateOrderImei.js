var reqPayLoad = context.targetRequest.body.asJSON

var orderId=context.getVariable("orderId");

context.setVariable("dataType","postUpdateOrderImei");

if(reqPayLoad!=null)
{	
	if(orderId=='4399015' && reqPayLoad.IMEI=='12345678901234567')
	{
        context.setVariable("objectId","001");
	}
	else if(orderId=='4399016' && reqPayLoad.IMEI=='1234567890123')
	{
        context.setVariable("objectId","002");
	}
    else if(orderId=='4599017' && reqPayLoad.IMEI=='1234567890123')
	{
        context.setVariable("objectId","003");
	}
    else if(orderId=='4599018' && reqPayLoad.IMEI=='1234567890123')
	{
        context.setVariable("objectId","004");
	}
    else if(orderId=='4599019' && reqPayLoad.IMEI=='1234567890123')
	{
        context.setVariable("objectId","005");
	}
	else if(orderId=='4599020' && reqPayLoad.IMEI=='1234567890123')
	{
        context.setVariable("objectId","006");
	}
 	else if(orderId=='90299021' && reqPayLoad.IMEI=='112233445566000')
	{
        context.setVariable("objectId","007");
	}
 	else if(orderId=='90299087' && reqPayLoad.IMEI=='112233445566011')
	{
        context.setVariable("objectId","008");
	}
 	else if(orderId=='90299023' && reqPayLoad.IMEI=='112233445566022')
	{
        context.setVariable("objectId","009");
	}
 	else if(orderId=='90299024' && reqPayLoad.IMEI=='112233445566033')
	{
        context.setVariable("objectId","010");
	}
  else if(orderId=='90299022' && reqPayLoad.IMEI=='112233445566033')
	{
        context.setVariable("objectId","013");
	}
 	else if(orderId=='90299021' && reqPayLoad.IMEI=='112233445566044')
	{
        context.setVariable("objectId","011");
	}
 	else if(orderId=='90299044' && reqPayLoad.IMEI=='112233445566055')
	{
        context.setVariable("objectId","012");
	}
    else
	{
        context.setVariable("objectId","000");
	}
} 
else
{
  context.setVariable("objectId","000");
}