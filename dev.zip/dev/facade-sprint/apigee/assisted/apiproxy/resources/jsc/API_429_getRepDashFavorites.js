var repId=context.getVariable("request.queryparam.repId");
context.setVariable("dataType","getRepDashFavorites");

context.setVariable("objectId","001");
