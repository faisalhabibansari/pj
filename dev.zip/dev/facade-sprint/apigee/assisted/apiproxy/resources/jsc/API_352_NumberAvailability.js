var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable('dataType','NumberAvailability');

/*if(reqPayLoad!=null && reqPayLoad.type=='zipCode')
{
    context.setVariable("objectId","1"); 
}
    else if (reqPayLoad!=null && reqPayLoad.type=='areaCode')
    {  
      context.setVariable("objectId","2"); 
    }
*/
if(reqPayLoad!=null)
{
 if(reqPayLoad.type=='zipCode')
 {
  if(reqPayLoad.zipCode.length==2)
  {
     if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98102' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","1"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98015' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","9"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98015' && reqPayLoad.zipCode[1].limit=='2')
     {
       context.setVariable("objectId","4"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='3' && reqPayLoad.zipCode[1].code=='98015' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","7"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98072' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98073' && reqPayLoad.zipCode[1].limit=='3')
     {
       context.setVariable("objectId","8"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='2' && reqPayLoad.zipCode[1].code=='98015' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","10"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98072' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98073' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","12"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98101' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","14"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='2' && reqPayLoad.zipCode[1].code=='98101' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","15"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98101' && reqPayLoad.zipCode[1].limit=='3')
     {
       context.setVariable("objectId","16"); 
     }
  else if(reqPayLoad.zipCode[0].code=='98073' && reqPayLoad.zipCode[0].limit=='3' && reqPayLoad.zipCode[1].code=='98072' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","17"); 
     }
  else if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98101' && reqPayLoad.zipCode[1].limit=='2')
     {
       context.setVariable("objectId","18"); 
     }
  else if(reqPayLoad.zipCode[0].code=='98073' && reqPayLoad.zipCode[0].limit=='1' && reqPayLoad.zipCode[1].code=='98072' && reqPayLoad.zipCode[1].limit=='1')
     {
       context.setVariable("objectId","19"); 
     }
  }
  else if(reqPayLoad.zipCode.length==1)
  {
     if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='2')
     {
       context.setVariable("objectId","5"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='1')
     {
       context.setVariable("objectId","6"); 
     }
     else if(reqPayLoad.zipCode[0].code=='98101' && reqPayLoad.zipCode[0].limit=='2')
     {
       context.setVariable("objectId","11"); 
     }
    else if(reqPayLoad.zipCode[0].code=='98015' && reqPayLoad.zipCode[0].limit=='1')
     {
       context.setVariable("objectId","13"); 
     }
  }

 }
 else if(reqPayLoad.type=='areaCode')
 {
  context.setVariable("objectId","2"); 
 }
  else if(reqPayLoad!=null && reqPayLoad.type=='areaExchangeCode')
 {
  context.setVariable("objectId","20"); 
 }
 else
 {
  context.setVariable("objectId","0"); 
 }
}
else
{
 context.setVariable("objectId","0"); 
}