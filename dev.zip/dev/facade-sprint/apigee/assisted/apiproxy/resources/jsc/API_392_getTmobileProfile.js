var tmobileId=context.getVariable("tmobileId");

context.setVariable("dataType","getTmobileProfile");


if(tmobileId=='123456789')
{
    context.setVariable("objectId","001");
}
