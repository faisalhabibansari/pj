var contentPath=context.getVariable("request.queryparam.contentPath");
context.setVariable("dataType","getAemContents");
if(contentPath=="configurations/account/reviewReactivation.config.json")
{
	context.setVariable("objectId","001");
}
else if(contentPath=="/content/t-mobile/en/countries.json")
{
	context.setVariable("objectId","002");
}
