var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var input = request_payload.input;
var userName = request_payload.userName;
var emailAddress = request_payload.emailAddress;
var address = request_payload.address;
var msisdn = request_payload.msisdn;
var accountId = request_payload.accountId

context.setVariable("dataType","inputValidator");

 if(input=='userName' && userName=='MichaelSmith')
 {
          context.setVariable("objectId", "001"); 
 }
    
 else if(input=='emailAddress'&& emailAddress=='ms@ms.com')
  {
          context.setVariable("objectId", "002"); 
  }else if(input=='emailAddress'&& emailAddress=='mngp@t-mobile.com')
  {
          context.setVariable("objectId", "011"); 
  }else if(input=='emailAddress'&& emailAddress=='mngp1@t-mobile.com')
  {
          context.setVariable("objectId", "012"); 
  }else if(input=='emailAddress'&& emailAddress=='mngp2@t-mobile.com')
  {
          context.setVariable("objectId", "013"); 
  }
   else if(input=='address' && address.addressLine1=="")
  {
          context.setVariable("objectId", "003"); 
  }

else if (input == 'address' && address.addressLine1 == '123 Main St') {
    context.setVariable("objectId", "004"); 
}
else if (input == 'address' && address.addressLine1 == 'Sttle street') {
    context.setVariable("objectId", "005"); 
}
else if (input == 'address' && address.addressLine1 == 'Sestian Garden') {
    context.setVariable("objectId", "006"); 
}
else if (input == 'msisdn' && msisdn == '2061123467') {
    context.setVariable("objectId", "008"); 
}
else if (input == 'msisdn' && msisdn == '4254351234') {
    context.setVariable("objectId", "008"); 
}
else if (input == 'msisdn' && msisdn == '4254354321') {
    context.setVariable("objectId", "008"); 
}
else if (input == 'msisdn' && msisdn == '2061123456') {
    context.setVariable("objectId", "010"); 
}
else if (input == 'msisdn' && msisdn == '5551234567') {
    context.setVariable("objectId", "018"); 
}
else if (input == 'msisdn' && msisdn == '5551234568') {
    context.setVariable("objectId", "019"); 
}
else if (input == 'msisdn' && msisdn == '5551234575') {
    context.setVariable("objectId", "021"); 
}
else if (input == 'address' && address.addressLine1 == '1234 Sunny St.') {
    context.setVariable("objectId", "009"); 
}
else if (input == 'accountId' && accountId == 'A1234567897') {
    context.setVariable("objectId", "016"); 
}
else if (input == 'emailAddress' && emailAddress == 'abc@gmail.com') {
    context.setVariable("objectId", "017"); 
}
else if (input == 'emailAddress' && emailAddress == 'steve.glinert@gmail.com') {
    context.setVariable("objectId", "020"); 
}
else if (input == 'emailAddress' && emailAddress == 'francis@email.com') {
    context.setVariable("objectId", "021"); 
}
/*else if (input == 'msisdn' && msisdn == '4254351234') {
  context.setVariable("objectId", "014");
}
else if (input == 'msisdn' && msisdn == '4254354321') {
  context.setVariable("objectId", "015"); 
}*/