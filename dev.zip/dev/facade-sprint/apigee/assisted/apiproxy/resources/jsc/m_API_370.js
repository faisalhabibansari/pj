var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postBlockingControls");
if(reqPayLoad!=null && JSON.stringify(reqPayLoad).indexOf("dataControlsSelected")!= -1 && JSON.stringify(reqPayLoad).indexOf("linesSelected")!= -1)
{
context.setVariable("objectId","001");
}
   