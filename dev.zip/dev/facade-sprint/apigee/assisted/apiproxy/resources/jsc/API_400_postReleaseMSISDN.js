var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postReleaseMSISDN");

if(reqPayLoad!=null && (reqPayLoad instanceof Array) && reqPayLoad.length>0)
{
context.setVariable("objectId","001");
}
  