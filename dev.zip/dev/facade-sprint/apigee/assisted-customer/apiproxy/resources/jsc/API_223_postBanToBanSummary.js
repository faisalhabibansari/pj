var reqPayLoad = context.targetRequest.body.asJSON
var accountId = context.getVariable("accountId")
var customerId = context.getVariable("customerId")
if(reqPayLoad!=null){ 
  if(customerId=='234234200' && accountId=='123127'){
    context.setVariable("objectId", "123127");
  }else if(customerId=='234234200' &&  accountId=='123456'){
    context.setVariable("objectId", "123456");
  }else if(customerId=='234234200' &&  accountId=='123126'){
    context.setVariable("objectId", "123126");
  }else if(customerId=='234234328' &&  accountId=='123123'){
    context.setVariable("objectId", "123123");
  }else if(customerId=='500000002' &&  accountId=='123123' && reqPayLoad.lines[0].msisdn=='8182223334' && reqPayLoad.newAccountId=='123124'){
    context.setVariable("objectId", "001");
  }
  else if(customerId=='500000002' &&  accountId=='123123' && reqPayLoad.lines[0].msisdn=='8182223334' && reqPayLoad.newAccountId=='123123'){
    context.setVariable("objectId", "004");
  }
  else if(customerId=='500000002' &&  accountId=='123123' && reqPayLoad.lines[0].msisdn=='8182223335' && reqPayLoad.newAccountId=='123123'){
    context.setVariable("objectId", "005");
  }
  else if(customerId=='500000001' &&  accountId=='123123' && reqPayLoad.lines[0].msisdn == '6021234578'){
    context.setVariable("objectId", "002");
  }
  else if(customerId=='500000001' &&  accountId=='123123' && reqPayLoad.lines[0].msisdn == '2061234567'){
    context.setVariable("objectId", "003");
  }
  else{
    context.setVariable("objectId", "12345");
  }
}
else
{
    context.setVariable("objectId","0000");
}
context.setVariable("dataType", "postBanToBanSummary");