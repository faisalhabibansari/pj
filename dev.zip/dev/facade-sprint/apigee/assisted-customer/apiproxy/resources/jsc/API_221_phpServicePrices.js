var msisdn = context.targetRequest.body.asJSON.msisdn
var custId = context.getVariable("customerId");

if(custId=='234234234' && msisdn=='6021234577'){
  context.setVariable("objectId", "6021234577");
}else if(custId=='234234234' && msisdn=='2061234567'){
  context.setVariable("objectId", "2061234567");
}else if(custId=='234234234' && msisdn=='6354781111'){
  context.setVariable("objectId", "6354781111");
}else if(custId=='234234234' && msisdn=='2062234567'){
  context.setVariable("objectId", "2062234567");
}else if(custId=='12345' && msisdn=='2061234567'){
context.setVariable("objectId", "12345");
}else{
  context.setVariable("objectId", "");
}

