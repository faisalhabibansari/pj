var customerId = context.getVariable("customerId");
var accountId = context.getVariable("objectId");

if (customerId == '1241' && accountId == '123123')
{
	context.setVariable("objectId", "001");
}
else if (customerId == '12345' && accountId == '123123')
{
	context.setVariable("objectId", "002");
}
else if (customerId == '33456' && accountId == '123123')
{
	context.setVariable("objectId", "003");
}
else if (customerId == '741852' && accountId == '123123')
{
	context.setVariable("objectId", "004");
}
else if (customerId == '425435' && accountId == '12345667')
{
	context.setVariable("objectId", "005");
}
else if (customerId == '741852' && accountId == '12345667')
{
	context.setVariable("objectId", "006");
}
else if (customerId == '963852' && accountId == '12345667')
{
	context.setVariable("objectId", "007");
}
else if (customerId == '425435' && accountId == '123456678')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '741852' && accountId == '123123789')
{
	context.setVariable("objectId", "009");
}
else if (customerId == '963852' && accountId == '123456670')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '500000001' && accountId == '123123')
{
	context.setVariable("objectId", "011");
}
else if (customerId == '500000002' && accountId == '123123')
{
	context.setVariable("objectId", "012");
}
else if (customerId == '500000003' && accountId == '123127')
{
	context.setVariable("objectId", "013");
}
else if (customerId == '500000011' && accountId == '123123')
{
	context.setVariable("objectId", "014");
}
else if (customerId == '500000015' && accountId == '123123')
{
	context.setVariable("objectId", "015");
}
else if (customerId == '234234328' && accountId == '456785')
{
	context.setVariable("objectId", "016");
}
else if (customerId == '23456' && accountId == '5555501')
{
	context.setVariable("objectId", "0017");
}
else if (customerId == '22245' && accountId == '5555502')
{
	context.setVariable("objectId", "0018");
}
else if (customerId == '22246' && accountId == '5555503')
{
	context.setVariable("objectId", "0019");
}
else if (customerId == '22247' && accountId == '5555504')
{
	context.setVariable("objectId", "0020");
}
else if (customerId == '22248' && accountId == '5555505')
{
	context.setVariable("objectId", "0021");
}
else if (customerId == '22249' && accountId == '5555506')
{
	context.setVariable("objectId", "0022");
}
else if (customerId == '22250' && accountId == '5555507')
{
	context.setVariable("objectId", "0023");
}
else if (customerId == '22251' && accountId == '5555508')
{
	context.setVariable("objectId", "0024");
}
else if (customerId == '22252' && accountId == '5555509')
{
	context.setVariable("objectId", "0025");
}
else if (customerId == '22253' && accountId == '5555510')
{
	context.setVariable("objectId", "0026");
}
else if (customerId == '22254' && accountId == '5555511')
{
	context.setVariable("objectId", "0027");
}
else if (customerId == '22255' && accountId == '5555512')
{
	context.setVariable("objectId", "0028");
}
else if (customerId == '22256' && accountId == '5555513')
{
	context.setVariable("objectId", "0029");
}
else if (customerId == '555555555' && accountId == '456785')
{
	context.setVariable("objectId", "0030");
}
else if (customerId == '982333' && accountId == '123458899')
{
	context.setVariable("objectId", "0031");
}
else if (customerId == '425436' && accountId == '123123')
{
	context.setVariable("objectId", "0052");
}
else if (customerId == '741856' && accountId == '123456681')
{
	context.setVariable("objectId", "0054");
}
else if (customerId == '8900781' && accountId == '1530224')
{
	context.setVariable("objectId", "055");
}
else if (customerId == '2345678' && accountId == '7230223')
{
	context.setVariable("objectId", "056");
}
else if (customerId == '1234566' && accountId == '1230123')
{
	context.setVariable("objectId", "057");
}
else if (customerId == '1234567' && accountId == '1330124')
{
	context.setVariable("objectId", "058");
}
else if (customerId == '1234569' && accountId == '1330125')
{
	context.setVariable("objectId", "059");
}
else if (customerId == '1234570' && accountId == '1330125')
{
	context.setVariable("objectId", "060");
}
// QAT 331
else if (customerId == '3000000028' && accountId == '4000000568')
{
	context.setVariable("objectId", "0034");
}
else if (customerId == '3000000031' && accountId == '4000000569')
{
	context.setVariable("objectId", "0035");
}
else if (customerId == '3000000032' && accountId == '4000000570')
{
	context.setVariable("objectId", "0036");
}
else if (customerId == '3000000033' && accountId == '4000000571')
{
	context.setVariable("objectId", "0037");
}
else if (customerId == ' 3000000034' && accountId == ' 4000000572')
{
	context.setVariable("objectId", "0038");
}
else if (customerId == ' 3000000007' && accountId == ' 4000000548')
{
	context.setVariable("objectId", "0039");
}
else if (customerId == ' 3000000008' && accountId == ' 4000000549')
{
	context.setVariable("objectId", "0040");
}
else if (customerId == ' 3000000050' && accountId == ' 4000000583')
{
	context.setVariable("objectId", "0041");
}
else if (customerId == ' 3000000035' && accountId == ' 4000000573')
{
	context.setVariable("objectId", "0042");
}
else if (customerId == ' 3000000036' && accountId == ' 4000000574')
{
	context.setVariable("objectId", "0043");
}
else if (customerId == ' 3000000037' && accountId == ' 4000000575')
{
	context.setVariable("objectId", "0044");
}
else if (customerId == ' 3000000038' && accountId == ' 4000000576')
{
	context.setVariable("objectId", "0045");
}
else if (customerId == ' 3000000039' && accountId == ' 4000000577')
{
	context.setVariable("objectId", "0046");
}
else if (customerId == ' 3000000041' && accountId == ' 4000000579')
{
	context.setVariable("objectId", "0047");
}
else if (customerId == '234236000' && accountId == '123123')
{
	context.setVariable("objectId", "0048");
}
else if (customerId == '234236001' && accountId == '123123')
{
	context.setVariable("objectId", "0049");
}
else if (customerId == '425436' && accountId == '123456678')
{
	context.setVariable("objectId", "0050");
}
else if (customerId == '425437' && accountId == '123456678')
{
	context.setVariable("objectId", "0051");
}
else if (customerId == '9876543210' && accountId == '332211')
{
	context.setVariable("objectId", "061");
}
// QAT Ends
else
{
	context.setVariable("objectId", accountId);
}