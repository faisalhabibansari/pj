var reqPayLoad = context.targetRequest.body.asJSON

var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

context.setVariable("dataType","OffDeviceLineActivation");

if(reqPayLoad!=null)
{
    if(customerId=='8900781' && accountId=='1530224' && reqPayLoad.hasOwnProperty('Lines') && reqPayLoad.Lines instanceof Array)
    {
        if(reqPayLoad.Lines.length==4)
        {

         var lines = JSON.stringify(reqPayLoad.Lines);

         if(lines.indexOf("4253212928") != -1 && lines.indexOf('2063381111') != -1 && lines.indexOf('3603339887') != -1 && lines.indexOf('4256032222') != -1)
         {
           context.setVariable("objectId","001");
         }
         else if(lines.indexOf("4253212928") != -1 && lines.indexOf('2063381111') != -1 && lines.indexOf('4256032222') != -1 )
         {
           context.setVariable("objectId","002");
         }
         else if(lines.indexOf("4253212928") != -1 && lines.indexOf('3603339887') != -1 && lines.indexOf('2063381111') != -1)
         {
           context.setVariable("objectId","003");
         }
         else if(lines.indexOf("4253212928") == -1 && lines.indexOf("2063381111") != -1 && lines.indexOf('4256032222') != -1)
         {
           context.setVariable("objectId","004");
         }
         else if(lines.indexOf("4253212928") != -1 && lines.indexOf('3603050219') != -1 && lines.indexOf('3603339887') != -1  && lines.indexOf('3603052983') != -1)
         {
           context.setVariable("objectId","005");
         }
         else
         {
          context.setVariable("objectId","000");
         }
        }
    }
  else if(customerId=='2345678' && accountId=='7230223' && reqPayLoad.hasOwnProperty('Lines') && reqPayLoad.Lines instanceof Array)
    {
        if(reqPayLoad.Lines.length==4)
        {
         var lines = JSON.stringify(reqPayLoad.Lines);

         if(lines.indexOf("4253212928") != -1 && lines.indexOf('3603050219') != -1 && lines.indexOf('3603339887') != -1 && lines.indexOf('3603052983') != -1)
         {
           context.setVariable("objectId","006");
         }
         else if(lines.indexOf("2062503333") != -1 && lines.indexOf('2062503334') == -1 && lines.indexOf('2062503335') == -1)
         {
           context.setVariable("objectId","007");
         }
         else if(lines.indexOf("2062503333") != -1 && lines.indexOf('2062503334') != -1 && lines.indexOf('2062503335') != -1)
         {
           context.setVariable("objectId","008");
         }
         else
         {
          context.setVariable("objectId","000");
         }
        }
    }

    else if(customerId=='1234570' && accountId=='1234123' && reqPayLoad.hasOwnProperty('lines') && reqPayLoad.lines instanceof Array)
    {
    context.setVariable("objectId","1234123");
    }
}
