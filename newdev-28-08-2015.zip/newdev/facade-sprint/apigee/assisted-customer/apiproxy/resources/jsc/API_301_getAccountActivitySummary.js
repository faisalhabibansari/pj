var objectId = context.getVariable("objectId");
var accountId = context.getVariable("accountId");
var activityType=context.getVariable("request.queryparam.activityType");
var customerView=context.getVariable("request.queryparam.customerView");
var startDate=context.getVariable("request.queryparam.startDate");
var endDate=context.getVariable("request.queryparam.endDate");
var msisdn=context.getVariable("request.queryparam.msisdn");
var status=context.getVariable("request.queryparam.status");
var type=context.getVariable("request.queryparam.type");
var subType=context.getVariable("request.queryparam.subType");
var sortBy=context.getVariable("request.queryparam.sortBy");
var orderBy=context.getVariable("request.queryparam.orderBy");
var q=context.getVariable("request.queryparam.q");
var hidden=context.getVariable("request.queryparam.hidden");
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");

if(accountId=='432432432')
{
context.setVariable("objectId", "432432432");
}
else if(objectId=='12345' && accountId =='123123')
{
 	context.setVariable("objectId", "12345");
}
else if(objectId=='753869' && accountId =='12345667')
{
 	context.setVariable("objectId", "004");
}
else if(objectId=='963852' && accountId =='123456670')
{
	if(offset=='15' && limit=='5')
		{
			if(sortBy=='subType' && orderBy=='asc' && hidden=='true')
			{
				context.setVariable("objectId", "3401");
			}
			
		}
	else if(offset=='10' && limit=='5')
		{
			if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "1001");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "1002");
              
			}
          	else if(sortBy=='subType' && orderBy=='asc' && hidden=='true')
			{
				context.setVariable("objectId", "1006");
			}
			else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "1002");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "1005");
			}
			else if(customerView=='true')
			{
				context.setVariable("objectId", "1004");
			}
			else
			{
				context.setVariable("objectId", "1003");
			}
		}
	else if(offset=='5' && limit=='5')
		{
			if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "2001");
			}
          	else if(hidden=='true')
            {
				if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
				{
					context.setVariable("objectId", "2011");
				}
				else if(sortBy=='subType' && orderBy=='asc')
				{
					context.setVariable("objectId", "2009");
				}
            }
          	else if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
			{
				context.setVariable("objectId", "2010");
			}
			else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "2005");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "2002");
			}
			else if(customerView=='true')
			{
				context.setVariable("objectId", "2004");
			}
			else if(type=='Billing')
			{
				context.setVariable("objectId", "2007");
			}
			else if(q!=null)
			{
				context.setVariable("objectId", "2008");
			}
			else if(msisdn=='2061231234')
			{
				context.setVariable("objectId", "2006");
			}
			else
			{
				context.setVariable("objectId", "2003");
			}
		}
	else if(offset=='0' && limit=='5')
		{
			if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "3001");
			}
          	else if(hidden=='true')
			{
				if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
				{	
                  if(q=='payment')
                  {
					context.setVariable("objectId", "3016");
                  }
                  else if(q!=null && q!='')
                  {
                    context.setVariable("objectId", "3017");
                  }
                  else
                  {
                    context.setVariable("objectId", "3015");
                  }
				}
				else if(sortBy=='subType' && orderBy=='asc')
				{
					context.setVariable("objectId", "3012");
				}
			}
          	else if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
			{	
				if(q=='payment')
				{
					context.setVariable("objectId", "3014");
				}
				else if(q!=null && q!='')
                {
                    context.setVariable("objectId", "3018");
                }
				else
				{
					context.setVariable("objectId", "3013");
				}
				
			}
          	else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "3005");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "3002");
			}
			else if(customerView=='true')
			{
				context.setVariable("objectId", "3004");
			}
			else if(msisdn=='2061231234')
			{
				context.setVariable("objectId", "3006");
			}
			else if(startDate=='05/01/2015' && endDate=='05/10/2015')
			{
				context.setVariable("objectId", "3007");
			}
			else if(type=='Billing' && subType=='Paperless billing')
			{
				context.setVariable("objectId", "3008");
			}
			else if(type=='Billing')
			{
				context.setVariable("objectId", "3010");
			}
			else if(q=='payment')
			{
				context.setVariable("objectId", "3009");
			}
			else if(q!=null)
			{
				context.setVariable("objectId", "3011");
			}
			else
			{
				context.setVariable("objectId", "3003");
			}
		}
	else if(offset=='0' && limit=='10')
		{
			if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "3104");
			}
          	else if(hidden=='true')
			{
				if(sortBy=='subType' && orderBy=='asc' && type=='Billing' && q=='payment')
				{
					context.setVariable("objectId", "3115");
				}
				else if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
				{
					context.setVariable("objectId", "3116");
				}
				else if(sortBy=='subType' && orderBy=='asc')
				{
					context.setVariable("objectId", "3112");
				}
			}
         	else if(sortBy=='subType' && orderBy=='asc' && type=='Billing' && q=='payment')
			{
				context.setVariable("objectId", "3114");
			}
          	else if(sortBy=='subType' && orderBy=='asc' && type=='Billing')
			{
				context.setVariable("objectId", "3113");
			}
			else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "3102");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "3103");
			}
          	else if(sortBy=='activityDate' && orderBy=='desc')
			{
				context.setVariable("objectId", "3106");
			}
			else if(customerView=='true')
			{
				context.setVariable("objectId", "3105");
			}
			else if(msisdn=='2061231234')
			{
				context.setVariable("objectId", "3101");
			}
			else if(type=='Billing' && subType=='Paperless billing')
			{
				context.setVariable("objectId", "3107");
			}
			else if(type=='Billing')
			{
				context.setVariable("objectId", "3110");
			}
			else if(startDate=='05/01/2015' && endDate=='05/10/2015')
			{
				context.setVariable("objectId", "3108");
			}
			else if(q=='payment')
			{
				context.setVariable("objectId", "3109");
			}
			else if(q!=null)
			{
				context.setVariable("objectId", "3111");
			}
			
			
		}
	else if(offset=='10' && limit=='10')
		{
			if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "3203");
			}
          	else if(sortBy=='subType' && orderBy=='asc' && hidden=='true')
			{
				context.setVariable("objectId", "3206");
			}
			else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "3201");
			}
			else if(sortBy=='activityDate' && orderBy=='asc')
			{
				context.setVariable("objectId", "3202");
			}
            else if(sortBy=='activityDate' && orderBy=='desc')
			{
				context.setVariable("objectId", "3205");
			}
			else if(customerView=='true')
			{
				context.setVariable("objectId", "3204");
			}
			
			
		}
	else if(offset!=null && limit!=null)
	{
		context.setVariable("objectId", "3301");
	}
  else if(customerView=='true')
		{
			if(type=='Services' && subType=='New feature' && msisdn=='4251234568' && startDate=='04/01/2015' && endDate=='04/10/2015')
			{
				context.setVariable("objectId", "0055");
			}
			else if(q=='payment' || q=='Payment')
			{
				context.setVariable("objectId", "00521");
			}
			else if(sortBy=='subType' && orderBy=='asc')
			{
				context.setVariable("objectId", "00522");
			}
		  else if(sortBy=='subType' && orderBy=='desc')
			{
				context.setVariable("objectId", "00524");
			}
			else if(msisdn=='2061231234' && hidden=='true')
			{
				context.setVariable("objectId", "00525");
			}
			else if(type=='Billing')
			{
				context.setVariable("objectId", "00523");
			}
			else if((msisdn!=null && msisdn!='') || (q!=null && q!='') || (type!=null && type!='') || (status!=null && status!='') || (subType!=null && subType!='' && type=='billing'))
			{
			context.setVariable("objectId", "0000");
			}
			else
			{
			context.setVariable("objectId", "0052");
			}
		}
	else if(msisdn=='2061231234' && hidden=='true')
	{
		context.setVariable("objectId", "00513");
	}
	else if(msisdn=='2061231234')
	{
		context.setVariable("objectId", "0053");
	}
	else if(startDate=='04/30/2015' && endDate=='04/30/2015')
	{
		context.setVariable("objectId", "00515");
	}
	else if(status=='Received')
	{
		context.setVariable("objectId", "0054");
	}
	else if(type=='Billing' && subType=='Paperless billing')
	{
		context.setVariable("objectId", "0057");
	}
	else if(type=='Billing' && (q=='payment' || q=='Payment'))
	{
		context.setVariable("objectId", "00514");
	}
	else if(type=='Billing' && subType==null)
	{
		context.setVariable("objectId", "0056");
	}
	
	else if(sortBy=='subType' && orderBy=='asc')
	{
		context.setVariable("objectId", "0058");
	}
	else if(sortBy=='activityDate' && orderBy=='asc')
	{
		context.setVariable("objectId", "0059");
	}
 	else if(sortBy=='activityDate' && orderBy=='desc')
	{
		context.setVariable("objectId", "00516");
	}
	else if(sortBy=='subType' && orderBy=='desc')
	{
		context.setVariable("objectId", "00511");
	}
	else if(q=='payment' || q=='Payment')
	{
		context.setVariable("objectId", "00512");
	}
	else if((msisdn!=null && msisdn!='') || (q!=null && q!='') || (type!=null && type!='') || (status!=null && status!='') || (subType!=null && subType!='' && type=='billing'))
	{
		context.setVariable("objectId", "0000");
	}
	else{
 	context.setVariable("objectId", "005");
	}
}
else if(objectId=='963852' && accountId =='12345667')
{
	context.setVariable("objectId", '0032')
}
else if(objectId!='963852' && objectId!='425435' && objectId!='741852' && accountId =='12345667')
{
 	context.setVariable("objectId", "006");
}

else if(objectId=='333456' && accountId =='123123' && activityType=='billing')
{
 	context.setVariable("objectId", "001");
}
else if(objectId=='333456' && accountId =='123123' && activityType=='accountChange')
{
 	context.setVariable("objectId", "002");
}
else if(objectId=='333456' && accountId =='123123' && customerView=='true' && offset=='0' && limit=='10')
{
 	context.setVariable("objectId", "0031");
}
else if(objectId=='333456' && accountId =='123123' && customerView=='true')
{
 	context.setVariable("objectId", "003");
}

else if(objectId=='33456')
{
 	context.setVariable("objectId", "33456");
}
else if(objectId=='33348' && accountId =='123123')
{
 	context.setVariable("objectId", "33348");
}
else if(objectId=='33348' && accountId =='123123')
{
 	context.setVariable("objectId", "33348");
}
else if(objectId=='741852' && accountId =='123123789')
{
 	context.setVariable("objectId", "741852");
}
else if(objectId=='425435' && accountId =='123456678')
{
	if(customerView=='true')
	{
		 
		if((startDate!=null && startDate!='') && (endDate!=null && endDate!='')){
			if (sortBy=='activityDate' && orderBy=='desc'){
				if(offset=='0' && limit=='15'){
					context.setVariable("objectId", "425004");
				}
				else if(offset=='15' && limit=='15'){
					context.setVariable("objectId", "425005");
				}
              	
			}
			else if(sortBy=='subType' && orderBy=='asc' && hidden=='true'){
                if(type=='Billing'){ 
                  	if((q=='Payment' || q=='payment')){
                      context.setVariable("objectId", "425006");
                  	}
                  	else if(subType=='Paperless billing'){
                      context.setVariable("objectId", "425007");
                  	}
                  	else if((q!=null && q!='') || (subType!=null && subType!='')){
                  	context.setVariable("objectId", "0000");
					}
                  	else{
                      context.setVariable("objectId", "425008");
                  	}
                 }
              	else if(offset=='0' && limit=='15' && startDate=='07/01/2015' && endDate=='07/30/2015'){
					context.setVariable("objectId", "425013");
				}
				else if(offset=='0' && limit=='15'){
					context.setVariable("objectId", "425009");
				}
				else if(offset=='15' && limit=='15'){
					context.setVariable("objectId", "425010");
				}
              	else if((type!=null && type!='') || (q!=null && q!='') || (subType!=null && subType!=''))
                {
                  	context.setVariable("objectId", "0000");
				}
			}
			else if(sortBy=='subType' && orderBy=='asc'){
				if(offset=='0' && limit=='15'){
					context.setVariable("objectId", "425011");
				}
				else if(offset=='15' && limit=='15'){
					context.setVariable("objectId", "425012");
				}
              	
			}
          	
		}
      else if(offset=='0' && limit=='15'){
				context.setVariable("objectId", "425001");
			}
		else if(offset=='15' && limit=='15'){
				context.setVariable("objectId", "425002");
			} 
		else if(offset=='30' && limit=='15'){
				context.setVariable("objectId", "425003");
			}
      	

    }
	else
	{
		context.setVariable("objectId","425435else");
		}
}

else if(objectId=='425435' && accountId =='123456670')
{
 	context.setVariable("objectId", "007");
}
else if(objectId=='982333' && accountId =='123458899')
{
 	context.setVariable("objectId", "982333");
}
else if(objectId=='982564' && accountId =='123457788')
{
 	context.setVariable("objectId", "982564");
}
else{
  context.setVariable("objectId", objectId); 
  }
