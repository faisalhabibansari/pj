var limit = context.getVariable("request.queryparam.limit");
var offset = context.getVariable("request.queryparam.offset");
var filter = context.getVariable("request.queryparam.filter");
var familyId = context.getVariable("request.queryparam.familyId");
var lineId = context.getVariable("request.queryparam.lineId");
var type = context.getVariable("request.queryparam.type");


context.setVariable("dataType", 'getDeviceDetails');


if (familyId == 'IP6' || familyId == 'AP6') {
    context.setVariable("objectId", "1111");
} else if (familyId == 'IPAD6') {
    context.setVariable("objectId", "2222");
}   else if (lineId != null && filter == 'score') {
    context.setVariable("objectId", "score55554"); // scenario 2 in JSON 
} else if (lineId == null && filter == 'tablets') {
    context.setVariable("objectId", "scenario5"); // Scenario 5 in Mock_Data 
} else if (lineId == null && filter == 'phones') {
    context.setVariable("objectId", "scenario6"); // Scenario 5 in Mock_Data 
}else if (type=='tablets') {
    context.setVariable("objectId", "002"); 
}else if (lineId != null) {
    context.setVariable("objectId", "score0");
}else if (limit != null && offset != null && filter != null) {
    context.setVariable("objectId", "001");
}
else if (limit == null && offset == null && filter == null && familyId == null) {
    context.setVariable("objectId", " 12345");// same as before
}
 else {
    context.setvariable("objectId", "12345");
}
