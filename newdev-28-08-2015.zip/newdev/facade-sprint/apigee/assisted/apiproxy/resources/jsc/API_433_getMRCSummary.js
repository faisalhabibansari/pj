var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");

context.setVariable("dataType","getMRCSummary");

context.setVariable("objectId","CI_"+customerId+"_AI_"+accountId);

