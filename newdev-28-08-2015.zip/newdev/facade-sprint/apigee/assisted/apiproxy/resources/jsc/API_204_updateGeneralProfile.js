var objectId = context.getVariable("objectId");

var request_payload = '';
if (context.getVariable('request.content') != null && context.getVariable('request.content') != '')
{
	request_payload = JSON.parse(context.getVariable('request.content'));
}

var id = request_payload.id;
var phoneNumber = request_payload.phoneNumber;
var accounts = request_payload.accounts;
var language = request_payload.language;
var timeZone = request_payload.timeZone;
var firstName = request_payload.firstName;
var lastName = request_payload.lastName;

var userName = request_payload.userName;// Sprint 41
var emailAddress = request_payload.emailAddress;// Sprint 41
var securityQuestions = request_payload.securityQuestions;// Sprint 41
var nickName = request_payload.nickName;// Sprint 41
var passsword = request_payload.passsword;// Sprint 41
var pin = request_payload.pin;// Sprint 41

var addresses = request_payload.addresses;// Sprint 43

var type = request_payload.type;

context.setVariable("dataType", "updateGeneralProfile");
if (objectId == '234234234')
{
	if (addresses instanceof Array && addresses[0].addressLine1 == '1234 Sunny Ave.' && addresses[1].addressLine2 == '')
	{
		context.setVariable("objectId", "018");
	}
	else if (id == '234234234' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 2
			&& request_payload.linkedNumbers[0].msisdn == '5554567890')
	{
		context.setVariable("objectId", "029");
	}
	else if (id == '234234234' && request_payload.accounts instanceof Array && request_payload.accounts[0].currentDueDate !== null
			&& request_payload.accounts[0].currentDueDate === '05/17/2015')
	{
		context.setVariable("objectId", "48");
	}

	else if (id == '234234234' && request_payload.accounts instanceof Array && request_payload.accounts.length == 1
			&& request_payload.accounts[0].lines[0].msisdn == '2061234567')
	{
		context.setVariable("objectId", "030");
	}
	else if (id == '234234234' && request_payload.accounts instanceof Array && request_payload.accounts.length == 1
			&& request_payload.accounts[0].id == '123123') // Condition17
	{
		context.setVariable("objectId", "031");
	}

}
else if (id == '234234234')
{
	if (phoneNumber == '7325568899')
	{
		context.setVariable("objectId", "001");
	}

	else if (firstName == 'John' && lastName == 'Doe')
	{
		context.setVariable("objectId", "002");
	}
	else if (timeZone != null && timeZone.code == '2')
	{
		context.setVariable("objectId", "003");
	}
	else if ((language != '' && accounts != '') && (language != null && accounts != null))
	{
		context.setVariable("objectId", "004");
	}
	/* else if(accounts!=''&& accounts!=null)
	{
	  if(accounts[0].lines[0].nickName=='New Name')
	  {
	  context.setVariable("objectId", "005");
	  }
	  else
	  {
	   context.setVariable("objectId", "006");
	  }
	}*/
	else if (accounts != '' && accounts != null && language == null)
	{
		if (accounts instanceof Array && accounts[0].lines instanceof Array)
		{
			if (accounts[0].lines.length == 1)
			{
				if (accounts[0].lines[0].nickName == 'New Name')
				{
					context.setVariable("objectId", "005");
				}
				else if (accounts[0].lines[0].addresses instanceof Array)
				{
					context.setVariable("objectId", "006");
				}
				else if (accounts[0].lines[0].language != null)
				{
					context.setVariable("objectId", "015");
				}

			}
			else if (accounts[0].lines.length == 2)
			{
				if (accounts[0].lines[0].id == '2061234567' && accounts[0].lines[0].lineDesignation != null
						&& accounts[0].lines[1].id == '6021234511' && accounts[0].lines[1].lineDesignation != null)
				{
					context.setVariable("objectId", "014");
				}
				else if (accounts[0].lines[0].id == '2061234567' && accounts[0].lines[0].billDeliveryMethod != null
						&& accounts[0].lines[1].id == '6021234511' && accounts[0].lines[1].billDeliveryMethod != null)
				{
					context.setVariable("objectId", "016");
				}
			}
		}
	}

	else if (language != '' && language != null && language.code == "2")
	{
		context.setVariable("objectId", "007");
	}
	else if (userName == 'JohnSmith')
	{
		context.setVariable("objectId", "008");
	}
	else if (emailAddress == 'JohnSmith@gmail.com')
	{
		context.setVariable("objectId", "009");
	}
	else if (securityQuestions != '' && securityQuestions != null)
	{
		context.setVariable("objectId", "010");
	}
	else if (nickName == 'My NickName PC - new')
	{
		context.setVariable("objectId", "011");
	}
	else if (passsword == 'Test12345' && pin == '3456')
	{
		context.setVariable("objectId", "012");
	}
	else if (addresses[0].addressLine1 != '' && addresses[0].addressLine1 != '123ppuSt')
	{
		context.setVariable("objectId", "013");
	}
	else if (addresses[0].addressLine1 == '' && addresses[0].addressLine2 == '')
	{
		context.setVariable("objectId", "017");
	}

}

else if (objectId == '0')
{
	if (addresses.addressLine1 == '1234 Sunny Ave.' && addresses.addressLine2 == '')
	{
		context.setVariable("objectId", "019");
	}
	else if (addresses.type == 'Shipping' && addresses.addressLine1 == '' && addresses.addressLine2 == '')
	{
		context.setVariable("objectId", "0");
	}

}
else if (objectId == '7777777')
{
	if (addresses.addressLine1 == '1234 Sunny Ave.' && addresses.addressLine2 == '')
	{
		context.setVariable("objectId", "020");
	}
	else
	{
		context.setVariable("objectId", "023");
	}
}
else if (objectId == '234236000')
{
	if (id == '234236000' && request_payload.customerType == 'Applicant')
	{
		context.setVariable("objectId", "022");
	}
	else if (id = '234236000' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '5551234568')
	{
		context.setVariable("objectId", "025");
	}
	else if (id = '234236000' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 3
			&& request_payload.linkedNumbers[0].msisdn == '5554567890')
	{
		context.setVariable("objectId", "026");
	}
}
else if (objectId == '234236001')
{
	if (id == '234236001' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '5551234575')
	{
		context.setVariable("objectId", "027");
	}
}
else if (objectId == '234236002')
{
	if (id == '234236002' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '5551234568')
	{
		context.setVariable("objectId", "028");
	}
}
else if (objectId == '425435')
{
	if (id == '425435' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '5551234575')
	{
		context.setVariable("objectId", "032");
	}
	else if (id == '425435' && request_payload.contactPhoneNumber == '4254357789')
	{
		context.setVariable("objectId", "047");
	}
}
else if (objectId == '12345')
{
	context.setVariable("objectId", "024");
}
else if (objectId == '963853')
{
	if (id == '963853' && request_payload.contactPhoneNumber == '2061231234')
	{
		context.setVariable("objectId", "048");
	}
}

// For QAT
if (objectId == '3000000028')
{
	if (id == '3000000028' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '2172209130')
	{
		context.setVariable("objectId", "656");
	}
}
else if (objectId == '3000000031')
{
	if (id == '3000000031' && request_payload.linkedNumbers instanceof Array && request_payload.linkedNumbers.length == 1
			&& request_payload.linkedNumbers[0].msisdn == '2172209135')
	{
		context.setVariable("objectId", "656");
	}
}
else if (objectId == '3000000032')
{
	context.setVariable("objectId", "035");
}

else if (objectId == '3000000033')
{
	context.setVariable("objectId", "036");
}

else if (objectId == '3000000034')
{
	context.setVariable("objectId", "037");
}

else if (objectId == '3000000007')
{
	context.setVariable("objectId", "038");
}

else if (objectId == '3000000008')
{
	context.setVariable("objectId", "039");
}

else if (objectId == '3000000050')
{
	context.setVariable("objectId", "040");
}

else if (objectId == '3000000035')
{
	context.setVariable("objectId", "041");
}

else if (objectId == '3000000036')
{
	context.setVariable("objectId", "042");
}

else if (objectId == '3000000037')
{
	context.setVariable("objectId", "043");
}

else if (objectId == '3000000038')
{
	context.setVariable("objectId", "044");
}

else if (objectId == '3000000039')
{
	context.setVariable("objectId", "045");
}

else if (objectId == '3000000041')
{
	context.setVariable("objectId", "046");
}