var type=context.getVariable("request.queryparam.type");
context.setVariable("dataType","getRoles");

if(type=='customer'){
  context.setVariable("objectId", "001");}  
    
    else if(type=='rep'){
        context.setVariable("objectId", "002");  
    }
else {
  context.setVariable("objectId","12345");
}
