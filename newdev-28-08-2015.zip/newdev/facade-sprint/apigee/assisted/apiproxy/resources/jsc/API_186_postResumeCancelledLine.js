var reqPayLoad = context.targetRequest.body.asJSON
var JSON_STRING = JSON.stringify(reqPayLoad);

var customerId=context.getVariable("customerId");
if(reqPayLoad.resumption.accounts instanceof Array)
{
	var lines=reqPayLoad.resumption.accounts[0].lines;
}


context.setVariable("dataType","postResumeCancelledLine");

if(reqPayLoad!=null)
{	
    if(lines.length==3)
    {
    	context.setVariable("objectId","CI_"+customerId+"_ID1_"+lines[0].id+"_ID2_"+lines[1].id+"_ID3_"+lines[2].id);
    }
    else if(lines.length==2)
    {
    	context.setVariable("objectId","CI_"+customerId+"_ID1_"+lines[0].id+"_ID2_"+lines[1].id);
    }
    else if(lines.length==1)
    {
    	context.setVariable("objectId","CI_"+customerId+"_ID1_"+lines[0].id);
    }
}

