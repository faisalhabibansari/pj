var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postOverrideAuthorization");
if(reqPayLoad!=null && reqPayLoad!='' && reqPayLoad.overrideReason=='Manager Discretion' && reqPayLoad.userName=='manger1' && reqPayLoad.password=='Passw0rd')
  {
context.setVariable("objectId","001");
}
else
  {
context.setVariable("objectId","002");
} 