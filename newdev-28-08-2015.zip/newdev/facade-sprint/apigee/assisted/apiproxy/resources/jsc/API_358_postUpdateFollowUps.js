var reqPayLoad = context.targetRequest.body.asJSON
// var repId = context.getVariable("repId");
var token = context.getVariable('request.header.token')
context.setVariable("dataType", "postUpdateFollowUps");

if (reqPayLoad != null && reqPayLoad != '' && (token == '00x34frsdc' || token == 'fx00wmdlxw0'))
{
	context.setVariable("objectId", "001");
}
else
{
	context.setVariable("objectId", "000");
}