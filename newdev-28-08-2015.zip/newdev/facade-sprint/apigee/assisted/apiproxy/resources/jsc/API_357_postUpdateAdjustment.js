var type = context.getVariable("request.queryparam.type");
var token = context.getVariable('request.header.token')

var request_payload = '';
if (context.getVariable('request.content') != null && context.getVariable('request.content') != '')
{
	request_payload = JSON.parse(context.getVariable('request.content'));
}

context.setVariable('dataType', 'postUpdateAdjustment');

if ((request_payload != null) && (token == '00x34frsdc' || token == 'fx00wmdlxw0'))
{
	if (request_payload.subType == 'credit')
	{
		context.setVariable("objectId", "001");
	}
	else if (request_payload.subType == 'adjustment')
	{
		context.setVariable("objectId", "002");
	}
	else
	{
		context.setVariable("objectId", "000");
	}
}
else
{
	context.setVariable("objectId", "000");
}