/**

Purpose: Script to return rep mock profile data for given repNTId from BaaS.

Developer: Supriya.Datta4@T-Mobile.com

Revisions: 15 June 2015 | Added Script
  
**/

//Get request content from context
if(context.getVariable('request.content')!=''){
	var request_content = context.getVariable('request.content');  
}

context.setVariable('code', context.getVariable('code'));

//Get tmobileid from context extracted from request content
var repNTId = context.getVariable('code');

//Make call to Bass to retrive profile data based on tmobileid passed
var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='postMockRepProfile_updated' and id='" + repNTId + "'";
 

var headers = {'Content-Type' : 'application/json'};
var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);
req.waitForComplete();		

  if (req.isSuccess()) {          
     mockData = req.getResponse().content.asJSON;
     var profileObject = mockData.entities[0].mockData;
     context.proxyResponse.content = JSON.stringify(profileObject);
  }
  else
  {
      throw new Error("Did not find mock data.");
  }