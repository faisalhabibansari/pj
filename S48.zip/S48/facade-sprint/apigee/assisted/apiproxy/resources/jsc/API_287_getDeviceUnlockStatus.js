var imei = context.proxyRequest.queryParams['imei'];
var customerId = context.getVariable("customerID");
//context.setVariable("imei", imei);
context.setVariable("dataType", "getDeviceUnlockStatus");


if(imei=='012345678905555'){
  context.setVariable("objectId",'012345678905555');
  }
else if (customerId =='0123456789' && imei=='012345678901231'){
  context.setVariable("objectId",'012345678901231');
  }
else if(customerId =='0123456789' && imei=='0123456789012312'){
  context.setVariable("objectId",'0123456789012312');
  }
else if(customerId =='0123456789' && imei=='012345678901234'){ 
  context.setVariable("objectId",'012345678901234'); 
  }
else if(customerId =='0123456789' && imei=='012345678901235'){ 
  context.setVariable("objectId",'012345678901235'); 
  }
else if(customerId =='1234' && imei=='012345678901235'){ 
  context.setVariable("objectId",'002'); 
  }
else if(customerId =='0123456789' && imei=='0123456789012346'){ 
  context.setVariable("objectId",'0123456789012346'); 
  }
else if(customerId =='33348' && imei=='012345678901233'){ 
  context.setVariable("objectId",'012345678901233'); 
  }
else if(customerId =='33348' && imei=='012345678901231'){ 
  context.setVariable("objectId",'0123456789012311'); 
  }
else if(customerId =='33348' && imei=='012345678901235'){ 
  context.setVariable("objectId",'0123456789012355'); 
  }
else if(customerId =='33348' && imei!='012345678901233' && imei!='012345678901231' && imei!='012345678901235'){ 
  context.setVariable("objectId",'001'); 
  }
else if(customerId =='1234' && imei=='012345678901231'){ 
  context.setVariable("objectId",'1234'); 
  }
else if(customerId =='1234' && imei=='012345678901232'){ 
  context.setVariable("objectId",'012345678901232'); 
  }
else if(customerId =='1234' && imei=='012345678901236'){ 
  context.setVariable("objectId",'012345678901236'); 
  }
else if(customerId =='1234' && imei=='012345678901242'){ 
  context.setVariable("objectId",'012345678901242'); 
  }
else if(customerId =='1234' && imei=='012345678901245'){ 
  context.setVariable("objectId",'012345678901245'); 
  }
else if(customerId =='1234' && imei=='012345678901246'){ 
  context.setVariable("objectId",'012345678901246'); 
  }
else if(customerId =='1234' && imei=='012345678901247'){ 
  context.setVariable("objectId",'012345678901247'); 
  }
else if(customerId =='1234' && imei=='012345678901250'){ 
  context.setVariable("objectId",'012345678901250'); 
  }
else if(customerId =='1234' && imei=='012345678901240'){ 
  context.setVariable("objectId",'012345678901240'); 
  }
else if(customerId =='1234' && imei=='012345678901299'){ 
  context.setVariable("objectId",'012345678901299'); 
  }
else if(customerId =='1234' && imei=='012345678901222'){ 
  context.setVariable("objectId",'012345678901222'); 
  }
else if(customerId =='9876543210' && imei=='012345678901231'){ 
  context.setVariable("objectId",'scenario36'); 
  }
else if(customerId =='9876543210' && imei=='012345678901232'){ 
  context.setVariable("objectId",'scenario37'); 
  }
else if(customerId!=null && customerId!=''&& customerId!='33348' && imei!='012345678905555'&& imei!='012345678901234' && imei!='012345678901235'
  && imei!='012345678901231' && imei!='0123456789012312' && imei!='0123456789012346' && imei!='012345678901233'){
                context.setVariable("objectId",customerId); 
}