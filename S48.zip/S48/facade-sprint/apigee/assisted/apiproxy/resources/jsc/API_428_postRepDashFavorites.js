var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postRepDashFavorites");

if(reqPayLoad!=null)
{
  if(reqPayLoad.repId=="" && reqPayLoad.actionCode=="add/remove")
  {
    context.setVariable("objectId","001");
  }
  else
  {
   context.setVariable("objectId","000");
  }
}
else
{
  context.setVariable("objectId","000");
}