var zipCode=context.getVariable("request.queryparam.zipCode");
var areaCode=context.getVariable("request.queryparam.areaCode");
var exchangeCode=context.getVariable("request.queryparam.exchangeCode");
var limit=context.getVariable("request.queryparam.limit");

if(areaCode=='206')
{
  if(exchangeCode=='338')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='315')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='412')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='496')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='884')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='250')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='404')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='898')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='533')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='579')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='842')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='463')
  {
  context.setVariable("objectId",exchangeCode);
  }
}
else if(areaCode=='425')
{
  if(exchangeCode=='603')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='985')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='753')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='516')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='466')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='898')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='945')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='836')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='216')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='201')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='202')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='218')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='225')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='233')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='235')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='258')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='292')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='310')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='491')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='557')
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(exchangeCode=='435' & limit=='1')
  {
  context.setVariable("objectId",exchangeCode);
  }
  
}





/*
if(zipCode!=null&&areaCode==null&&exchangeCode==null)
{
 context.setVariable("objectId",zipCode);
}
else if(zipCode==null&&areaCode!=null&&exchangeCode==null)
{
context.setVariable("objectId",areaCode);
}
else if(zipCode==null&&areaCode!=null&&exchangeCode!=null)
{
  if((areaCode==206||areaCode==425) && exchangeCode!=898)
  {
  context.setVariable("objectId",exchangeCode);
  }
  else if(areaCode==425 && exchangeCode==898){
    context.setVariable("objectId",exchangeCode);}
 else if(areaCode==206 && exchangeCode==898){
      context.setVariable("objectId","206898");
 }
} */