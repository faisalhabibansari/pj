var token = context.getVariable('request.header.token')

context.setVariable("dataType",'MemoDefaultData');

if(token=='gx0qdkdds32')
{
context.setVariable("objectId", "002");
}
else
{
context.setVariable("objectId", "000");
}
