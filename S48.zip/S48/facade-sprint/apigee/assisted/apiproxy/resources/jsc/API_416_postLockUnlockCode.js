var reqPayLoad = context.targetRequest.body.asJSON;

var orderId = context.getVariable("orderId");

context.setVariable("dataType","postLockUnlockCode");
if(reqPayLoad!=null)
{
  if(orderId=="4599019" && reqPayLoad.actionCode=="LOCK")
  {
   context.setVariable("objectId","002");
  }
  else if(orderId=="4399016" && reqPayLoad.actionCode=="LOCK")
  {
   context.setVariable("objectId","003");
  }
  else if(orderId=="4599019" && reqPayLoad.actionCode=="UNLOCK")
  {
   context.setVariable("objectId","004");
  }
  else if(orderId=="4399016" && reqPayLoad.actionCode=="UNLOCK")
  {
   context.setVariable("objectId","005");
  }
  else if(orderId=="4399015" && reqPayLoad.actionCode=="LOCK")
  {
   context.setVariable("objectId","006");
  }
  else if(orderId=="4399015" && reqPayLoad.actionCode=="UNLOCK")
  {
   context.setVariable("objectId","007");
  }
}
   