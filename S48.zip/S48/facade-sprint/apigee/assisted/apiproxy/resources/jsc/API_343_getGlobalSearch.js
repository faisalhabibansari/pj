var q=context.getVariable("request.queryparam.q"); 
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");

context.setVariable("dataType","getGlobalSearch");

if(q == "Galaxy S5" && limit == null) { 
context.setVariable('objectId', '001'); 
} 
if(q == "Galaxi S5" && limit == null) { 
context.setVariable('objectId', '002'); 
} 
if(q == "Galaxy S5" && limit =="9" && offset == "1") { 
context.setVariable('objectId', '003'); 
} 
if(q == "Galaxi S5" && limit =="9" && offset == "1") { 
context.setVariable('objectId', '004'); 
} 
if(q == "Galaxy S5" && limit =="9" && offset == "2") { 
context.setVariable('objectId', '005'); 
}
if(q == "Galaxi S5" && limit =="9" && offset == "2") { 
context.setVariable('objectId', '006'); 
} 
if(q == "Galaxy S5" && limit =="9" && offset == "3") { 
context.setVariable('objectId', '007'); 
} 
if(q == "Galaxi S5" && limit =="9" && offset == "3") { 
context.setVariable('objectId', '008'); 
} 
