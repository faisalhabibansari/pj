var q=context.getVariable("request.queryparam.q");
var customerId=context.getVariable("request.queryparam.customerId");
context.setVariable("dataType","getAutoSuggest");
if(q=='gal' && customerId=='12345') {
   context.setVariable('objectId', customerId);
}
else if(q=='ga') {
   context.setVariable('objectId', "123");
}
if(q=='gal' && customerId==null) {
   context.setVariable('objectId', "003");
}