var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");
var filter=context.getVariable("request.queryparam.filter");

context.setVariable("dataType","getCallHistory");

if (accountId == '12341234') {
 context.setVariable("objectId", "12341234");
}
else if (accountId=='55555' && sort=='date' && filter==undefined)
{
 context.setVariable("objectId", "003");
}
else if(accountId=='55555' && sort=='duration' && filter==undefined)
{
 context.setVariable("objectId","004");
}
else if(accountId=='55555' && sort=='cost')
{
 context.setVariable("objectId","005");
}
else if(accountId=='55555' && sort=='duration')
{
 context.setVariable("objectId","006");
}
else if(accountId=='55555' && sort=='date')
{
 context.setVariable("objectId","007");
}
else if(accountId=='55555')
{
 context.setVariable("objectId","55555");
}
else {
  context.setVariable("objectId",customerId);
}