var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
var filter=context.getVariable("request.queryparam.filter");
var line=context.getVariable("request.queryparam.line");
var startDate=context.getVariable("request.queryparam.startDate");
var endDate=context.getVariable("request.queryparam.endDate");
var category=context.getVariable("request.queryparam.category");
var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");
var usageType=context.getVariable("request.queryparam.usageType");
var type=context.getVariable("request.queryparam.type");
var amount=context.getVariable("request.queryparam.amount");
var paymentMethod=context.getVariable("request.queryparam.paymentMethod");
var paymentInfo=context.getVariable("request.queryparam.paymentInfo");

context.setVariable("dataType","getTransactionHistory");
    
    /*if(customerId=='982333' && reqPayLoad.requestId=='123458899')
    {
        context.setVariable("objectId","001");
    }
   else if(customerId=='982564' && reqPayLoad.requestId=='123457788')
    {
        context.setVariable("objectId","002");
    } */
    
    
    if(customerId=='982564' && accountId=='123457788' && filter==',sort=date,sortOrder=desc,limit=50,offset=50')
    {
        context.setVariable("objectId","005");
    }
    else if(customerId=='982564' && accountId=='123457788' && filter==',sort=date,sortOrder=desc,limit=50,offset=0')
    {
         context.setVariable("objectId","006");
    }
    else if(customerId=='982333' && accountId=='123458899' && filter==',sort=date,sortOrder=desc,limit=50,offset=0')
    {
        context.setVariable("objectId","007");
    }
    else if(customerId=='982333' && accountId=='123458899' && filter==',sort=date,sortOrder=desc,limit=50,offset=50')
    {
         context.setVariable("objectId","008");
    }
else if(customerId=='982333' && accountId=='123458899' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && type=='Refill' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","012");
    }
    
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","009");
    }
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234' && startDate=='05/01/2015' && endDate=='07/01/2015' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","027");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234' && category=='Charges' && type=='Domestic Usages,International Usage' && usageType=='voice' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {   
             context.setVariable("objectId","033");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='6021234577' && category=='Charges' && type=='Domestic Usages,International Usage' && usageType=='voice' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","034");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='6021234577' && category=='Charges' && type=='Domestic Usages,International Usage' && usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","035");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234' && category=='Charges' && type=='Domestic Usages,International Usage' && usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","036");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","028");
        }
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234,6021234577' && startDate=='05/01/2015' && endDate=='07/01/2015' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
        {
             context.setVariable("objectId","029");
        }
    
    else if(customerId=='982333' && accountId=='123458899' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","013");
    }
    else if(customerId=='982333' && accountId=='123458899' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","010");
    }
    else if(customerId=='982333' && accountId=='123458899' && amount=='10' && paymentMethod=='Credit' && paymentInfo=='1234' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
        context.setVariable("objectId","037");
    }
    else if(customerId=='982333' && accountId=='123458899' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","011");
    }
    else if(customerId=='982564' && accountId=='123457788' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","014");
    }
    else if(customerId=='982564' && accountId=='123457788' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","015");
    }
else if(customerId=='982333' && accountId=='123458899' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","016");
    }
else if(customerId=='982333' && accountId=='123458899' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","017");
    }

else if(customerId=='425435' && accountId=='123456678' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && type=='Refill' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","022");
    }
else if(customerId=='425435' && accountId=='123456678' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","023");
    }
else if(customerId=='425435' && accountId=='123456678' && line=='4251231234,6021234577,6354781111,5634238367' && startDate=='05/01/2015' && endDate=='07/01/2015' && category=='Payments,Charges' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","024");
    }
else if(customerId=='425435' && accountId=='123456678' && line=='4251231234,6021234577'&& startDate=='05/01/2015' && endDate=='07/01/2015' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","031");
    }
else if(customerId=='425435' && accountId=='123456678' && startDate=='05/01/2015' && endDate=='07/01/2015' && line=='4251231234'&& sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","032");
    }
else if(customerId=='425435' && accountId=='123456678' && line=='4251231234'&& sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","030");
    }

else if(customerId=='425435' && accountId=='123456678' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","018");
    }
else if(customerId=='425435' && accountId=='123456678' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='0')
    {
         context.setVariable("objectId","019");
    }
else if(customerId=='425435' && accountId=='123456678' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","020");
    }
else if(customerId=='425435' && accountId=='123456678' && sort=='amount' && sortOrder=='desc' && limit=='50' && offset=='50')
    {
         context.setVariable("objectId","021");
    }

else if(customerId=='982333' && accountId=='123458899')
    {
        context.setVariable("objectId","003");
    }
else if(customerId=='982564' && accountId=='123457788')
     {
          context.setVariable("objectId","004");
     }
    
    else
    {
     context.setVariable("objectId","000");
    } 
