/*var reqPayLoad = context.targetRequest.body.asJSON;

var accountId = context.getVariable("accountId");

if(reqPayLoad!=null && reqPayLoad.MSISDN=='3212524095' && accountId=='20131010398547') { 
  
  context.setVariable("objectId", accountId);
  context.setVariable("dataType", "reportingLostStolenDevice");
}
*/



var reqPayLoad = context.targetRequest.body.asJSON;

//var accountId = context.getVariable("accountId");

if(
 (reqPayLoad!=null && reqPayLoad.MSISDN=='4254356547') || (reqPayLoad!=null && reqPayLoad.MSISDN=='4254357654') || (reqPayLoad!=null && reqPayLoad.MSISDN=='4251234567') || (reqPayLoad!=null && reqPayLoad.MSISDN=='3212524095')||(reqPayLoad!=null && reqPayLoad.MSISDN=='2061234567')||(reqPayLoad!=null && reqPayLoad.MSISDN=='2061233333'))
{ 
  
  context.setVariable("objectId", '20131010398547');
  context.setVariable("dataType", "reportingLostStolenDevice");
}


