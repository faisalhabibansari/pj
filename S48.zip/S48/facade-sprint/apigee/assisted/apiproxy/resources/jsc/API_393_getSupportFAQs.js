var category=context.getVariable("request.queryparam.category"); 
context.setVariable("dataType","supportfaqs");
if(category!= null && category=='device')
{
context.setVariable("objectId","001");
}
else
{
context.setVariable("objectId","002");
}  