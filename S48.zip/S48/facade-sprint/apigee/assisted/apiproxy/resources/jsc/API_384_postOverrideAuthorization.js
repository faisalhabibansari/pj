var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postOverrideAuthorization");
if(reqPayLoad!=null && reqPayLoad!='' && reqPayLoad.overrideReason=='Managed Discretion' && reqPayLoad.userName=='jwalker123' && reqPayLoad.password=='Test123')
  {
context.setVariable("objectId","001");
}
else
  {
context.setVariable("objectId","002");
}