context.setVariable("objectId","12345");
context.setVariable("dataType","getRoles");