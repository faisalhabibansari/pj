var simnumber= context.getVariable("simnumber");
  context.setVariable("dataType","getSimDetails");
	if(simnumber!=null && simnumber!='') {
		context.setVariable("objectId", simnumber); 
    }