var cardNumber = context.targetRequest.body.asJSON.refillCard.cardNumber

context.setVariable('dataType', 'validatePrepaidRefillCard');

/*if(cardNumber != null && cardNumber =='3333444455556'){
  context.setVariable("objectId", "2061123456");
}else 
{
  context.setVariable("objectId", "2061123467");
}*/

if(cardNumber != null && cardNumber =='3333444455556'){
  context.setVariable("objectId", "2061123456");
}else if(cardNumber != null && cardNumber =='3333444455557')
{
  context.setVariable("objectId", "2061123477");
}else if(cardNumber != null && cardNumber =='3333444455558')
{
  context.setVariable("objectId", "2061123468");
}else if(cardNumber != null && cardNumber =='3333444455559')
{
  context.setVariable("objectId", "2061123469");
}else if(cardNumber != null && cardNumber =='3333444455550')
{
  context.setVariable("objectId", "2061123460");
}else if(cardNumber != null && cardNumber =='3333444455551')
{
  context.setVariable("objectId", "2061123461");
}else if(cardNumber != null && cardNumber =='3333444455552')
{
  context.setVariable("objectId", "2061123462");
}else if(cardNumber != null && cardNumber =='3333444455553')
{
  context.setVariable("objectId", "2061123463");
}else if(cardNumber != null && cardNumber =='3333444455554')
{
  context.setVariable("objectId", "2061123464");
}else if(cardNumber != null && cardNumber =='3333444455555')
{
  context.setVariable("objectId", "2061123465");
}
else 
{
  context.setVariable("objectId", "2061123467");
}
