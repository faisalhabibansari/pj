var reqPayLoad = context.targetRequest.body.asJSON
var cartId = reqPayLoad.cartId;

context.setVariable("cartId",cartId);

context.setVariable("dataType","TermsConditions");
context.setVariable("objectId",cartId);
