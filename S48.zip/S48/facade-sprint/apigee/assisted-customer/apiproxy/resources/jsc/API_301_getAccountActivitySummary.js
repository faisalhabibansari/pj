var objectId = context.getVariable("objectId");
var accountId = context.getVariable("accountId");
var activityType=context.getVariable("request.queryparam.activityType");
var customerView=context.getVariable("request.queryparam.customerView");
var startDate=context.getVariable("request.queryparam.startDate");
var endDate=context.getVariable("request.queryparam.endDate");
var msisdn=context.getVariable("request.queryparam.msisdn");
var status=context.getVariable("request.queryparam.status");
var type=context.getVariable("request.queryparam.type");
var subType=context.getVariable("request.queryparam.subType");
var sortBy=context.getVariable("request.queryparam.sortBy");
var orderBy=context.getVariable("request.queryparam.orderBy");
var q=context.getVariable("request.queryparam.q");
var hidden=context.getVariable("request.queryparam.hidden");

if(accountId=='432432432')
{
context.setVariable("objectId", "432432432");
}
else if(objectId=='12345' && accountId =='123123')
{
 	context.setVariable("objectId", "12345");
}
else if(objectId=='753869' && accountId =='12345667')
{
 	context.setVariable("objectId", "004");
}
else if(objectId=='963852' && accountId =='123456670')
{
	if(customerView=='true')
	{
		if(type=='Services' && subType=='New feature' && msisdn=='4251234568' && startDate=='04/01/2015' && endDate=='04/10/2015')
		{
			context.setVariable("objectId", "0055");
		}
		else if(q=='payment' || q=='Payment')
		{
			context.setVariable("objectId", "00521");
		}
		else if(sortBy=='subType' && orderBy=='asc')
		{
			context.setVariable("objectId", "00522");
		}
      else if(sortBy=='subType' && orderBy=='desc')
		{
			context.setVariable("objectId", "00524");
		}
		else if(msisdn=='2061231234' && hidden=='true')
		{
			context.setVariable("objectId", "00525");
		}
		else if(type=='Billing')
		{
			context.setVariable("objectId", "00523");
		}
		else if((msisdn!=null && msisdn!='') || (q!=null && q!='') || (type!=null && type!='') || (status!=null && status!='') || (subType!=null && subType!='' && type=='billing'))
		{
		context.setVariable("objectId", "0000");
		}
		else
		{
		context.setVariable("objectId", "0052");
		}
	}
	else if(msisdn=='2061231234' && hidden=='true')
	{
		context.setVariable("objectId", "00513");
	}
	else if(msisdn=='2061231234')
	{
		context.setVariable("objectId", "0053");
	}
	else if(startDate=='04/30/2015' && endDate=='04/30/2015')
	{
		context.setVariable("objectId", "00515");
	}
	else if(status=='Received')
	{
		context.setVariable("objectId", "0054");
	}
	else if(type=='Billing' && subType=='Paperless billing')
	{
		context.setVariable("objectId", "0057");
	}
	else if(type=='Billing' && (q=='payment' || q=='Payment'))
	{
		context.setVariable("objectId", "00514");
	}
	else if(type=='Billing' && subType==null)
	{
		context.setVariable("objectId", "0056");
	}
	
	else if(sortBy=='subType' && orderBy=='asc')
	{
		context.setVariable("objectId", "0058");
	}
	else if(sortBy=='activityDate' && orderBy=='asc')
	{
		context.setVariable("objectId", "0059");
	}
 	else if(sortBy=='activityDate' && orderBy=='desc')
	{
		context.setVariable("objectId", "00516");
	}
	else if(sortBy=='subType' && orderBy=='desc')
	{
		context.setVariable("objectId", "00511");
	}
	else if(q=='payment' || q=='Payment')
	{
		context.setVariable("objectId", "00512");
	}
	else if((msisdn!=null && msisdn!='') || (q!=null && q!='') || (type!=null && type!='') || (status!=null && status!='') || (subType!=null && subType!='' && type=='billing'))
	{
		context.setVariable("objectId", "0000");
	}
	else{
 	context.setVariable("objectId", "005");
	}
}
else if(objectId!='963852' && objectId!='425435' && objectId!='741852' && accountId =='12345667')
{
 	context.setVariable("objectId", "006");
}
else if(objectId=='33456')
{
 	context.setVariable("objectId", "33456");
}
else if(objectId=='333456' && accountId =='123123' && activityType=='billing')
{
 	context.setVariable("objectId", "001");
}
else if(objectId=='333456' && accountId =='123123' && activityType=='accountChange')
{
 	context.setVariable("objectId", "002");
}
else if(objectId=='333456' && accountId =='123123' && customerView=='true')
{
 	context.setVariable("objectId", "003");
}
else if(objectId=='33348' && accountId =='123123')
{
 	context.setVariable("objectId", "33348");
}
else if(objectId=='33348' && accountId =='123123')
{
 	context.setVariable("objectId", "33348");
}
else if(objectId=='741852' && accountId =='123123789')
{
 	context.setVariable("objectId", "741852");
}
else if(objectId=='425435' && accountId =='123456678')
{
	if(customerView=='true')
	{
		if(sortBy=='subType' && orderBy=='asc')
		{
			context.setVariable("objectId", "4001");
		}
		else if(sortBy=='subType' && orderBy=='desc')
		{
			context.setVariable("objectId", "4003");
		}
		else if(type=='Billing' && subType=='Paperless billing')
		{
			context.setVariable("objectId", "4004");
		}
		else if(type=='Billing' && (q=='payment' || q=='Payment'))
		{
			context.setVariable("objectId", "4006");
		}
		else if(type=='Billing')
		{
			context.setVariable("objectId", "4005");
		}
     	else if(q=='payment' || q=='Payment')
		{
			context.setVariable("objectId", "4002");
		}
		else if((msisdn!=null && msisdn!='') || (q!=null && q!='') || (type!=null && type!='') || (status!=null && status!='') || (subType!=null && subType!='' && type=='billing'))
		{
		context.setVariable("objectId", "0000");
		}
	}
	else
	{
 	context.setVariable("objectId", "425435");
	}
}
else if(objectId=='425435' && accountId =='123456670')
{
 	context.setVariable("objectId", "007");
}
else if(objectId=='982333' && accountId =='123458899')
{
 	context.setVariable("objectId", "982333");
}
else if(objectId=='982564' && accountId =='123457788')
{
 	context.setVariable("objectId", "982564");
}
else{
  context.setVariable("objectId", objectId); 
  }
