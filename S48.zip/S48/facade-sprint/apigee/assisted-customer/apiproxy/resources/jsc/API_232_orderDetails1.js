var groupBy=context.getVariable("request.queryparam.groupBy");
var objectId = context.getVariable("objectId");
if(groupBy==null)
{
context.setVariable("objectId",objectId);
}
else if(groupBy!=null && objectId=='orderId')
{
context.setVariable("objectId","12345");
}
else if(groupBy!=null && objectId=='4399010')
{
context.setVariable("objectId","12346");
}
else if(groupBy!=null && objectId=='4399011')
{
context.setVariable("objectId","12347");
}
else if(groupBy!=null && objectId=='4399012')
{
context.setVariable("objectId","12348");
}
else if(groupBy!=null && objectId=='4399013')
{
context.setVariable("objectId","12349");
}
else if(groupBy!=null && objectId=='4399014')
{
context.setVariable("objectId","12350");
}
else if(groupBy!=null && objectId=='4399015')
{
context.setVariable("objectId","12351");
}
else if(groupBy!=null && objectId=='4399111')
{
context.setVariable("objectId","12352");
}
else if(groupBy!=null && objectId=='4399016')
{
context.setVariable("objectId","12353");
}
else if(groupBy!=null && objectId=='4599017')
{
context.setVariable("objectId","12354");
}
else if(groupBy!=null && objectId=='4599018')
{
context.setVariable("objectId","12355");
}
else if(groupBy!=null && objectId=='4599019')
{
context.setVariable("objectId","12356");
}
else if(groupBy!=null && objectId=='4599020')
{
context.setVariable("objectId","12357");
}
else if(groupBy=='line' && objectId=='12341234123412341234123412341234')
{
context.setVariable("objectId","001");
}
else if(groupBy=='line' && objectId=='87654321876543218765432187654321')
{
context.setVariable("objectId","002");
}
else if(groupBy=='line' && objectId=='12345678123456781234567812345678')
{
context.setVariable("objectId","003");
}
else
{
context.setVariable("objectId","000");
}