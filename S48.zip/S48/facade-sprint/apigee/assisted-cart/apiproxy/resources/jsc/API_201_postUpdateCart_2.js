var id = context.getVariable("objectId");
var reqPayLoad = context.targetRequest.body.asJSON;

var requestJSON = '';

if(reqPayLoad!=null&&reqPayLoad!='') {
	requestJSON = JSON.stringify(reqPayLoad);
}

/*if(id!=null && id == '7780') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
	{
		if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1) 
		 {
				context.setVariable("objectId","103");
		 }
	}
}*/
if(id!=null && id == '1509') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
	  {
		if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234567") != -1) 
		 {
				context.setVariable("objectId","0041");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456670") != -1) 
		 {
				context.setVariable("objectId","0044");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456678") != -1) 
		 {
				context.setVariable("objectId","0042");
		 }
        else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1 && requestJSON.indexOf("4251234571") != -1) 
		 {
				context.setVariable("objectId","103");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1) 
		 {
				context.setVariable("objectId","0043");
         }
        
	 }
}