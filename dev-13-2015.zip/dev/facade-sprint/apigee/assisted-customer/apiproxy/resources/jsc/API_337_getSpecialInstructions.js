var customerId = context.getVariable("customerId");
var accountId = context.getVariable("objectId");

if (customerId == '1241' && accountId == '123123')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '12345' && accountId == '123123')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '33456' && accountId == '123123')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '741852' && accountId == '123123')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '425435' && accountId == '12345667')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '741852' && accountId == '12345667')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '963852' && accountId == '12345667')
{
	context.setVariable("objectId", "123123");
}
else if (customerId == '425435' && accountId == '123456678')
{
	context.setVariable("objectId", "001");
}
else if (customerId == '741852' && accountId == '123123789')
{
	context.setVariable("objectId", "002");
}
else if (customerId == '963852' && accountId == '123456670')
{
	context.setVariable("objectId", "003");
}
else if (customerId == '111222333' && accountId == '132132132')
{
	context.setVariable("objectId", "004");
}
else if (customerId == '222333444' && accountId == '133133133')
{
	context.setVariable("objectId", "005");
}
else if (customerId == '333444555' && accountId == '134134134')
{
	context.setVariable("objectId", "006");
}
else if (customerId == '444555666' && accountId == '135135135')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '666777888' && accountId == '136136136')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999111' && accountId == '137137137')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999222' && accountId == '138138138')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999333' && accountId == '139139139')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999444' && accountId == '140140140')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999555' && accountId == '141141141')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '888999666' && accountId == '142142142')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '500000001' && accountId == '123123')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '500000002' && accountId == '123123')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '500000003' && accountId == '123127')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '500000011' && accountId == '123123')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '500000015' && accountId == '123123')
{
	context.setVariable("objectId", "008");
}
else if (customerId == '234234328' && accountId == '123123')
{
	context.setVariable("objectId", "009");
}
else if (customerId == '3000000057' && accountId == '123123')
{
	context.setVariable("objectId", "009");
}
else if (customerId == '23456' && accountId == '5555501')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22245' && accountId == '5555502')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22246' && accountId == '5555503')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22247' && accountId == '5555504')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22248' && accountId == '5555505')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22249' && accountId == '5555506')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22250' && accountId == '5555507')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22251' && accountId == '5555508')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22252' && accountId == '5555509')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22253' && accountId == '5555510')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22254' && accountId == '5555511')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22255' && accountId == '5555512')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '22256' && accountId == '5555513')
{
	context.setVariable("objectId", "010");
}
else if (customerId == '555555555' && accountId == '456785')
{
	context.setVariable("objectId", "011");
}
else if (customerId == '234234328' && accountId == '123123')
{
	context.setVariable("objectId", "011");
}
else if (customerId == '982333' && accountId == '123458899')
{
	context.setVariable("objectId", "012");
}

// QAT 337
else if (customerId == '3000000028' && accountId == '4000000568')
{
	context.setVariable("objectId", "014");
}
else if (customerId == '3000000031' && accountId == '4000000569')
{
	context.setVariable("objectId", "015");
}
else if (customerId == '3000000032' && accountId == '4000000570')
{
	context.setVariable("objectId", "016");
}
else if (customerId == '3000000033' && accountId == '4000000571')
{
	context.setVariable("objectId", "017");
}
else if (customerId == '3000000034' && accountId == '4000000572')
{
	context.setVariable("objectId", "018");
}
else if (customerId == '3000000007' && accountId == '4000000548')
{
	context.setVariable("objectId", "019");
}
else if (customerId == '3000000008' && accountId == '4000000549')
{
	context.setVariable("objectId", "020");
}
else if (customerId == '3000000050' && accountId == '4000000583')
{
	context.setVariable("objectId", "021");
}
else if (customerId == '3000000035' && accountId == '4000000573')
{
	context.setVariable("objectId", "022");
}
else if (customerId == '3000000036' && accountId == '4000000574')
{
	context.setVariable("objectId", "023");
}
else if (customerId == '3000000037' && accountId == '4000000575')
{
	context.setVariable("objectId", "024");
}
else if (customerId == '3000000038' && accountId == '4000000576')
{
	context.setVariable("objectId", "025");
}
else if (customerId == '3000000039' && accountId == '4000000577')
{
	context.setVariable("objectId", "026");
}
else if (customerId == '3000000041' && accountId == '4000000579')
{
	context.setVariable("objectId", "027");
}
else if (customerId == '3000000054' && accountId == '4000000587')
{
	context.setVariable("objectId", "029");
}
else if(customerId=='9876543210' && accountId=='332211')
{
  context.setVariable("objectId", "034");
}
else if(customerId=='425436' && accountId=='123123')
{
  context.setVariable("objectId", "035");
}
// QAT End

else
{
	context.setVariable("objectId", accountId);
}