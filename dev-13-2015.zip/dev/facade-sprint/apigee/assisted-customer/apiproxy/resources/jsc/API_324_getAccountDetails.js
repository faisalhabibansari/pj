var objectId = context.getVariable("objectId"); 
var lineId=context.getVariable("request.queryparam.lineId");
if(lineId!=null && objectId=='9832723' )
{
context.setVariable("objectId", "12345");
}

else if(lineId=='2061231235' && objectId=='123123'){
  context.setVariable("objectId", "123456");
  }
else if(lineId=='2061231236' && objectId=='123123'){
  context.setVariable("objectId", "1234567"); 
  }
else if(lineId=='2234459987' && objectId=='123123'){
  context.setVariable("objectId", "12345678"); 
  }
else if(lineId==null && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario7"); 
  }
else if(lineId==null && objectId=='123123'){
  context.setVariable("objectId", "api324scenario8"); 
  }
else if(lineId=='2061231235' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario9"); 
  }
else if(lineId=='2061231236' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario10"); 
  }
else if(lineId=='2234459987' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario11"); 
  }
else if(lineId=='2061231237' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario13"); 
  }
else if(lineId=='2061231237' && objectId=='123123'){
  context.setVariable("objectId", "api324scenario14"); 
  }
else if(lineId=='2234459987' && objectId=='55555'){
  context.setVariable("objectId", "api324scenario15"); 
  }
else if(objectId=='123456670'){
  if(lineId=='4251234568'){
    context.setVariable("objectId", "api324scenario20"); 
  }
    else if(lineId=='2061231234'){
    context.setVariable("objectId", "api324scenario22"); 
  }
  else{
    context.setVariable("objectId", "api324scenario21");
    }
}
else if(objectId=='123456678'){
  if(lineId=='4254357788'){
    context.setVariable("objectId", "api324scenario24"); 
  }
    else if(lineId=='4254354466'){
    context.setVariable("objectId", "api324scenario26"); 
  }
  else if(lineId=='4254352233'){
    context.setVariable("objectId", "api324scenario27"); 
  }
  else{
    context.setVariable("objectId", "api324scenario25");
    }
}
else if(objectId=='123123789'){
  context.setVariable("objectId", "api324scenario23"); 
  }
else if(objectId=='555555'){
  context.setVariable("objectId", "api324scenario29"); 
  }
else if(lineId==null){
  context.setVariable("objectId", objectId); 
  }