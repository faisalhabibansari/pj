var cartid = context.getVariable("cartId");

context.setVariable("dataType", "getCartStatus");

if (cartid == '1000')
{
	context.setVariable("objectId", "001");
}
else if (cartid == '1513')
{
	context.setVariable("objectId", "002");
}