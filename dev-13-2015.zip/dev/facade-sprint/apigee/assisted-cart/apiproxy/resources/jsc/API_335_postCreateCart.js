var request_payload = '';
if (context.getVariable('request.content') != null && context.getVariable('request.content') != '') {
    request_payload = JSON.parse(context.getVariable('request.content'));
}


context.setVariable("dataType", "createCart");

var cartData = [];

if (request_payload.hasOwnProperty('items') && request_payload.items instanceof Array) {
    for (i = 0; i < request_payload.items.length; i++) {
        cartData.push(request_payload.items[i].productId);
    }
}
//context.setVariable("cart",JSON.stringify(cartData));

var customerId = request_payload.customerId;

if (customerId == "1244") {
    context.setVariable("objectId", "1444");
} else if (customerId == "1241") {
    if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (cartLinesData.indexOf("pln2513") != -1) {
            context.setVariable("objectId", "004");
        }
    }
    //context.setVariable("objectId","1333");
} else if (customerId == "33456") {
    if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (cartLinesData.indexOf("pln2513") != -1) {
            context.setVariable("objectId", "005");
        }
    }
    //context.setVariable("objectId","1222");
} else if (customerId == "1234") {
    context.setVariable("objectId", "1555");
} else if (customerId == "12345") {
    if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (cartLinesData.indexOf("pln2511") != -1) {
            context.setVariable("objectId", "001");
        } else if (cartLinesData.indexOf("pln2512") != -1) {
            context.setVariable("objectId", "002");
        } else if (cartLinesData.indexOf("101") != -1) {
            context.setVariable("objectId", "006");
        } else if (cartLinesData.indexOf("1000123456") != -1) {
            context.setVariable("objectId", "007");
        } else if (cartLinesData.indexOf("pln2513") != -1) {
            context.setVariable("objectId", "008");
        } else if (cartLinesData.indexOf("10001234511") != -1) {
            context.setVariable("objectId", "009");
        }
    }
    //context.setVariable("objectId","1666");
} else if (customerId == "1207") {
    if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (cartLinesData.indexOf("pln2513") != -1) {
            context.setVariable("objectId", "003");
        }
    }
} else if (request_payload.hasOwnProperty('source') && request_payload.source.customerId == "500000011") {
    if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (cartLinesData.indexOf("6021234578") != -1) {
            context.setVariable("objectId", "011");
        }
    }
} else if (customerId == "") {
    if (request_payload.hasOwnProperty('items')) {
        if (request_payload.items instanceof Array && request_payload.items[0].productId == '12') {
            context.setVariable("objectId", "1302");
        } else if (request_payload.items instanceof Array && request_payload.items[0].productType ==
            'refillCards') {
            context.setVariable("objectId", "refill01");
        } else if (request_payload.items instanceof Array && request_payload.items[0].productId == '101') {
            context.setVariable("objectId", "1486");
        }
    } else if (request_payload.hasOwnProperty('cartLines') && request_payload.cartLines instanceof Array) {
        var cartLinesData = JSON.stringify(request_payload.cartLines);
        if (request_payload.cartLines instanceof Array && ((request_payload.cartLines[0].lineId == '55556') ||
                (request_payload.cartLines[0].lineId == '55554') || (request_payload.cartLines[0].lineId ==
                    '55555'))) {
            context.setVariable("objectId", "1304");
        } else if (request_payload.cartLines.length == 3) {
            if (cartLinesData.indexOf("Francis Whitman") != -1 && cartLinesData.indexOf("Peter L Whitman") !=
                -1 && cartLinesData.indexOf("Jack Whitman") != -1 && cartLinesData.indexOf("Added") != -1) {
                context.setVariable("objectId", "012");
            } else if (cartLinesData.indexOf("Francis Whitman") == -1 && cartLinesData.indexOf(
                    "Peter L Whitman") == -1 && cartLinesData.indexOf("Jack Whitman") == -1 && cartLinesData.indexOf(
                    "Added") == -1) {
                context.setVariable("objectId", "012");
            } else {
                context.setVariable("objectId", "line3");
            }
        } else if (request_payload.cartLines.length == 1) {
            if (cartLinesData.indexOf("123456789012345678") != -1) {
                context.setVariable("objectId", "010");
            } else if (request_payload.cartLines[0].items.length == 1 && cartLinesData.indexOf("101") != -1 &&
                cartLinesData.indexOf("plan") != -1) {
                context.setVariable("objectId", "013");
            } else if (request_payload.cartLines[0].items.length == 1 && cartLinesData.indexOf("101") == -1 &&
                cartLinesData.indexOf("plan") != -1) {
                context.setVariable("objectId", "1521");
            } else if (request_payload.cartLines[0].items.length == 1 && cartLinesData.indexOf("11") != -1 &&
                cartLinesData.indexOf("device") != -1) {
                context.setVariable("objectId", "1521");
            } else if (request_payload.cartLines[0].items.length == 2 && cartLinesData.indexOf("device") != -
                1 && cartLinesData.indexOf("service") != -1) {
                context.setVariable("objectId", "1521");
            } else if (request_payload.cartLines[0].items.length == 2 && cartLinesData.indexOf("device") != -
                1 && cartLinesData.indexOf("plan") != -1) {
                context.setVariable("objectId", "1521");
            } else if (request_payload.cartLines[0].items.length == 2 && cartLinesData.indexOf("device") != -
                1 && cartLinesData.indexOf("accessory") != -1) {
                context.setVariable("objectId", "1521");
            } else if (request_payload.cartLines[0].items.length == 2 && cartLinesData.indexOf("Device") != -
                1 && cartLinesData.indexOf("Accessory") != -1 && request_payload.cartLines[0].items[0].productId ==
                '101' && request_payload.cartLines[0].items[1].productId == '111') {
                context.setVariable("objectId", "1302");
            } else if (cartLinesData.indexOf("1PMX134LL/A") != -1) {
                context.setVariable("objectId", "1650");
            } else if (request_payload.cartLines[0].items.length == 1 && cartLinesData.indexOf("101") != -1 &&
                cartLinesData.indexOf("device") != -1) {
                context.setVariable("objectId", "1651");
            }
        }
    }
} else {
    if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(123) != -1)) {
        context.setVariable("objectId", "9002");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(101) !=
            -1) && (cartData.indexOf(789) != -1)) {
        context.setVariable("objectId", "9001");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(123) !=
            -1)) {
        context.setVariable("objectId", "9003");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(123) !=
            -1)) {
        context.setVariable("objectId", "9004");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(123) !=
            -1)) {
        context.setVariable("objectId", "9005");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(456) !=
            -1)) {
        context.setVariable("objectId", "9006");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(456) !=
            -1)) {
        context.setVariable("objectId", "9007");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(456) !=
            -1)) {
        context.setVariable("objectId", "9008");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(456) !=
            -1)) {
        context.setVariable("objectId", "9009");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(789) !=
            -1)) {
        context.setVariable("objectId", "9014");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(789) !=
            -1)) {
        context.setVariable("objectId", "9012");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(789) !=
            -1)) {
        context.setVariable("objectId", "9010");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(786) !=
            -1)) {
        context.setVariable("objectId", "9013");
    } else if ((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(789) !=
            -1)) {
        context.setVariable("objectId", "9011");
    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1)) {

        context.setVariable("objectId", "9015");

    } else if ((cartData.indexOf("pln2512") != -1) && (cartData.indexOf('0001') != -1)) {

        context.setVariable("objectId", "1300");

    } else if ((cartData.indexOf("pln2517") != -1) && (cartData.indexOf(102) != -1)) {

        context.setVariable("objectId", "9016");

    } else if ((cartData.indexOf("pln2513") != -1) && (cartData.indexOf("0001") != -1)) {

        context.setVariable("objectId", "9017");

    } else if (request_payload.hasOwnProperty('cartLines')) {
        var cartLinesdata = JSON.stringify(request_payload.cartLines);
        if (cartLinesdata.indexOf("101") != -1) {
            context.setVariable("objectId", "9018");
        }

    } else if (request_payload.hasOwnProperty('items')) {
        if (request_payload.items instanceof Array && request_payload.items[0].productId == 'pln2512' &&
            request_payload.items[1].productId == '0001') {
            context.setVariable("objectId", "1300");
        } else if (request_payload.items instanceof Array && request_payload.items[0].productId == 'pln2517' &&
            request_payload.items[1].productId == '102') {
            context.setVariable("objectId", "1301");
        } else if (request_payload.items instanceof Array && request_payload.items[0].productId == '12') {
            context.setVariable("objectId", "1302");
        }
        /*  else if(request_payload.items instanceof Array && request_payload.items[0].productId == 'pln2513' && request_payload.items[1].productId == '101') 
          {
          context.setVariable("objectId","1444");
          }
          else if(request_payload.items instanceof Array && request_payload.items[0].productId == 'pln2513' && request_payload.items[1].productId == '102') 
          {
          context.setVariable("objectId","1333");
          }
          else if(request_payload.items instanceof Array && request_payload.items[0].productId == 'pln2518' && request_payload.items[1].productId == '103') 
          {
          context.setVariable("objectId","1222");
          }*/
    }
}

if (typeof request_payload.cartLines !== 'undefined') {
    var cartLinesData = JSON.stringify(request_payload.cartLines);
    if (cartLinesData.indexOf("1PMX134LL/A") != -1) {
        context.setVariable("objectId", "1650");
        print("cartLineData : objectId: 1650" + cartLinesData);
    }
}