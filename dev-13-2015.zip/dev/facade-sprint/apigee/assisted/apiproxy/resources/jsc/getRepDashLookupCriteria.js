var token = context.getVariable('request.header.token')
var type = context.getVariable("request.queryparam.type");
var customerView = context.getVariable("request.queryparam.customerView")
context.setVariable("dataType", "getRepDashLookupCriteria");

if (token == 'fx00wmdlxw0' || token == '00x34frsdc')
{

	if (type == 'activity' && customerView == 'true')
	{
		context.setVariable("objectId", "005");
	}
	else if (type == 'activity')
	{
		context.setVariable("objectId", "002");
	}

	else if (type == 'status')
	{
		context.setVariable("objectId", "003");
	}
	else if (type == 'situationalCodes,followUpReasons')
	{
		context.setVariable("objectId", "004");
	}
	else if (type == 'blockPaymentReasons,paymentChannels')
	{
		context.setVariable("objectId", "006");
	}
	else if (type == 'unblockPaymentReasons')
	{
		context.setVariable("objectId", "007");
	}
	else if (type == 'creditReasons')
	{
		context.setVariable("objectId", "008");
	}
	else if (type == 'fraudRoutingReasons,Market')
	{
		context.setVariable("objectId", "009");
	}
	else if (type == 'holdRequestReasons')
	{
		context.setVariable("objectId", "010");
	}
	else if (type == 'adjustmentReasons')
	{
		context.setVariable("objectId", "011");
	}
	else if (type == 'creditDenialReasons')
	{
		context.setVariable("objectId", "012");
	}

	else if (type == 'promotion')
	{
		context.setVariable("objectId", "013");
	}
	else if (type == 'customer')
	{
		context.setVariable("objectId", "customer");
	}
	else if (type == 'order')
	{
		context.setVariable("objectId", "order");
	}
	else
	{
		context.setVariable("objectId", "001");
	}
}
// else if(type != null && type != '')
else if (type == 'creditDenialReasons')
{
	context.setVariable("objectId", type);
}
else if (type == 'activity')
{
	context.setVariable("objectId", "002");
}

else if (type == 'status')
{
	context.setVariable("objectId", "003");
}
