var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postSetNotification");
if(reqPayLoad!=null && reqPayLoad.linesSelected[0].msisdn=='1234567891')
{
context.setVariable("objectId","001");
}