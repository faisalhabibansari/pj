context.setVariable("dataType","getDeviceDetails");
