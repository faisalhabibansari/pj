context.setVariable("dataType", 'workflowRouteApiTable');
context.setVariable("objectId", "001");