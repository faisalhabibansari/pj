context.setVariable("dataType", 'RolePermissions');
context.setVariable("objectId", "001");