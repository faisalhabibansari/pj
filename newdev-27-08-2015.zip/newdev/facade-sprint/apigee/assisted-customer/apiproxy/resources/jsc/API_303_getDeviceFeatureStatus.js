var imei=context.getVariable("request.queryparam.imei");

context.setVariable("dataType",'getDeviceFeatureStatus');

if(imei=='012345678901250')
{
context.setVariable("objectId","002");
}
else if(imei=='012345678901245')
{
context.setVariable("objectId","003");
}
else
{
context.setVariable("objectId","001");
}

