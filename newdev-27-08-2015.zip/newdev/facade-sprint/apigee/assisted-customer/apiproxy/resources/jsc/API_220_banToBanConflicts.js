var request_payload = '';
var requestJSON = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='') {
  request_payload = JSON.parse(context.getVariable('request.content'));
    requestJSON = JSON.stringify(request_payload);
}

//if (request_payload.lines[0].id == '2061234567') 
//{

  //context.setVariable("objectId", "2061234567");
    //context.setVariable("dataType","banToBanConflicts");
//}
//var type=context.getVariable("request.queryparam.type");

var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
var type=context.getVariable("request.queryparam.type");
context.setVariable("dataType","banToBanConflicts");

if(customerId == "234234200" && type=='plans' && accountId =="123127"){
  context.setVariable("objectId", "003");  
}else if(customerId == "234234200" && type=='plans' && accountId =="123456"){
  context.setVariable("objectId", "004");  
}else if(customerId == "234234200" && type=='services' && accountId =="123127"){
  context.setVariable("objectId", "005");  
}else if(customerId == "234234200" && type=='services' && accountId =="123456"){
  context.setVariable("objectId", "006");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123123"){
  context.setVariable("objectId", "015");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123127"){
  context.setVariable("objectId", "008");  
}else if(customerId == "234234328" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "010");  
}else if(customerId == "234227000" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "011");  
}else if(customerId == "234227001" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "012"); 
}else if(customerId == "234234200" && type=='plans' && accountId =="123126"){
  context.setVariable("objectId", "013");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123124"){
  context.setVariable("objectId", "014");  
}else if(customerId == "500000002" && type=='plans' && accountId =="123123"){
  context.setVariable("objectId", "016");  
}
else if(customerId == "500000002" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "017");  
}
else if(customerId == "500000001" && type=='services' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "035");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='555555') 
  {
  context.setVariable("objectId", "042");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "060");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "061");  
  }
  else if (requestJSON.indexOf("6021234578  ") != -1 && request_payload.newAccountId=='666666') 
  {
  context.setVariable("objectId", "043");  
  }
  //context.setVariable("objectId", "018");  
}
else if(customerId == "500000001" && type=='services' && accountId =="123124")
{
  if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "036");  
  }
  else if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "037");  
  } 
  else if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "038");  
  }
  else if (requestJSON.indexOf("2061255555") != -1 && request_payload.newAccountId=='123127') 
  {
  context.setVariable("objectId", "103");  
  }
}
else if(customerId == "500000001" && type=='services' && accountId =="999988")
{
  if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "039");  
  }
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='999999') 
  {
  context.setVariable("objectId", "040");  
  } 
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "062");  
  } 
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "063");  
  } 
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='888888') 
  {
  context.setVariable("objectId", "041");  
  } 
}
else if(customerId == "500000001" && type=='services' && accountId =="999987")
{
  if (requestJSON.indexOf("6021234934") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "076");
  }
  else if (requestJSON.indexOf("2061255555") != -1 && request_payload.newAccountId=='123127') 
  {
  context.setVariable("objectId", "076");
  }
}
else if(customerId == "500000001" && type=='plans' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "025");  
  }
  else if (requestJSON.indexOf("2061234567") != -1 && request_payload.newAccountId=='123126') 
  {
  context.setVariable("objectId", "026");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='555555') 
  {
  context.setVariable("objectId", "033");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='666666') 
  {
  context.setVariable("objectId", "034");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "059");  
  }
  else if (request_payload.lines[0].id == '6021234578') 
  {
  context.setVariable("objectId", "019");  
  }
  else  if (request_payload.lines[0].id == '2061234567') 
  {
  context.setVariable("objectId", "020");  
  }
}
else if(customerId == "500000001" && type=='plans' && accountId =="123124")
{
  if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "027");  
  }
  else if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "028");  
  }
  else if (requestJSON.indexOf("2063234567") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "029");  
  }
}
else if(customerId == "500000001" && type=='plans' && accountId =="999988")
{
  if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "030");  
  }
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='999999') 
  {
  context.setVariable("objectId", "031");  
  }
  else if (requestJSON.indexOf("601234600") != -1 && request_payload.newAccountId=='888888') 
  {
  context.setVariable("objectId", "032");  
  }
}
else if(customerId == "500000001" && type=='plans' && accountId =="999987")
{
  if (requestJSON.indexOf("6021234934") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "077");
  }
  else if (requestJSON.indexOf("2061255555") != -1 && request_payload.newAccountId=='123127') 
  {
  context.setVariable("objectId", "104");
  }
}
else if(customerId == "500000002" && type=='plans' && accountId =="123124")
{
  if (request_payload.lines[0].id == '8182223334') 
  {
  context.setVariable("objectId", "021");  
  }
  else  if (request_payload.lines[0].id == '8182223335') 
  {
  context.setVariable("objectId", "022");  
  } 
}
else if(customerId == "500000002" && type=='services' && accountId =="123124")
{
  if (request_payload.lines[0].id == '8182223334') 
  {
  context.setVariable("objectId", "023");  
  }
  else  if (request_payload.lines[0].id == '8182223335') 
  {
  context.setVariable("objectId", "024");  
  } 
}
else if(customerId == "500000011" && type=='services' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "044");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "045");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "046");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "047");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123126') 
  {
  context.setVariable("objectId", "073");  
  }
}
else if(customerId == "500000011" && type=='plans' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "048");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "049");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "050");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123124') 
  {
  context.setVariable("objectId", "051");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123127') 
  {
  context.setVariable("objectId", "074");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123126') 
  {
  context.setVariable("objectId", "075");  
  }
}
else if(customerId == "500000015" && type=='services' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "052");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "053");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "054");  
  }
}
else if(customerId == "500000015" && type=='plans' && accountId =="123123")
{
  if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123125') 
  {
  context.setVariable("objectId", "055");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "056");  
  }
  else if (requestJSON.indexOf("6021234578") != -1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "057");  
  }
}

else if(customerId == "741852" && accountId =="123123789" && type=='plans')
{
  if (requestJSON.indexOf("123123") != -1 && request_payload.newAccountId=='123990') 
  {
  context.setVariable("objectId", "078");  
  }
  else if (requestJSON.indexOf("123125") != -1 && requestJSON.indexOf("6021238367") != -1) 
  {
  context.setVariable("objectId", "079");  
  }
  else if (requestJSON.indexOf("123123") != -1 && requestJSON.indexOf("4251234567") != -1) 
  {
  context.setVariable("objectId", "101");  
  }
}
else if(customerId == "741852" && type=='services' && accountId =="123123789")
{
  if (requestJSON.indexOf("123123") != -1 && request_payload.newAccountId=='123990123') 
  {
  context.setVariable("objectId", "080");  
  }
  else if (requestJSON.indexOf("123125") != -1 && request_payload.newAccountId=='123456670') 
  {
  context.setVariable("objectId", "081");  
  }
}
else if(customerId == "555555555" && type=='plans' && accountId =="456785")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==3 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "082");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==3 && request_payload.newAccountId=='456787') 
  {
  context.setVariable("objectId", "083");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "088");  
  }
}
else if(customerId == "555555555" && type=='plans' && accountId =="456786")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==2 && request_payload.newAccountId=='456785') 
  {
  context.setVariable("objectId", "084");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==2 && request_payload.newAccountId=='456787') 
  {
  context.setVariable("objectId", "085");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "089");  
  }
}
else if(customerId == "555555555" && type=='plans' && accountId =="456787")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456785') 
  {
  context.setVariable("objectId", "086");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "087");  
  }
}
else if(customerId == "555555555" && type=='services' && accountId =="456785")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==3 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "090");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==3 && request_payload.newAccountId=='456787') 
  {
  context.setVariable("objectId", "091");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "096");  
  }
}
else if(customerId == "555555555" && type=='services' && accountId =="456786")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==2 && request_payload.newAccountId=='456785') 
  {
  context.setVariable("objectId", "092");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==2 && request_payload.newAccountId=='456787') 
  {
  context.setVariable("objectId", "093");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "097");  
  }
}
else if(customerId == "555555555" && type=='services' && accountId =="456787")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456785') 
  {
  context.setVariable("objectId", "094");  
  }
  else if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='456786') 
  {
  context.setVariable("objectId", "095");  
  }
}
else if(customerId == "500000001" && type=='plans' && accountId =="123125")
{
  if (request_payload.lines instanceof Array && request_payload.lines.length==1 && request_payload.newAccountId=='123991') 
  {
  context.setVariable("objectId", "100");  
  }
}
else if(type =='plans'){
  context.setVariable("objectId", "001");  
}else if(type =='services'){
  context.setVariable("objectId", "002");  
}
context.setVariable("dataType","banToBanConflicts");