var request_payload = context.targetRequest.body.asJSON
var imei = request_payload.imei;
var diff = (request_payload.deviceAssessmentAnswers[0].answer.answerText).toLowerCase();
var diff1 = (request_payload.deviceAssessmentAnswers[1].answer.answerText).toLowerCase();
var diff2 = (request_payload.deviceAssessmentAnswers[2].answer.answerText).toLowerCase();

context.setVariable("dataType", "saveAssessmentResponse");


context.setVariable("objectId","IMEI_"+imei+"_A1_"+diff+"_A2_"+diff1+"_A3_"+diff2); 
