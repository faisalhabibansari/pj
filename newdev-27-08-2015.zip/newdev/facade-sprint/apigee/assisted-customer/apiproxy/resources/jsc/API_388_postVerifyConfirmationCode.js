var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","VerifyConfirmationCode");

if(reqPayLoad.confirmationCode=='1122' && reqPayLoad.msisdn=='5551234568')
{
    context.setVariable("objectId","001" );
}
else if(reqPayLoad.confirmationCode=='3344' && reqPayLoad.msisdn=='5551234575')
{
     context.setVariable("objectId","002");
}
else if(reqPayLoad.confirmationCode=='5566' && reqPayLoad.msisdn=='5551234568')
{
    context.setVariable("objectId","003");
}
