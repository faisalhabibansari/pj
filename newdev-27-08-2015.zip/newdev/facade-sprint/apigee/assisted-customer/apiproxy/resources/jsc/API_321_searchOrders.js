var email=context.getVariable("request.queryparam.email");
var accntNo=context.getVariable("request.queryparam.accntNo");
var street=context.getVariable("request.queryparam.street");
var city=context.getVariable("request.queryparam.city");
var state=context.getVariable("request.queryparam.state");
var zip=context.getVariable("request.queryparam.zip");
var agentId=context.getVariable("request.queryparam.agentId");
var cardNo=context.getVariable("request.queryparam.cardNo");
var dealerCode=context.getVariable("request.queryparam.dealerCode");
var taxId=context.getVariable("request.queryparam.taxId");
var firstName=context.getVariable("request.queryparam.firstName");
var lastName=context.getVariable("request.queryparam.lastName");
var imei=context.getVariable("request.queryparam.imei");
var orderId=context.getVariable("request.queryparam.orderId");
var rma=context.getVariable("request.queryparam.rma");
var storeId=context.getVariable("request.queryparam.storeId");
var trackingNo=context.getVariable("request.queryparam.trackingNo");
var msisdn=context.getVariable("request.queryparam.msisdn");
var ssnLast4=context.getVariable("request.queryparam.ssnLast4");
var terminalId=context.getVariable("request.queryparam.terminalId");
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");

var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");
var filter=context.getVariable("request.queryparam.filter");

var transactionId=context.getVariable("request.queryparam.transactionId");

if(email!=null && email!="")
{
email = email.toLowerCase();
}
if(firstName!=null && firstName!="")
{
firstName = firstName.toLowerCase();
}
if(lastName!=null && lastName!="")
{
lastName = lastName.toLowerCase();
}


context.setVariable("email----",email);

context.setVariable("dataType","searchOrders");

if(email=='johnadams@domain.com')
{
 context.setVariable("objectId","001");
}
else if(accntNo=='43212567')
{
 context.setVariable("objectId","002");
}
else if(street=='221bBakerStreet' && city=='' && state=='' && zip=='' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","092");
}
else if(street=='' && city=='' && state=='AL' && zip=='' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","093");
}
else if(street=='' && city=='' && state=='' && zip=='12345' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","094");
}
else if(street=='' && city=='Marylebone' && state=='' && zip=='' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","095");
}
else if(street=='' && city=='Marylebone' && state=='' && zip=='12345' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","096");
}
else if(street=='221bBakerStreet' && city=='Marylebone' && state=='' && zip=='' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","097");
}
else if(street=='221bBakerStreet'&&city=='Marylebone'&&state=='AL'&&zip=='12345')
{
 context.setVariable("objectId","003");
}
else if(agentId=='0123456')
{
 context.setVariable("objectId","004");
}
else if(cardNo=='123456789101112')
{
 context.setVariable("objectId","005");
}
else if(dealerCode=='1234567')
{
 context.setVariable("objectId","006");
}
else if(email=='john.baker@hotmail.com' && sortOrder==undefined)
{
 context.setVariable("objectId","007");
}
else if(taxId=='012345678')
{
 context.setVariable("objectId","008");
}
else if(firstName=='taylor'&&lastName=='james')
{
 context.setVariable("objectId","009");
}
else if(firstName=='Jim'&&lastName=='')
{
 context.setVariable("objectId","009");
}
else if(firstName=='mik*' && lastName=='ab*' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","102");
}
else if(imei=='1234567891011')
{
 context.setVariable("objectId","011");
}
else if(orderId=='ABCD12345EFGHIJKL678910ABCDE123')
{
 context.setVariable("objectId","012");
}
else if(rma=='12345A67B89C1012')
{
 context.setVariable("objectId","013");
}
else if(storeId=='9611' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","070");
}
else if(storeId=='9611' && offset=='10' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","071");
}
else if(storeId=='9611' && offset=='20' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","072");
}
else if(storeId=='4321')
{
 context.setVariable("objectId","014");
}
else if(trackingNo=='12345ABCDEF12345')
{
 context.setVariable("objectId","015");
}
else if(msisdn=='4259991234')
{
 context.setVariable("objectId","016");
}
else if(ssnLast4=='1234' && lastName=='Adams')
{
 context.setVariable("objectId","017");
}
else if(terminalId=='12'&&storeId=='1234')
{
 context.setVariable("objectId","018");
}
else if(imei=='12345678910111')
{
 context.setVariable("objectId","019");
}
else if(orderId=='ABCD12345EFGHIJKL678910ABCDE1234')
{
 context.setVariable("objectId","020");
}
else if(rma=='12345A67B89C10123')
{
 context.setVariable("objectId","021");
}
else if(imei=='12345678910111')
{
 context.setVariable("objectId","022");
}
else if(imei=='1234567887456321' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","087");
}
else if(rma=='ABC12345678910123')
{
 context.setVariable("objectId","023");
}
else if(storeId=='9600')
{
 context.setVariable("objectId","024");
}
else if(storeId=='1234' && offset=='0' && limit=='10')
{
 context.setVariable("objectId","025");
}
else if(storeId=='1234' && offset=='10' && limit=='10')
{
 context.setVariable("objectId","026");
}
else if(storeId=='1234' && offset=='20' && limit=='10')
{
 context.setVariable("objectId","027");
}
else if(storeId=='9611' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","028");
}
else if(storeId=='9611' && offset=='10' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","029");
}
else if(storeId=='9611' && offset=='20' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","030");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='asc')
{
 context.setVariable("objectId","031");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='desc')
{
 context.setVariable("objectId","032");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='asc')
{
 context.setVariable("objectId","033");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","034");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","035");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc')
{
 context.setVariable("objectId","036");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='asc')
{
 context.setVariable("objectId","037");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='desc')
{
 context.setVariable("objectId","038");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","039");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","040");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","041");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","042");
}
else if(msisdn=='4254357788' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","085");
}
else if(msisdn=='775676*' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","101");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","043");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc')
{
 context.setVariable("objectId","046");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='asc')
{
 context.setVariable("objectId","047");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='desc')
{
 context.setVariable("objectId","048");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='asc')
{
 context.setVariable("objectId","049");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","050");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","051");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","052");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='asc')
{
 context.setVariable("objectId","053");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='desc')
{
 context.setVariable("objectId","054");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","055");
}
else if(email=='john.baker@hotmail.com' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","056");
}
else if(email=='john.smith@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","084");
}
else if(email=='john.smith@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","057");
}
else if(email=='john.smith@hotmail.com')
{
 context.setVariable("objectId","0571");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=' )
{
 context.setVariable("objectId","058");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=returned,orderTypeList=individual,purchaseChannelList=telesales,orderStartDate=4/20/2014,orderEndDate=4/20/2014')
{
 context.setVariable("objectId","059");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=4/20/2015,orderEndDate=5/20/2015')
{
 context.setVariable("objectId","060");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=individual,purchaseChannelList=all,orderStartDate=4/20/2014,orderEndDate=4/30/2015')
{
 context.setVariable("objectId","061");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=individual,purchaseChannelList=all,orderStartDate=4/20/2014,orderEndDate=4/30/2015')
{
 context.setVariable("objectId","062");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=exchange,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","063");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=individual,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","064");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=retail,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","065");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=returned,orderTypeList=individual,purchaseChannelList=telesales,orderStartDate=04/20/2014,orderEndDate=04/20/2014')
{
 context.setVariable("objectId","066");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=04/20/2015,orderEndDate=05/20/2015')
{
 context.setVariable("objectId","067");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=individual,purchaseChannelList=all,orderStartDate=04/20/2014,orderEndDate=04/30/2015')
{
 context.setVariable("objectId","068");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=individual,purchaseChannelList=all,orderStartDate=04/20/2014,orderEndDate=04/30/2015')
{
 context.setVariable("objectId","069");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","073");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='order' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","074");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='order' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","075");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","076");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='date' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","077");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","078");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","079");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='channel' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","080");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='channel' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","081");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='orderType' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","082");
}
else if(email=='david.james@hotmail.com' && offset=='0' && limit=='10' && sort=='orderType' && sortOrder=='desc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","083");
}
else if(email=='will.smith@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","086");
}
else if(email=='jeremy.son@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","088");
}
else if(email=='jo*123@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","098");
}
else if(email=='míckéy@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","099");
}
else if(email=='jo*@hotmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","100");
}
else if(street=='221bBakerStreet'&&city==''&&state==''&&zip=='')
{
 context.setVariable("objectId","044");
}
else if(street==''&&city==''&&state=='AL'&&zip=='')
{
 context.setVariable("objectId","044");
}
else if(street==''&&city==''&&state==''&&zip=='12345')
{
 context.setVariable("objectId","044");
}
else if(street==''&&city=='Marylebone'&&state==''&&zip=='')
{
 context.setVariable("objectId","044");
}
else if(street==''&&city=='Marylebone'&&state==''&&zip=='12345')
{
 context.setVariable("objectId","044");
}
else if(street=='221bBakerStreet'&&city=='Marylebone'&&state==''&&zip=='')
{
 context.setVariable("objectId","044");
}
else if(street=='221bBakerStreet'&&city=='Marylebone'&&state==''&&zip=='12345')
{
 context.setVariable("objectId","044");
}
else if(street=='BakerStreet1234567890'&&city=='Seattle123'&&state=='WA'&&zip=='11110')
{
 context.setVariable("objectId","045");
}
else if(street=='BakerStreet1234567890'&&city==''&&state==''&&zip=='')
{
 context.setVariable("objectId","045");
}
else if(street==''&&city==''&&state=='WA'&&zip=='')
{
 context.setVariable("objectId","045");
}
else if(street==''&&city==''&&state==''&&zip=='11110')
{
 context.setVariable("objectId","045");
}
else if(street==''&&city=='Seattle123'&&state==''&&zip=='')
{
 context.setVariable("objectId","045");
}
else if(street==''&&city=='Seattle123'&&state==''&&zip=='11110')
{
 context.setVariable("objectId","045");
}
else if(street=='BakerStreet1234567890'&&city=='Seattle123'&&state==''&&zip=='')
{
 context.setVariable("objectId","045");
}
else if(street==''&&city=='Marylebone'&&state==''&&zip=='11110')
{
 context.setVariable("objectId","045");
}
else if(transactionId=='12341234123412341234123412341234' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","089");
}
else if(transactionId=='12345678123456781234567812345678' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","090");
}
else if(transactionId=='87654321876543218765432187654321' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","091");
}
else if(email=='evin.martin@gmail.com'&&offset=='0'&&limit=='10'&&sort=='name'&&sortOrder=='asc'&&filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","110");
}
else if(email=='evin.martin@gmail.com')
{
 context.setVariable("objectId","103");
}
else if(email=='mill.baker@gmail.com'&&offset=='0'&&limit=='10'&&sort=='name'&&sortOrder=='asc'&&filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","111");
}
else if(email=='mill.baker@gmail.com')
{
 context.setVariable("objectId","104");
}
else if(email=='mark.henry@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='accStatus=all,lineStatus=all,accType=all,accSubType=all')
{
 context.setVariable("objectId","105");
}
else if(email=='jack.whitman@gmail.com')
{
 context.setVariable("objectId","106");
}
else if(email=='adam.smith@gmail.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","107");
}
else if(orderId=='12345678910111213141516171819202' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc' && filter=='orderStatusList=all,orderTypeList=all,purchaseChannelList=all,orderStartDate=,orderEndDate=')
{
 context.setVariable("objectId","108");
}
else if(email=='alex.smith@gmail.com')
{
 context.setVariable("objectId","109");
}
else
{
  context.setVariable("objectId","000");
}
