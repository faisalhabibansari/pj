var type= context.proxyRequest.queryParams['type'];

if( type != '' &&  type == 'adjustment') {
	context.setVariable("objectId", "1111");
	context.setVariable("dataType", "getReasons");

} else if (type != '' &&  type == 'credit') {
	context.setVariable("objectId", "2222");
	context.setVariable("dataType", "getReasons");

}else if (type != '' &&  type == 'holdRequest') {
	context.setVariable("objectId", "3333");
	context.setVariable("dataType", "getReasons");
}else if (type != '' &&  type == 'addImeiBlock') {
	context.setVariable("objectId", "4444");
	context.setVariable("dataType", "getReasons");
}else if (type != '' &&  type == 'removeImeiBlock') {
	context.setVariable("objectId", "5555");
	context.setVariable("dataType", "getReasons");
}
else if (type != '' &&  type == 'return') {
	context.setVariable("objectId", "6666");
	context.setVariable("dataType", "getReasons");
}
else if (type != '' &&  type == 'exchange') {
	context.setVariable("objectId", "7777");
	context.setVariable("dataType", "getReasons");
}
else if (type != '' &&  type == 'postVoid') {
	context.setVariable("objectId", "8888");
	context.setVariable("dataType", "getReasons");
}