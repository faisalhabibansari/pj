var cartid = context.getVariable("cartId");
context.setVariable('dataType', 'getCartItemStatus');

if (cartid == '1000')
{
	context.setVariable("objectId", "001");
}
else if (cartid == '1509')
{
	context.setVariable("objectId", "002");
}
else
{
	context.setVariable("objectId", "000");
}
