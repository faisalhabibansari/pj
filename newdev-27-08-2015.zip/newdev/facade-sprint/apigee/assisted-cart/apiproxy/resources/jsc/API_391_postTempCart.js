var reqPayLoad = context.targetRequest.body.asJSON;

context.setVariable("dataType", "postTempCart");

if (reqPayLoad != null)
{
	if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array)
	{
		var cartLines = reqPayLoad.cartLines;
		var cartLinesData = JSON.stringify(reqPayLoad.cartLines);

		if (reqPayLoad.cartLines.length == 2)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") == -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") == -1)
			{
				context.setVariable("objectId", "001");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") == -1)
			{
				context.setVariable("objectId", "004");
			}
			else if (cartLines[0].items.length == 2 && cartLines[1].items.length == 2)
			{
				context.setVariable("objectId", "006");
			}
			else if (cartLinesData.indexOf("Francis Whitman") != -1 && cartLinesData.indexOf("plans") != -1
					&& cartLinesData.indexOf("101") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1)
			{
				context.setVariable("objectId", "025");
			}
			else if (cartLinesData.indexOf("plans,devices,accessories,services") != -1)
			{
				if ((cartLines[0].items.length == 2 && cartLines[1].items.length == 1)
						|| (cartLines[1].items.length == 1 && cartLines[0].items.length == 2))
				{
					context.setVariable("objectId", "005");
				}
			}
		}
		else if (reqPayLoad.cartLines.length == 4)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("Francis Whitman") != -1
					&& reqPayLoad.cartLines[3].items.length == 2 && reqPayLoad.cartLines[3].items[1].productId == '14')
			{
				context.setVariable("objectId", "050");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("Francis Whitman") != -1
					&& reqPayLoad.cartLines[3].items.length >= 2)
			{
				context.setVariable("objectId", "017");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("11") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("Line") != -1)
			{
				context.setVariable("objectId", "052");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLines[0].lineName == 'Francis Whitman')
			{
				context.setVariable("objectId", "011");
			}
			else if (cartLinesData.indexOf("temp") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1)
			{
				context.setVariable("objectId", "041");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[3].items.length == 1)
			{
				context.setVariable("objectId", "042");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "018");
			}

		}

		else if (reqPayLoad.cartLines.length == 5)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[4].items.length == 1)
			{
				context.setVariable("objectId", "043");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "019");
			}
		}

		else if (reqPayLoad.cartLines.length == 6)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[5].items.length == 1)
			{
				context.setVariable("objectId", "044");
			}

			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "020");
			}
		}

		else if (reqPayLoad.cartLines.length == 7)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[6].items.length == 1)
			{
				context.setVariable("objectId", "045");
			}

			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "021");
			}
		}

		else if (reqPayLoad.cartLines.length == 8)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[7].items.length == 1)
			{
				context.setVariable("objectId", "046");
			}

			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "022");
			}
		}

		else if (reqPayLoad.cartLines.length == 9)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[8].items.length == 1)
			{
				context.setVariable("objectId", "047");
			}

			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "023");
			}
		}

		else if (reqPayLoad.cartLines.length == 10)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& cartLinesData.indexOf("plans,devices,accessories,services") != -1 && reqPayLoad.cartLines[8].items.length == 1)
			{
				context.setVariable("objectId", "048");
			}

			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
			{
				context.setVariable("objectId", "024");
			}
			// Start: For QAT
			if (cartLinesData.indexOf("plans") != -1 && cartLines[0].msisdn == '2172209130' && cartLinesData.indexOf("items") != -1)
			{
				context.setVariable("objectId", "026");
			}
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209135')
			{
				context.setVariable("objectId", "027");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209148')
			{
				context.setVariable("objectId", "028");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209163')
			{
				context.setVariable("objectId", "029");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209172')
			{
				context.setVariable("objectId", "030");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2142053292')
			{
				context.setVariable("objectId", "031");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2142053312')
			{
				context.setVariable("objectId", "032");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '8502074195')
			{
				context.setVariable("objectId", "033");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209174')
			{
				context.setVariable("objectId", "034");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209179')
			{
				context.setVariable("objectId", "035");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209209')
			{
				context.setVariable("objectId", "036");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209217')
			{
				context.setVariable("objectId", "037");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209231')
			{
				context.setVariable("objectId", "038");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("items") != -1 && cartLines[0].msisdn == '2172209247')
			{
				context.setVariable("objectId", "039");
			}
			// End: For QAT
		}

		else if (reqPayLoad.cartLines.length == 3)
		{
			if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1
					&& cartLinesData.indexOf("Francis Whitman") == -1)
			{
				context.setVariable("objectId", "007");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1
					&& cartLinesData.indexOf("Francis Whitman") != -1 && reqPayLoad.cartLines[1].items.length == 1
					&& reqPayLoad.cartLines[2].items.length == 1)
			{
				context.setVariable("objectId", "008");
			}
			// else if(cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1 &&
			// cartLinesData.indexOf("Francis Whitman") != -1 && reqPayLoad.cartLines[1].items.length==2 &&
			// reqPayLoad.cartLines[2].items.length==1)
			// {
			// context.setVariable("objectId","052");
			// }
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1
					&& cartLinesData.indexOf("Francis Whitman") != -1 && reqPayLoad.cartLines[1].items.length == 2
					&& reqPayLoad.cartLines[2].items.length == 1)
			{
				context.setVariable("objectId", "009");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1
					&& cartLinesData.indexOf("Francis Whitman") != -1 && reqPayLoad.cartLines[1].items.length == 2
					&& reqPayLoad.cartLines[2].items.length == 2)
			{
				context.setVariable("objectId", "010");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1
					&& cartLinesData.indexOf("Francis Whitman") != -1 && reqPayLoad.cartLines[1].items.length == 1
					&& reqPayLoad.cartLines[2].items.length == 2)
			{
				context.setVariable("objectId", "016");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("plan") != -1)
			{
				context.setVariable("objectId", "002");
			}

		}
		else if (reqPayLoad.cartLines.length == 1)
		{
			if (cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("plans") != -1
					&& reqPayLoad.customerId == '425435' && reqPayLoad.cartLines[0].items.length == 2)
			{
				context.setVariable("objectId", "015");
			}
			else if (cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("plans") != -1
					&& reqPayLoad.customerId == '425435')
			{
				context.setVariable("objectId", "014");
			}
			else if (cartLinesData.indexOf("devices") != -1 && cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1
					&& reqPayLoad.cartLines[0].items.length == 2)
			{
				context.setVariable("objectId", "013");
			}
			else if (cartLinesData.indexOf("device") != -1 && cartLinesData.indexOf("Line") != -1 && cartLinesData.indexOf("11") != -1
					&& reqPayLoad.cartLines[0].items.length == 1)
			{
				context.setVariable("objectId", "051");
			}
			else if (cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("plans") != -1
					&& reqPayLoad.customerId == '9999')
			{
				context.setVariable("objectId", "012");
			}
			else if (cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("devices") != -1 && cartLinesData.indexOf("22") != -1)
			{
				context.setVariable("objectId", "053");
			}
			else if (cartLinesData.indexOf("plans,devices,accessories,services") != -1 && cartLinesData.indexOf("plans") != -1)
			{
				context.setVariable("objectId", "040");
			}

			else if (cartLinesData.indexOf("plans,devices,accessories") != -1 && cartLinesData.indexOf("devices") != -1)
			{
				context.setVariable("objectId", "003");
			}
			else if (cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("1") != -1)
			{
				context.setVariable("objectId", "049");
			}

		}
		/*    else if(reqPayLoad.cartLines.length==2)
		     {
		           if(cartLinesData.indexOf("plans") != -1 && cartLinesData.indexOf("101") != -1)
		            {
		              context.setVariable("objectId","004");
		            }
		     }
		    else if(reqPayLoad.cartLines.length==2)
		     {
		           if(cartLinesData.indexOf("1") != -1 && cartLinesData.indexOf("plans,devices,accessories,services") != -1)
		            {
		              context.setVariable("objectId","005");
		            }
		     }*/
	}
}