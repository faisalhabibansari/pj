var reqPayLoad = context.targetRequest.body.asJSON
if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1234'){
context.setVariable("objectId","0001");
}
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='5001') {
   context.setVariable("objectId","0002");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1501') {
   context.setVariable("objectId","0003");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1521') {
   context.setVariable("objectId","0004");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1300') {
   context.setVariable("objectId","0005");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1302') {
   context.setVariable("objectId","0006");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1504') {
   context.setVariable("objectId","0007");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1111') {
   context.setVariable("objectId","0008");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460000') {
   context.setVariable("objectId","0009");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460001') {
   context.setVariable("objectId","0010");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460002') {
   context.setVariable("objectId","0011");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='5555') {
   context.setVariable("objectId","0012");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='6767') {
   context.setVariable("objectId","0013");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='7766') {
   context.setVariable("objectId","0014");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='8899') {
   context.setVariable("objectId","0015");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='7777') {
   context.setVariable("objectId","0016");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='5008') {
   context.setVariable("objectId","0017");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1113') {
   context.setVariable("objectId","0018");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1509') {
   context.setVariable("objectId","0019");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1506') {
   context.setVariable("objectId","0020");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460005') {
   context.setVariable("objectId","0021");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1513') {
   context.setVariable("objectId","0022");
    }
    else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='7778') {
   context.setVariable("objectId","0023");
    }   
    else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='7779') {
   context.setVariable("objectId","0024");
    }
  else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='7780') {
   context.setVariable("objectId","0028");
    } 
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460004') {
   context.setVariable("objectId","0025");
    } 
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460006') {
   context.setVariable("objectId","0026");
    } 
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460007') {
   context.setVariable("objectId","0027");
    } 
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='460008') {
   context.setVariable("objectId","0028");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1685') {
   context.setVariable("objectId","0029");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1230') {
   context.setVariable("objectId","0030");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1533') {
   context.setVariable("objectId","0031");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1561') {
   context.setVariable("objectId","0032");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1565') {
   context.setVariable("objectId","0033");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='6666') {
   context.setVariable("objectId","0034");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='6667') {
   context.setVariable("objectId","0035");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1551') {
   context.setVariable("objectId","0036");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1555') {
   context.setVariable("objectId","0037");
    }
else if(reqPayLoad!=null && reqPayLoad!=''&& reqPayLoad.cartId =='1591') {
   context.setVariable("objectId","0038");
    }