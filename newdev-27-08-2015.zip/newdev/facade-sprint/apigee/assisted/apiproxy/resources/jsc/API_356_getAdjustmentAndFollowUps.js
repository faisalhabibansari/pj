var token = context.getVariable('request.header.token')
var repId = context.getVariable("request.queryparam.repId");
var managerId = context.getVariable("request.queryparam.managerId")
var needTeam = context.getVariable("request.queryparam.needTeam")
var type = context.getVariable("request.queryparam.type")
var status = context.getVariable("request.queryparam.status")

context.setVariable("dataType", 'getAdjustmentAndFollowUps');

if (token == 'fx00wmdlxw0')
{
	context.setVariable("objectId", "001");}
	
else if (token == 'md00avkxna0')
{
	if (repId == 'CWalters123' && managerId == 'hsherman' && needTeam == 'true')
	{
		context.setVariable("objectId", "003");
	}
	else if (repId == 'CParker123' && managerId == 'CWalters123' && needTeam == 'false')
	{
		context.setVariable("objectId", "004");
	}
	else
	{
		context.setVariable("objectId", "002");
	}
}
else if (token == '00xsa55nbu')
{
	if (type=='followUp' && status == 'closed')
	{
		context.setVariable("objectId", "005");
	}
	else
	{
		context.setVariable("objectId", "006");
	}
}

else if (token == '00x34frsdc'){
  context.setVariable("objectId", "007");} 