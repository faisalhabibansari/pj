var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postsuggestedProducts");
if (reqPayLoad.hasOwnProperty('suggestedProducts'))
{
    if(reqPayLoad.suggestedProducts instanceof Array && reqPayLoad.suggestedProducts[0].productId=='IP64') 
    { 
    	context.setVariable("objectId", "001");
    }
}