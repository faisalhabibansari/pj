var reqPayLoad = context.targetRequest.body.asJSON
var firstName = reqPayLoad.firstName;
var lastName = reqPayLoad.lastName;
if (reqPayLoad.hasOwnProperty('addresses'))
{
    if(reqPayLoad.addresses instanceof Array) 
    { 
    	var address1 = reqPayLoad.addresses[0].address1
    }
}
if (reqPayLoad.hasOwnProperty('phones'))
{
    if(reqPayLoad.phones instanceof Array) 
    { 
    	var phone = reqPayLoad.phones[0].phone
    }
}
if (reqPayLoad.hasOwnProperty('emails'))
{
    if(reqPayLoad.emails instanceof Array) 
    { 
    	var email = reqPayLoad.emails[0].email
    }
}


if(firstName=='sam' && lastName=='smith' && address1=='123 king st'){
  context.setVariable("objectId", "12345678");
}
else if((firstName==null || firstName=='') && (lastName==null || lastName=='') && address1=='123 king st'){
  context.setVariable("objectId", "9988324");
}
else if((firstName==null || firstName=='') && (lastName==null || lastName=='') && address1=='123 T-Mobile Way Drive'){
  context.setVariable("objectId", "1111111");
}
else if(phone=='(111) 111-1111' && email=='name@domain.com' && address1=='123 king Station'){
  context.setVariable("objectId", "004");
}
else if(phone=='(111) 111-1111' && (email==null || email=='') && (address1==null || address1=='')){
  context.setVariable("objectId", "001");
}
else if((phone==null || phone=='') && email=='name@domain.com' && (address1==null || address1=='')){
  context.setVariable("objectId", "002");
}
else if((phone==null || phone=='') && (email==null || email=='') && address1=='123 king Station'){
  context.setVariable("objectId", "003");
}
else if(email=='john.smith@hotmail.com'){
  context.setVariable("objectId", "005");
}
else{
  context.setVariable("objectId", "");
}