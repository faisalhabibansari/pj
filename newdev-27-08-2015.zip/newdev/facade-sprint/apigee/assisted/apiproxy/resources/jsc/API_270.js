var reqPayLoad = context.targetRequest.body.asJSON;
context.setVariable("dataType", "reportingLostStolenDevice"); 
if(reqPayLoad!=null) 
{ 
var msisdn = reqPayLoad.msisdn; 
  var msisdn1 = reqPayLoad.MSISDN;

if(msisdn=='1231231233' || msisdn=='1231231232' || msisdn=='1231231231' || msisdn=='4254356547' || msisdn=='4254357654' || msisdn=='4251234567' || msisdn=='3212524095' || msisdn=='2061234567' || msisdn=='2061233333')

{ 
context.setVariable("objectId", '20131010398547'); 
} 
else if (msisdn1=='4254357788')
 {
   context.setVariable("objectId", '001');
}
else if (msisdn1=='2061231234')
 {
   context.setVariable("objectId", '002');
}
}