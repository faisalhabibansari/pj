//var reqPayLoad = context.targetRequest.body.asJSON
//context.setVariable("dataType","AccountSettings");
//if(reqPayLoad!=null && reqPayLoad!=''){
//context.setVariable("objectId","001");
//}
  //  else{
   //context.setVariable("objectId","000");
    //}

//var msisdn1;
//var msisdn2;
var request_payload = context.targetRequest.body.asJSON
context.setVariable("dataType","AccountSettings");

var msisdns = [];
var lines = request_payload.lines;
for (var i = 0;i<lines.length;i++)
{
  msisdns.push(lines[i].msisdn);
}

if(lines.length==3 && msisdns.indexOf("2061234567") != -1 && msisdns.indexOf("6021234577") != -1 && msisdns.indexOf("6021234511") != -1 ){
   context.setVariable("objectId","002");
}else if(lines.length==2 && msisdns.indexOf("2061234567") != -1 && msisdns.indexOf("6021234577") != -1){
  context.setVariable("objectId","005");
}else if(lines.length==1 && msisdns.indexOf('2061234567')!=-1){
   context.setVariable("objectId","003");
}else if(lines.length==1 && msisdns.indexOf('6021234577')!=-1){
   context.setVariable("objectId","004");
}
else if(lines.length==1 && msisdns.indexOf('6021234511')!=-1){
   context.setVariable("objectId","006");
}
else if(lines.length==1 && msisdns.indexOf('6021234512')!=-1){
   context.setVariable("objectId","007");
}
else if(lines.length==1 && msisdns.indexOf('4254357788')!=-1){
   context.setVariable("objectId","008");
}
else if(lines.length==1 && msisdns.indexOf('4254354466')!=-1){
   context.setVariable("objectId","011");
}
else if(lines.length==2 && msisdns.indexOf('4254357788')!=-1 && msisdns.indexOf('4254352233')!=-1){
   context.setVariable("objectId","012");
}
else if(lines.length==1 && msisdns.indexOf('4254352233')!=-1){
   context.setVariable("objectId","013");
}
else if(lines.length==2 && msisdns[0]=='4254357788' && msisdns[1]=='4254352233'){
   context.setVariable("objectId","014");
}
else if(lines.length==1 && msisdns.indexOf('4254353399')!=-1){
   context.setVariable("objectId","009");
}
else if(lines.length==2 && msisdns[0]=='4254357788' && msisdns[1]=='4254353399'){
   context.setVariable("objectId","010");
}
else if(lines.length==2 && msisdns[0]=='' && msisdns[1]==''){
   context.setVariable("objectId","001");
}
else if(lines.length==1 && msisdns.indexOf('2061231234')!=-1){
   context.setVariable("objectId","015");
}





/*var msisdn = request_payload.lines[0].msisdn;
if(request_payload.lines.length==2){
   msisdn1 = request_payload.lines[1].msisdn;
}
if(request_payload.lines.length==3){
    msisdn2 = request_payload.lines[2].msisdn;
   }
if(msisdn=='2061234567' && msisdn1=='6021234577' && msisdn2=='6021234511')
{
   context.setVariable("objectId","002");
}
else if(msisdn=='2061234567')
{
   context.setVariable("objectId","003");
}
else if(msisdn=='6021234577')
{
   context.setVariable("objectId","004");
}
  else if(msisdn==''&& msisdn1=='')
{
   context.setVariable("objectId","001");
}*/