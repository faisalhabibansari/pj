var zipCode=context.getVariable("request.queryparam.zipCode"); 
context.setVariable('dataType', 'getCityStatebyZip');

 if(zipCode=='85281')
 {
   context.setVariable("objectId", "001");
 }
 else if(zipCode=='98004')
 {
   context.setVariable("objectId", "002");
 }
 else if(zipCode=='97001')
 {
   context.setVariable("objectId", "003");
 }
 else if(zipCode=='97002')
 {
   context.setVariable("objectId", "004");
 }
 else if(zipCode=='98989')
 {
   context.setVariable("objectId", "005");
 }
 else if(zipCode=='98111')
 {
     context.setVariable("objectId", "006");
 }
 else 
 {
   context.setVariable("objectId", "000");
 }   
  