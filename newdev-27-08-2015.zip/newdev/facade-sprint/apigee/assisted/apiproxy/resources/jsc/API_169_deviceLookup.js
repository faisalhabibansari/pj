// FOR API 169 having url /v1/customers/{customerID}/devices
//query parameter
var imei = context.getVariable("request.queryparam.imei");
var esn = context.getVariable("request.queryparam.esn");
var meid = context.getVariable("request.queryparam.meid");
var macId = context.getVariable("request.queryparam.macid");
// var customerID=context.getVariable("customers");
var customerID = context.getVariable("objectId");

context.setVariable("dataType", "deviceLookup");

if (esn != null && meid == null && macId == null && imei == null)
{
	context.setVariable("objectId", esn);
}

else if (esn == null && meid != null && macId == null && imei == null)
{
	context.setVariable("objectId", meid);
}

else if (esn == null && meid == null && macId != null && imei == null)
{
	context.setVariable("objectId", macId);
}

/*if( esn==null && meid==null && macId==null && imei != null && imei=='354904008327814'){
	context.setVariable("objectId",imei);

}else if( meid==null && imei==null && macId==null && esn!=null && esn=='1BCC5FDF'){
	context.setVariable("objectId",esn);				

}else if( esn==null && imei==null && macId==null && meid!=null && meid=='268435456010201020'){
	context.setVariable("objectId",meid);

}else if(esn==null && meid==null && macId==null && imei!=null && imei=='356489052784746'){
	context.setVariable("objectId",imei);

}else if(esn==null && meid==null && macId==null && imei!=null && imei== '535934655968752'){
	context.setVariable("objectId",imei);

}else if(esn==null && meid==null && macId==null && imei!=null && imei=='380332443958274'){
	context.setVariable("objectId",imei);

} else if (esn==null && meid==null && imei==null && macId!=null && macId=='0123.4567.89ab'){
	context.setVariable("objectId",macId);

} else if (esn=='1BCC5FDA' && meid==null && imei==null && macId==null && esn!=null) {
 	context.setVariable("objectId",esn); 
  
} else if (esn=='1BCC5FDB' && meid==null && imei==null && macId==null && esn!=null) {
 	context.setVariable("objectId",esn); 
}

//	else {
//		context.setVariable("objectId","000");
//	}
*/

// FOR API 194 having url /v1/customers/{customerID}/devices
else if (esn == null && meid == null && imei == null && macId == null && esn == null)
{

	var objectId = context.getVariable("objectId");
	context.setVariable("dataType", "deviceDetails");
	context.setVariable("objectId", objectId);
}

// QAT 169
else if (customerID == '3000000028' && imei == '352067061242627')
{
	context.setVariable("objectId", "656");
}
else if (customerID == '3000000031' && imei == '352067067426745')
{
	context.setVariable("objectId", "659");
}
else if (customerID == '3000000032' && imei == '352067064255220')
{
	context.setVariable("objectId", "660");
}
else if (customerID == '3000000033' && imei == '352067065092200')
{
	context.setVariable("objectId", "661");
}

else if (customerID == '3000000028' && imei == '359444022017401')
{
	context.setVariable("objectId", "001");
}
else if (customerID == '3000000028' && imei == '359444029814107')
{
	context.setVariable("objectId", "002");
}
else if (customerID == '3000000031' && imei == '359444026047156')
{
	context.setVariable("objectId", "003");
}
else if (customerID == '3000000031' && imei == '359444026857810')
{
	context.setVariable("objectId", "004");
}
else if (customerID == '3000000032' && imei == '359444024823087')
{
	context.setVariable("objectId", "005");
}
else if (customerID == '3000000032' && imei == '359444026711991')
{
	context.setVariable("objectId", "006");
}
else if (customerID == '3000000033' && imei == '359444027268439')
{
	context.setVariable("objectId", "007");
}
else if (customerID == '3000000033' && imei == '359444022965195')
{
	context.setVariable("objectId", "008");
}
else if (customerID == '3000000034' && imei == '359444029338156')
{
	context.setVariable("objectId", "009");
}
else if (customerID == '3000000034' && imei == '359444025563815')
{
	context.setVariable("objectId", "010");
}
else if (customerID == '3000000007' && imei == '359444027338612')
{
	context.setVariable("objectId", "011");
}
else if (customerID == '3000000007' && imei == '359444022524943')
{
	context.setVariable("objectId", "012");
}
else if (customerID == '3000000008' && imei == '359444026859485')
{
	context.setVariable("objectId", "013");
}
else if (customerID == '3000000008' && imei == '359444023421917')
{
	context.setVariable("objectId", "014");
}
else if (customerID == '3000000050' && imei == '359444023426304')
{
	context.setVariable("objectId", "015");
}
else if (customerID == '3000000035' && imei == '359444022872672')
{
	context.setVariable("objectId", "016");
}
else if (customerID == '3000000036' && imei == '359444029281406')
{
	context.setVariable("objectId", "017");
}
else if (customerID == '3000000037' && imei == '359444025152205')
{
	context.setVariable("objectId", "018");
}
else if (customerID == '3000000038' && imei == '359444028222336')
{
	context.setVariable("objectId", "019");
}
else if (customerID == '3000000039' && imei == '359444026481819')
{
	context.setVariable("objectId", "020");
}
else if (customerID == '3000000041' && imei == '359444024056571')
{
	context.setVariable("objectId", "021");
}
// QAT End

else if (esn == null && meid == null && macId == null && imei != null)
{
	context.setVariable("objectId", imei);
}
else
{
	context.setVariable("objectId", "000");
}
