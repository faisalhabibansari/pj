var type=context.getVariable("request.queryparam.type");
if(type=='shippingLabel')
{
  	context.setVariable("objectId","001")
}
else
{
  	context.setVariable("objectId","002");
}