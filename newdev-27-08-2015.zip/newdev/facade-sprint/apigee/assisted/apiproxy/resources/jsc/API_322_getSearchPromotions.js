  var q=context.getVariable("request.queryparam.q");
 // var promos=context.getVariable("request.queryparam.promos");
  var promoCode=context.getVariable("request.queryparam.promoCode");
  var offset=context.getVariable("request.queryparam.offset");
  var limit=context.getVariable("request.queryparam.limit");
  var sort=context.getVariable("request.queryparam.sort");
  var sortOrder=context.getVariable("request.queryparam.sortOrder");
  var filter=context.getVariable("request.queryparam.filter");


context.setVariable("promoCode---",promoCode); 

if(promoCode!=null && promoCode!="")
{
  promoCode = promoCode.toLowerCase();
}
  
  context.setVariable("dataType","getSearchPromotions");
  
  if(q=="smart phone")
  {
   context.setVariable("objectId","001");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="endDate" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","003");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="endDate" && sortOrder=="desc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","004");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="startDate" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","005");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="startDate" && sortOrder=="desc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","006");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","007");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="desc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","008");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="status" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","009");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="status" && sortOrder=="desc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","010");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=active,category=prepaid,state=or,city=beaverton,zipCode=97003,storeId=9700")
  {
   context.setVariable("objectId","011");
  }
//else if(promos=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=active,category=prepaid,state=all,city=all,zipCode=all,storeId=all")
  //{
   //context.setVariable("objectId","012");
  //}
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="desc" && filter=="status=active,category=prepaid,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","013");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=prepaid,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","014");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="desc" && filter=="status=all,category=prepaid,state=all,city=all,zipCode=all,storeId=all")
  {
   context.setVariable("objectId","021");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=or,city=astoria,zipCode=all,storeId=all")
{context.setVariable("objectId","015");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=or,city=beaverton,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","016");
  }
  else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=or,city=all,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","017");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=active,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","018");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=or,city=beaverton,zipCode=all,storeId=9700")
  {
    context.setVariable("objectId","019");
  }
else if(promoCode=="phone" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=or,city=beaverton,zipCode=97003,storeId=all")
  {
    context.setVariable("objectId","020");
  }
  else if(promoCode=="25*" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","022");
  }
  else if(promoCode=="p*id" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","023");
  }
  else if(promoCode=='prépáíd' && offset=='0' && limit=='10' && sort=='promoName' && sortOrder=='asc' && filter=='status=all,category=all,state=all,city=all,zipCode=all,storeId=all')
  {
    context.setVariable("objectId","024");
  }
  else if(promoCode=="save3*" && offset=="0" && limit=="10" && sort=="promoName" && sortOrder=="asc" && filter=="status=all,category=all,state=all,city=all,zipCode=all,storeId=all")
  {
    context.setVariable("objectId","025");
  }
  else 
  {
   context.setVariable("objectId","000");
  }