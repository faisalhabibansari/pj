var id = context.getVariable("objectId");
var reqPayLoad = context.targetRequest.body.asJSON;

var requestJSON = '';

if(reqPayLoad!=null&&reqPayLoad!='') {
	requestJSON = JSON.stringify(reqPayLoad);
}

/*if(id!=null && id == '7780') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
	{
		if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1) 
		 {
				context.setVariable("objectId","103");
		 }
	}
}*/
if(id!=null && id == '1509') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
	  {
		if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234567") != -1) 
		 {
				context.setVariable("objectId","0041");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456670") != -1) 
		 {
				context.setVariable("objectId","0044");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1 && requestJSON.indexOf("123456678") != -1) 
		 {
				context.setVariable("objectId","0042");
		 }
        else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("4251234570") != -1 && requestJSON.indexOf("4251234571") != -1) 
		 {
				context.setVariable("objectId","103");
		 }
		 else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && requestJSON.indexOf("741852") != -1) 
		 {
				context.setVariable("objectId","0043");
         }
        
	 }
}

else if(id!=null && id == '1690'){
  context.setVariable("objectId","093");}
else if(id!=null && id == '1685'){
  context.setVariable("objectId","094");}

else if(id!=null && id == '4444')
{
    if(reqPayLoad.cartLines instanceof Array) 
        {
            if(reqPayLoad.cartLines.length==3) 
            {
              if(requestJSON.indexOf("456786") != -1) 
              {
               context.setVariable("objectId","085");
              }
              else if(requestJSON.indexOf("456787") != -1) 
              {
               context.setVariable("objectId","086");
              }
            }
            else if(reqPayLoad.cartLines.length==2) 
            {
              if(requestJSON.indexOf("456785") != -1) 
              {
               context.setVariable("objectId","087");
              }
              else if(requestJSON.indexOf("456787") != -1) 
              {
               context.setVariable("objectId","087");
              }
            }
            else if(reqPayLoad.cartLines.length==1) 
            {
              if(requestJSON.indexOf("456785") != -1) 
              {
               context.setVariable("objectId","088");
              }
              else if(requestJSON.indexOf("123991") != -1) 
              {
               context.setVariable("objectId","092");
              }
             
            }
        }
}
else if(id!=null && id == '1551') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items[0].productId=='101' && reqPayLoad.cartLines[0].items[1].productId=='111') 
     {
        context.setVariable("objectId","105");
     }
  }
}
else
{
  context.setVariable("objectId",id);
}

