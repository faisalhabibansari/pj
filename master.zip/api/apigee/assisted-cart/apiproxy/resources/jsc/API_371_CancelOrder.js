var objectId = context.getVariable("objectId");
context.setVariable("objectId",objectId);
context.setVariable("dataType","CancelOrder");