var id = context.getVariable("objectId");
var reqPayLoad = context.targetRequest.body.asJSON;

var requestJSON = '';

if(reqPayLoad!=null&&reqPayLoad!='') {
  requestJSON = JSON.stringify(reqPayLoad);
}

if(id!=null && id == '1234'){
  context.setVariable("objectId",'1234');
} 
else if(id!=null && id == '1300')
{
  if (reqPayLoad.hasOwnProperty('payment'))
  {
   if(reqPayLoad.payment.cardNumber=="4915491549154915")
   {
      context.setVariable("objectId","1306");
   }
    else if (reqPayLoad.payment.paymentMethod=="CheckingAccount" && reqPayLoad.payment.accountNumber=="212012045150156") 
    {
        context.setVariable("objectId","1307");
    }
    else if (reqPayLoad.payment.paymentMethod=="CreditCard" && reqPayLoad.payment.nameOnCard=="JohnJDoe") 
    {
        context.setVariable("objectId","1308");
    }  
  }
  else if (reqPayLoad.hasOwnProperty('items'))
  {
    if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2512' && reqPayLoad.items[1].productId == 'pln2516') 
    {
    context.setVariable("objectId","1301");
  }
    else if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2513' && reqPayLoad.items[1].productId == 'pln2517') 
    {
    context.setVariable("objectId","1302");
    }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].productId == 'pln2512' && reqPayLoad.items[1].productId == '101') 
    {
    context.setVariable("objectId","1309");
    }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].productId == 'pln2517' && reqPayLoad.items[1].productId == '102') 
    {
    context.setVariable("objectId","1310");
    }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==4 && reqPayLoad.items[0].actionCode == 'Duplicate') 
    {
    context.setVariable("objectId","001");
    }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == 'pln2512') 
    {
    context.setVariable("objectId","004");
    }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == 'pln2511') 
    {
    context.setVariable("objectId","005");
    }
  }
  else if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items[0].priceOverride.overridePrice == 35) 
    {
    context.setVariable("objectId","002");
    }
    else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items[0].priceOverride.overridePrice == 15) 
    {
    context.setVariable("objectId","003");
    }
  }
}

else if(id!=null && id == '1200')
{
  if (reqPayLoad.hasOwnProperty('payment'))
  {
   if(reqPayLoad.payment.routingNumber=="11111")
   {
      context.setVariable("objectId","1315");
   }
    else if(reqPayLoad.payment.paymentMethod=="CreditCard" && reqPayLoad.payment.nameOnCard=="JohnJDoe"){
      context.setVariable("objectId","1317");}
      
      }}
else if(id!=null && id == '1309')
{
  if (reqPayLoad.hasOwnProperty('payment'))
  {
   if(reqPayLoad.payment.routingNumber=="11111")
   {
      context.setVariable("objectId","1316");
   }
    else if(reqPayLoad.payment.paymentMethod=="CreditCard" && reqPayLoad.payment.nameOnCard=="JohnJDoe"){
      context.setVariable("objectId","1318");}
  }
}
else if(id!=null && id == '1444')
{
  if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == "pln2511") 
    {
    context.setVariable("objectId","006");
    }
  }
    //context.setVariable("objectId","1444");
}
else if(id!=null && id == '1333')
{
  if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == "pln2511") 
    {
    context.setVariable("objectId","007");
    }
  }
    //context.setVariable("objectId","1333");
}
else if(id!=null && id == '1222')
{
  if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == "pln2511") 
    {
    context.setVariable("objectId","008");
    }
  }
    //context.setVariable("objectId","1222");
}
else if(id!=null && id == '1555')
{
    context.setVariable("objectId","1555");
}
else if(id!=null && id == '999')
{
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.hasOwnProperty('orphanEips') && reqPayLoad.hasOwnProperty('destination'))
  {
   if(reqPayLoad.destination.customerId=="12344")
   {
     context.setVariable("objectId","009");
   }
  }
}
else if(id!=null && id == '998')
{
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.hasOwnProperty('orphanEips') && reqPayLoad.hasOwnProperty('destination'))
  {
   if(reqPayLoad.destination.customerId=="")
   {
     context.setVariable("objectId","010");
   }
  }
}
else if(id!=null && id == '460000')
{
  if (reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
  if(reqPayLoad.items.length==2 && reqPayLoad.items[0].productId=='11' && reqPayLoad.items[1].productId=='9999')
    {
     if(reqPayLoad.originalOrderId=='4800404')
        {
          context.setVariable("objectId","error404");
          }
    else if(reqPayLoad.originalOrderId=='4800500')
      {
        context.setVariable("objectId","error500");
        }
     }
  else
  {
    context.setVariable("objectId","011");
    }
  }
  else if (reqPayLoad.hasOwnProperty('payments') && reqPayLoad.payments instanceof Array)
  {
     context.setVariable("objectId","0111");
  }
  else { context.setVariable("objectId","01111"); }
}
else if(id!=null && id == '460001')
{
  if (reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
     if(reqPayLoad.items.length==1 && reqPayLoad.items[0].productId=='11')
    {
      if(reqPayLoad.originalOrderId=='4800404')
      {
        context.setVariable("objectId","error404");
        }
      else if(reqPayLoad.originalOrderId=='4800500')
      {
        context.setVariable("objectId","error500");
        }
    }
  else
  {
    context.setVariable("objectId","012");
    }
  }
   else if(reqPayLoad.hasOwnProperty('payments') && reqPayLoad.payments instanceof Array)
  {
   context.setVariable("objectId","071");
  }
}
else if(id!=null && id == '460002')
{
     context.setVariable("objectId","013");
}
else if(id!=null && id == '1600')
{
  if (requestJSON.indexOf("TM0M12345") != -1) 
  {
   context.setVariable("objectId","014");  
  }
  else if (requestJSON.indexOf("A100/10005") != -1) 
  {
   context.setVariable("objectId","014");  
  }
  else if (requestJSON.indexOf("A5002/5002") != -1) 
  {
   context.setVariable("objectId","014");  
  }
  else if (requestJSON.indexOf("A100/10009") != -1) 
  {
   context.setVariable("objectId","014");  
  }
}
else if(id!=null && id == '1610')
{
  if (requestJSON.indexOf("123456789012345678") != -1) 
  {
   context.setVariable("objectId","023");  
  }
  else if (requestJSON.indexOf("123456789012379234") != -1) 
  {
   context.setVariable("objectId","015");  
  }
  else if (requestJSON.indexOf("supm123843") != -1) 
  {
   context.setVariable("objectId","015");  
  }
}
else if(id!=null && id == '5001') {
  
  if (reqPayLoad.destination.customerId == "500000001" && reqPayLoad.destination.accountId == "123125")
    {
      context.setVariable("objectId","123125");
    }
      else if(reqPayLoad.destination.customerId == "500000001" && reqPayLoad.destination.accountId == "123124") 
    {
         context.setVariable("objectId","042");
        }
        else if(reqPayLoad.destination.customerId == "500000001" && reqPayLoad.destination.accountId == "123991") 
        {
         context.setVariable("objectId","100");
        }
  else if(reqPayLoad.destination.customerId == "500000001" && reqPayLoad.destination.accountId == '') 
        {
         context.setVariable("objectId","101");
        }
}
else if(id!=null && id == '5002') {
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "6021234578" && reqPayLoad.destination.accountId == "666666")
    {
      context.setVariable("objectId","666666");
    }
      
  else if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "8182223334" && reqPayLoad.destination.accountId == "123123")
    {
      context.setVariable("objectId","123123");
    }
      
}
else if(id!=null && id == '5003') {
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "6021234578" && reqPayLoad.destination.accountId == "555555")
    {
      context.setVariable("objectId","555555");
    }     
}
else if(id!=null && id == '5004') {
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "2063234567" && reqPayLoad.destination.accountId == "123125")
    {
      context.setVariable("objectId","2063234567");
    } 
}
else if(id!=null && id == '5005') {
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "2063234567" && reqPayLoad.destination.accountId == "123990")
    {
      context.setVariable("objectId","123990");
    } 
}
else if(id!=null && id == '5006') {
  if (reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines[0].msisdn == "2063234567" && reqPayLoad.destination.accountId == "123991")
    {
      context.setVariable("objectId","123991");
    } 
}
else if(id!=null && id == '1511') {
      if (reqPayLoad.hasOwnProperty('items'))
    {
        if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==5 && requestJSON.indexOf("1") != -1 && requestJSON.indexOf("2") != -1 && requestJSON.indexOf("3") != -1 && requestJSON.indexOf("4") != -1 && requestJSON.indexOf("5") != -1) 
      {
        context.setVariable("objectId","017");
      }
      }
      else
      {
       context.setVariable("objectId","1511");
      }
}
else if(id!=null && id == '1111') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
    {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && requestJSON.indexOf("123125") != -1) 
     {
        context.setVariable("objectId","018");
     }
        else if (reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && requestJSON.indexOf("123124") != -1){
          context.setVariable("objectId","063");
        }
        else if (reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && requestJSON.indexOf("123990") != -1){
          context.setVariable("objectId","064");
        }
        else if (reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && requestJSON.indexOf("123991") != -1){
          context.setVariable("objectId","065");
        }      
    }
}
else if(id!=null && id == '1115') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
    {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && requestJSON.indexOf("500000011") != -1 && requestJSON.indexOf("6021234578") != -1) 
     {
        context.setVariable("objectId","019");
     }
    }
}
else if(id!=null && id == '1512') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
    {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") != -1 && requestJSON.indexOf("Peter L Whitman") != -1 && requestJSON.indexOf("Jack Whitman") != -1) 
     {
        context.setVariable("objectId","020");
     }
    }
}
else if(id!=null && id == '1612') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012379234") != -1)
     {
        context.setVariable("objectId","021");
     }
    }
}
else if(id!=null && id == '1501') 
{
  if(reqPayLoad.hasOwnProperty('payments'))
  {
   context.setVariable("objectId","4141");
  }
}
else if(id!=null && id == '1613') 
{
   if (reqPayLoad.hasOwnProperty('items')  &&  reqPayLoad.items instanceof Array)
    {
    if(reqPayLoad.items.length==2) 
     {
           if(requestJSON.indexOf("supm123843") != -1)
           {
            context.setVariable("objectId","022");
           }
           else if(requestJSON.indexOf("123456789012345789") != -1)
           {
            context.setVariable("objectId","067");
           }  
     }
    } 
}
else if(id!=null && id == '1611') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012379234") != -1) 
     {
        context.setVariable("objectId","024");
     }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("8901234567890133456F") != -1){
          context.setVariable("objectId","025");}
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("8901234567890123456F") != -1 ){
          context.setVariable("objectId","026");}
         else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("8901234567890133456F") != -1 ){
          context.setVariable("objectId","027");
         }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("897654321987654321B") != -1 )
        {
          context.setVariable("objectId","043");
        }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("987654321987654321A") != -1 )
        {
          context.setVariable("objectId","044");
        }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("897654321987654321B") == -1 && requestJSON.indexOf("987654321987654321A") == -1)
        {
          context.setVariable("objectId","045");
        }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("897654321987654321B") != -1 )
        {
          context.setVariable("objectId","046");
        }
        else if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("1PMX134LL/A") != -1)
        {
          context.setVariable("objectId","0036");
        }
      }
}
else if(id!=null && id == '1506') 
{
  if(reqPayLoad.hasOwnProperty('promotions'))
  {
   context.setVariable("objectId","028");
  }
  else if(reqPayLoad.hasOwnProperty('payments') && reqPayLoad.payments instanceof Array)
  {
   context.setVariable("objectId","072");
  }
  else if(reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
    if(reqPayLoad.items.length==3)
    {
       context.setVariable("objectId","035");
    }
    else if(reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '28' && reqPayLoad.items[0].priceOverride.overridePrice==640.92)
    {
       context.setVariable("objectId","036");
    }
    else if(reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '28' && reqPayLoad.items[0].priceOverride.overridePrice==619.92)
    {
       context.setVariable("objectId","037");
    }
    else if(reqPayLoad.items.length==1 && reqPayLoad.items[0].priceOverride.overridePrice==640.92)
    {
       context.setVariable("objectId","036");
    }
    else if(reqPayLoad.items.length==1 && reqPayLoad.items[0].priceOverride.overridePrice==619.92)
    {
       context.setVariable("objectId","037");
    }
    }
  else if(reqPayLoad.hasOwnProperty('cartLines') && reqPayLoad.cartLines instanceof Array)
  {
    if(reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].lineId=='1'  && reqPayLoad.cartLines[0].lineName=='Francis Whitman')
    {
       context.setVariable("objectId","066");
    }
  }
}
else if(id!=null && id == '1507') 
{
  if(reqPayLoad.hasOwnProperty('promotions') && reqPayLoad.promotions instanceof Array)
  {
  if(reqPayLoad.promotions.length==1)
   {
    if(reqPayLoad.promotions[0].id=='TMOBILE20')
    {
    context.setVariable("objectId","029");
    }
    else if(reqPayLoad.promotions[0].id=='FREESIM')
    {
    context.setVariable("objectId","053");
    }
   } 
  }
}
else if(id!=null && id == '1508') 
{
  if(reqPayLoad.hasOwnProperty('promotions'))
  {
   context.setVariable("objectId","051");
  }
}
else if(id!=null && id == '1513') 
{
  if(reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
    if(reqPayLoad.items.length==3)
    {
    context.setVariable("objectId","038");
    }
   else if(reqPayLoad.items.length==4)
    {
    context.setVariable("objectId","999");
    }
    
      else if (reqPayLoad.items.length==2)
    {
      if (requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("987654321987654321A") != -1 )
        {
          context.setVariable("objectId","047");
        }
      else if (requestJSON.indexOf("000000123456782109") != -1){
        context.setVariable("objectId","000000123456782109");}
    }
  }
}
else if(id!=null && id == '1521') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
    {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") != -1 && requestJSON.indexOf("Peter L Whitman") == -1 && requestJSON.indexOf("104") == -1 && requestJSON.indexOf("14") == -1) 
     {
        context.setVariable("objectId","030");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") != -1 && requestJSON.indexOf("Peter L Whitman") == -1 && requestJSON.indexOf("104") != -1 && requestJSON.indexOf("14") == -1) 
     {
        context.setVariable("objectId","031");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") != -1 && requestJSON.indexOf("Peter L Whitman") == -1 && requestJSON.indexOf("104") != -1 && requestJSON.indexOf("14") != -1) 
     {
        context.setVariable("objectId","032");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") != -1 && requestJSON.indexOf("Peter L Whitman") != -1 && requestJSON.indexOf("Jack Whitman") != -1) 
     {
        context.setVariable("objectId","033");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && requestJSON.indexOf("Francis Whitman") == -1 && requestJSON.indexOf("Peter L Whitman") == -1 && requestJSON.indexOf("Jack Whitman") == -1) 
     {
        context.setVariable("objectId","034");
     }
         else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==1 && requestJSON.indexOf("101") == -1 && requestJSON.indexOf("plan") == -1 && requestJSON.indexOf("device") == -1) 
     {
        context.setVariable("objectId","052");
     }
         else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==1 && requestJSON.indexOf("101") == -1 && requestJSON.indexOf("plan") != -1) 
     {
        context.setVariable("objectId","054");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==1 && requestJSON.indexOf("11") != -1 && requestJSON.indexOf("device") != -1) 
     {
        context.setVariable("objectId","055");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==2 && requestJSON.indexOf("11") != -1 && requestJSON.indexOf("device") != -1 && requestJSON.indexOf("service") != -1) 
     {
        context.setVariable("objectId","056");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==2 && requestJSON.indexOf("11") != -1 && requestJSON.indexOf("device") != -1 && requestJSON.indexOf("plan") != -1) 
     {
        context.setVariable("objectId","057");
     }
     else if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.cartLines[0].items.length==2 && requestJSON.indexOf("11") != -1 && requestJSON.indexOf("device") != -1 && requestJSON.indexOf("accessory") != -1) 
     {
        context.setVariable("objectId","058");
     }
    
    }
   else if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==5)
      {
        context.setVariable("objectId","070");
      }
    else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("1PMX134LL/A") != -1 ) 
     {
        context.setVariable("objectId","075");
     }
    }
    else if (reqPayLoad.hasOwnProperty('payments'))
    {
    if(reqPayLoad.payments instanceof Array && reqPayLoad.payments.length==1 && requestJSON.indexOf("12345678900000") != -1)
      {
        context.setVariable("objectId","083");
      }
    else if(reqPayLoad.payments instanceof Array && reqPayLoad.payments.length==2 && requestJSON.indexOf("12345678900000") != -1)
      {
        context.setVariable("objectId","084");
      }
    }
}
else if(id!=null && id == '1630') 
{
  if (reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
      if (reqPayLoad.items.length==2)
    {
      if (requestJSON.indexOf("supm123843") != -1)
        {
          context.setVariable("objectId","048");
        }
        else if(requestJSON.indexOf("123456789012345789") != -1)
        {
      context.setVariable("objectId","068");
    }
    }
  }
}
else if(id!=null && id == '1631') 
{
  if (reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
      if (reqPayLoad.items.length==2)
    {
      if (requestJSON.indexOf("123456789012345678") != -1 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("987654321987654321A") != -1)
        {
          context.setVariable("objectId","049");
        }
    }
  }
}
else if(id!=null && id == '1632') 
{
  if (reqPayLoad.hasOwnProperty('items') && reqPayLoad.items instanceof Array)
  {
      if (reqPayLoad.items.length==2)
    {
      if (requestJSON.indexOf("123456789012379234") != -1 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("897654321987654321B") != -1)
        {
          context.setVariable("objectId","050");
        }
    }
  }
}
else if(id!=null && id == '1501') 
{
  if (reqPayLoad.hasOwnProperty('items'))
    {
      if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].productId == '4001' && reqPayLoad.items[1].productId == "pln2799") 
      {
        context.setVariable("objectId","1304");
      }
        else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '4001' && reqPayLoad.items[0].priceOverride.overridePrice == "750.99") 
      {
        context.setVariable("objectId","1305");
      }
        else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '4001' && reqPayLoad.items[0].priceOverride.overridePrice == "729.99") 
      {
        context.setVariable("objectId","1326");
      }
            else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("14") != -1 && requestJSON.indexOf("15") != -1) 
      {
        context.setVariable("objectId","016");
      }
            else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==3) 
      {
        context.setVariable("objectId","039");
      }
      else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '4001' && reqPayLoad.items[0].priceOverride.overridePrice == 640.92) 
      {
        context.setVariable("objectId","040");
      }
      else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '4001' && reqPayLoad.items[0].priceOverride.overridePrice == 619.92) 
      {
        context.setVariable("objectId","041");
      }
          else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '28' && reqPayLoad.items[0].priceOverride.overridePrice == 640.92) 
      {
        context.setVariable("objectId","040");
      }
      else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId == '28' && reqPayLoad.items[0].priceOverride.overridePrice == 619.92) 
      {
        context.setVariable("objectId","041");
      }
          else 
      {
        context.setVariable("objectId","4141");
      }
            
    }
}
else if(id!=null && id == '1513') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("987654321987654321A") != -1) 
     {
        context.setVariable("objectId","0029");
     }
      
      }
}
else if(id!=null && id == '1630') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("supm123843") != -1) 
     {
        context.setVariable("objectId","0030");
     }
      
      }
}
else if(id!=null && id == '1631') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012379") != -1 && requestJSON.indexOf("987654321987654321A") != -1) 
     {
        context.setVariable("objectId","0031");
     }
      
      }
}
else if(id!=null && id == '1632') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("123456789012389") != -1 && requestJSON.indexOf("897654321987654321B") != -1) 
     {
        context.setVariable("objectId","0032");
     }
      
      }
}
else if(id!=null && id == '1650') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("990012345678901") != -1 && requestJSON.indexOf("8901123456789012345") != -1) 
     {
        context.setVariable("objectId","0033");
     }
      
      }
}
else if(id!=null && id == '1652') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("071234567890123") != -1 && requestJSON.indexOf("8901123456789012346F") != -1) 
     {
        context.setVariable("objectId","0034");
     }
      
      }
}
else if(id!=null && id == '1653') 
{
   if (reqPayLoad.hasOwnProperty('items'))
    {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456782109") != -1) 
     {
        context.setVariable("objectId","0035");
     }
      
      }
}
else if(id!=null && id == '1651') 
{
  if (reqPayLoad.hasOwnProperty('items'))
    {
      if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].sku == '1PMX134LL/A' && reqPayLoad.items[0].imei == "990012345678901") 
      {
        context.setVariable("objectId","0037");
      }
        else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].sku == '1PMX134LL/A' && reqPayLoad.items[0].imei == "071234567890123") 
      {
        context.setVariable("objectId","0038");
      }
          else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].sku == '1PMX134LL/A') 
      {
        context.setVariable("objectId","0039");
      }
        else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].sku == '000000123456789012') 
      {
        context.setVariable("objectId","0040");
      }
          else 
      {
        context.setVariable("objectId","0000");
      }
            
    }
}

else if(id!=null && id == '4001') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && reqPayLoad.destination.accountId=='456786') 
     {
        context.setVariable("objectId","0060");
     }
  }
}
else if(id!=null && id == '4002') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==3 && reqPayLoad.destination.accountId=='456787') 
     {
        context.setVariable("objectId","0061");
     }
  }
}
else if(id!=null && id == '4003') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && reqPayLoad.destination.accountId=='456785') 
     {
        context.setVariable("objectId","0062");
     }
  }
}
else if(id!=null && id == '4004') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==2 && reqPayLoad.destination.accountId=='456787') 
     {
        context.setVariable("objectId","0063");
     }
  }
}
else if(id!=null && id == '4005') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.destination.accountId=='456785') 
     {
        context.setVariable("objectId","0064");
     }
  }
}
else if(id!=null && id == '4006') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.destination.accountId=='456786') 
     {
        context.setVariable("objectId","0065");
     }
  }
}
else if(id!=null && id == '4007') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.destination.accountId=='456786') 
     {
        context.setVariable("objectId","0066");
     }
  }
}
else if(id!=null && id == '4008') 
{
   if (reqPayLoad.hasOwnProperty('cartLines'))
  {
    if(reqPayLoad.cartLines instanceof Array && reqPayLoad.cartLines.length==1 && reqPayLoad.destination.accountId=='123991') 
     {
        context.setVariable("objectId","0067");
     }
  }
}
else if(id!=null && id == '1680') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456789012") != -1) 
     {
        context.setVariable("objectId","076");
     }
  }
}
else if(id!=null && id == '1681') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456782109") != -1) 
     {
        context.setVariable("objectId","077");
     }
  }
}
else if(id!=null && id == '1682') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456782901") != -1) 
     {
        context.setVariable("objectId","078");
     }
  }
}
else if(id!=null && id == '1683') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456782902") != -1) 
     {
        context.setVariable("objectId","079");
     }
  }
}
else if(id!=null && id == '1684') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && requestJSON.indexOf("000000123456789015") != -1) 
     {
        context.setVariable("objectId","080");
     }
  }
}
else if(id!=null && id == '1523') 
{
   if (reqPayLoad.hasOwnProperty('payments'))
  {
    if(reqPayLoad.payments instanceof Array && reqPayLoad.payments.length==1 && requestJSON.indexOf("12345678900000") != -1) 
     {
        context.setVariable("objectId","081");
     }
  }
}
else if(id!=null && id == '1524') 
{
   if (reqPayLoad.hasOwnProperty('payments'))
  {
    if(reqPayLoad.payments instanceof Array && reqPayLoad.payments.length==1 && requestJSON.indexOf("12345678911111") != -1) 
     {
        context.setVariable("objectId","082");
     }
  }
}
else if(id!=null && id == '460005') 
{
   if (reqPayLoad.hasOwnProperty('items'))
  {
    if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].productId=='3102') 
     {
        context.setVariable("objectId","102");
     }
  }
}


context.setVariable("dataType","addToCart");
