/*

Purpose: Script to generate Access token and return mock profile data along with access token for given code from BaaS.

Developer: Supriya.Datta4@T-Mobile.com

Revisions: 15th June 2015 | Added Script
  
*/

//Get request content from context
if(context.getVariable('request.content')!=''){
	var request_content = context.getVariable('request.content');  
}

context.setVariable('code', context.getVariable('code'));

//Get tmobileid from context extracted from request content
var code = context.getVariable('code');

//Get response content of OAuthV2 generate token
var auth_response = JSON.parse(context.getVariable('response.content'));
context.setVariable('auth_response', JSON.stringify(auth_response));

//Make call to Bass to retrive profile data based on tmobileid passed
var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='getMockProfile_updated' and id='" + code + "'";
 

var headers = {'Content-Type' : 'application/json'};
var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);
req.waitForComplete();		

  if (req.isSuccess()) {          
      mockData = req.getResponse().content.asJSON;  
      var profileObject = mockData.entities[0].mockData;
      profileObject.token = auth_response.access_token;
      context.proxyResponse.content = JSON.stringify(profileObject);
  }
  else
  {
      throw new Error("Did not find mock data.");
  }
