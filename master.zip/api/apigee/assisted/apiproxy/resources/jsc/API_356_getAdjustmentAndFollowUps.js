var token = context.getVariable('request.header.token')
var repId=context.getVariable("request.queryparam.repId");
var managerId=context.getVariable("request.queryparam.managerId")
context.setVariable("dataType",'getAdjustmentAndFollowUps');

if(token=='fx00wmdlxw0')
{
context.setVariable("objectId", "001");
}
else if(token=='00x34frsdc')
{
  if(repId=='CWalters123' && managerId=='Hsherman')
  {
     context.setVariable("objectId", "003");
  }
  else if(repId=='Rcross' && managerId=='Hsherman')
  {
     context.setVariable("objectId", "004");
  }
  else
  {
  context.setVariable("objectId", "002");
  }
}
