var req_payload = context.targetRequest.body.asJSON


context.setVariable("dataType", "postScoreSuggestions");

if(req_payload.lines instanceof Array && req_payload.lines.length==1 && JSON.stringify(req_payload).indexOf("devices,accessories")!= -1)
{
  	context.setVariable("objectId","001");
}