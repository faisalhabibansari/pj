var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");
var filter=context.getVariable("request.queryparam.filter");

context.setVariable("dataType","getCallHistory");

if (accountId == '12341234') {
 context.setVariable("objectId", "12341234");
}
else if (accountId=='55555' && sort=='date' && filter==undefined)
{
 context.setVariable("objectId", "003");
}
else if(accountId=='55555' && sort=='duration' && filter==undefined)
{
 context.setVariable("objectId","004");
}
else if(accountId=='55555' && sort=='cost')
{
 context.setVariable("objectId","005");
}
else if(accountId=='55555' && sort=='duration')
{
 context.setVariable("objectId","006");
}
else if(accountId=='55555' && sort=='date')
{
 context.setVariable("objectId","007");
}
else if(accountId=='55555')
{
 context.setVariable("objectId","55555");
}
else if(accountId=='123456678'&& filter=='line=4567239871')
{
 context.setVariable("objectId","008");
}
else if(accountId=='123456678'&& filter=='phoneNumber=8765439877')
{
 context.setVariable("objectId","009");
}
else if(accountId=='123456678'&& filter=='type=Wi-Fi Call')
{
 context.setVariable("objectId","010");
}
else if(accountId=='123456678'&& filter=='startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","011");
}
else if(accountId=='123456678'&& filter=='startDate=01/01/2014,endDate=06/30/2014')
{
 context.setVariable("objectId","012");
}
else if(accountId=='123456678'&& filter=='line=4567239871,phoneNumber=8765439877,type=Wi-Fi Call,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","013");
}
else if(accountId=='123456678'&& filter=='phoneNumber=8765439876,8765439877')
{
 context.setVariable("objectId","014");
}
else if(accountId=='123456678'&& filter=='type=Wi-Fi Call, Domestic roaming')
{
 context.setVariable("objectId","015");
}
else if(accountId=='123456678'&& filter=='line=4567239871,type=Wi-Fi Call,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","016");
}
else if(accountId=='123456678'&& filter=='line=4567239871,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","017");
}
else if(accountId=='123456678'&& filter=='destination=Seattle, WA')
{
 context.setVariable("objectId","018");
}

else {
  context.setVariable("objectId",customerId);
}