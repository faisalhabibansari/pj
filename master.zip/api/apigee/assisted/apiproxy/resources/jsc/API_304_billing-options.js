var customerID=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
context.setVariable("dataType",'getBillingOptions');
if(customerID=='1234' &&accountId=='123123')
{
context.setVariable("objectId","001");
}
else if(customerID=='1234570' &&accountId=='123123')
{
context.setVariable("objectId","002");
} 
else if(customerID=='1234570' &&accountId=='1234123')
{
context.setVariable("objectId","003");
}else if(customerID=='234234234' &&accountId=='9876543')
{
context.setVariable("objectId","004");
}else if(customerID=='234234235' &&accountId=='9876543')
{
context.setVariable("objectId","005");
}
else if(customerID=='761' &&accountId=='4000000606')
{
context.setVariable("objectId","006");
}
else if(customerID=='760' &&accountId=='4000000605')
{
context.setVariable("objectId","007");
}
else if(customerID=='756' &&accountId=='4000000601')
{
context.setVariable("objectId","008");
} 

//---For QT-----


else if(customerID=='656' &&accountId=='4000000568')
{
context.setVariable("objectId","009");
}
else if(customerID=='659' &&accountId=='4000000569')
{
context.setVariable("objectId","010");
}
else if(customerID=='660' &&accountId=='4000000570')
{
context.setVariable("objectId","011");
}
else if(customerID=='661' &&accountId=='4000000571')
{
context.setVariable("objectId","012");
}

