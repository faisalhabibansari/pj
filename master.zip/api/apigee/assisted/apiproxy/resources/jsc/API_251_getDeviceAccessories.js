var deviceId = context.getVariable("deviceId");

context.setVariable("dataType","getDeviceAccessories");

if(deviceId!=null) 
{
 	context.setVariable("objectId",deviceId);
}