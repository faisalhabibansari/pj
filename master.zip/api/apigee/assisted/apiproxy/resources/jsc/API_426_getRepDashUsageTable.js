var customerId=context.getVariable("request.queryparam.customerId");
var accountId=context.getVariable("request.queryparam.accountId");
var startDate=context.getVariable("request.queryparam.startDate");
var endDate=context.getVariable("request.queryparam.endDate");
var line=context.getVariable("request.queryparam.line");
context.setVariable("dataType","getRepDashUsageTable");
if(customerId!= null && accountId!=null)
{
	if(customerId=='12345' && accountId=='123123')
	{
		if(startDate=='05/21/2015' && endDate=='06/20/2015')
		{
			if(line=='4251234567')
			{
				context.setVariable("objectId","002");
			}
			else if(line=='6021234577')
			{
				context.setVariable("objectId","003");
			}
			else if(line=='6021238367')
			{
				context.setVariable("objectId","004");
			}
			else if(line=='6354781111')
			{
				context.setVariable("objectId","005");
			}
			else if(line=='5634238367')
			{
				context.setVariable("objectId","006");
			}
			else
			{
				context.setVariable("objectId","007");
			}
		}
		else if(startDate=='04/21/2015' && endDate=='05/20/2015')
		{
			if(line=='4251234567')
			{
				context.setVariable("objectId","008");
			}
			else if(line=='6021234577')
			{
				context.setVariable("objectId","009");
			}
			else if(line=='6021238367')
			{
				context.setVariable("objectId","010");
			}
			else if(line=='6354781111')
			{
				context.setVariable("objectId","011");
			}
			else if(line=='5634238367')
			{
				context.setVariable("objectId","012");
			}
			else
			{
				context.setVariable("objectId","013");
			}
		}
		else
		{
			context.setVariable("objectId","014");
		}
	}
}
else{	
  	context.setVariable("objectId","001");
  }
