
var q = context.getVariable('request.queryparam.q');
var customerId = context.getVariable('request.queryparam.customerId');
context.setVariable("dataType","getAutoSuggest");

if(q=='gal' && customerId=='12345') {
   context.setVariable('objectId', customerId);
}
else if(q=='ga') {
   context.setVariable('objectId', "123");
}
else if(q=='gal' && customerId===null) {
   context.setVariable('objectId', "003");
}
else if(customerID=='3000000028' && q=='gal')
{	
  context.setVarible('objectId',"003")
}
else if(customerID=='3000000031' && q=='gal')
{	
  context.setVarible('objectId',"003")
}
else if(customerID=='3000000032' && q=='gal')
{	
  context.setVarible('objectId',"003")
}
else if(customerID=='3000000033' && q=='gal')
{	
  context.setVarible('objectId',"003")
}