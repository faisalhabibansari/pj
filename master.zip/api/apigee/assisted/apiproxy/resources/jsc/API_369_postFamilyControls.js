var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null && reqPayLoad!=''){ 
    context.setVariable("objectId", "001");
}else{
    context.setVariable("objectId", "0000");
}
context.setVariable("dataType", "postFamilyControls");