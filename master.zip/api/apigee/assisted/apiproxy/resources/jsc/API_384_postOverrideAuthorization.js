var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postOverrideAuthorization");
if(reqPayLoad!=null && reqPayLoad!='' && reqPayLoad.overrideReason=='Managed Discretion')
  {
context.setVariable("objectId","001");
}
else if(reqPayLoad!=null && reqPayLoad!='' && reqPayLoad.overrideReason=='Customer Loyalty')
  {
context.setVariable("objectId","002");
}