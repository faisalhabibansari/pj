var limit=context.getVariable("request.queryparam.limit");
var offset=context.getVariable("request.queryparam.offset");
var filter=context.getVariable("request.queryparam.filter");
var familyId=context.getVariable("request.queryparam.familyId");
var lineId=context.getVariable("request.queryparam.lineId");

context.setVariable("dataType",'getDeviceDetails');


if(familyId=='IP6')
{
  context.setVariable("objectId","1111");
}
else if(familyId=='IPAD6')
{
context.setVariable("objectId","2222");
}
else if(limit!=null&&offset!=null&&filter!=null)
{
context.setVariable("objectId","001");
}
else if(limit==null&&offset==null&&filter==null &&familyId==null)
{
context.setVariable("objectId","12345");
}
else if(lineId=='{}'&&filter==score)
{
context.setVariable("objectId","score0");
}
else
{
  context.setvariable("objectId","000");
}