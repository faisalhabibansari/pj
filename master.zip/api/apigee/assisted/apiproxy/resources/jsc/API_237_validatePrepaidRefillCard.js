var cardNumber = context.targetRequest.body.asJSON.refillCard.cardNumber;

var pincode = context.targetRequest.body.asJSON.refillCard.pincode;

context.setVariable('dataType', 'validatePrepaidRefillCard');

/*if(cardNumber != null && cardNumber =='3333444455556'){
  context.setVariable("objectId", "2061123456");
}else 
{
  context.setVariable("objectId", "2061123467");
}*/

if(cardNumber != null && cardNumber =='3333444455556'){
  context.setVariable("objectId", "2061123456");
}else if(cardNumber != null && cardNumber =='3333444455557')
{
  context.setVariable("objectId", "2061123477");
}else if(cardNumber != null && cardNumber =='3333444455558')
{
  context.setVariable("objectId", "2061123468");
}else if(cardNumber != null && cardNumber =='3333444455559')
{
  context.setVariable("objectId", "2061123469");
}else if(cardNumber != null && cardNumber =='3333444455550')
{
  context.setVariable("objectId", "2061123460");
}else if(cardNumber != null && cardNumber =='3333444455551')
{
  context.setVariable("objectId", "2061123461");
}else if(cardNumber != null && cardNumber =='3333444455552')
{
  context.setVariable("objectId", "2061123462");
}else if(cardNumber != null && cardNumber =='3333444455553')
{
  context.setVariable("objectId", "2061123463");
}else if(cardNumber != null && cardNumber =='3333444455554')
{
  context.setVariable("objectId", "2061123464");
}else if(cardNumber != null && cardNumber =='3333444455555')
{
  context.setVariable("objectId", "2061123465");
}
else if(cardNumber != null && cardNumber =='12345678901234')
{
  context.setVariable("objectId", "2061123470");
}
else if(cardNumber != null && cardNumber =='43214321432143')
{
  context.setVariable("objectId", "2061123471");
}
else if(cardNumber != null && cardNumber =='12341234123412')
{
  context.setVariable("objectId", "2061123472");
}
else if(cardNumber != null && cardNumber =='12345678900000')
{
  context.setVariable("objectId", "2061123478");
}
else if(cardNumber != null && cardNumber =='12345678933333')
{
  context.setVariable("objectId", "2061123479");
}
else if(cardNumber != null && cardNumber =='12345678911111')
{
  context.setVariable("objectId", "2061123480");
}
else if(pincode != null && pincode =='11159324261974')
{
  context.setVariable("objectId", "18502074266");
}
else if(pincode != null && pincode =='64080544567964')
{
  context.setVariable("objectId", "18052008482");
}
else if(pincode != null && pincode =='59152377363576')
{
  context.setVariable("objectId", "18052008467");
}
else if(pincode != null && pincode =='10444828664985')
{
  context.setVariable("objectId", "18172910041");
}
else if(pincode != null && pincode =='27919902474212')
{
  context.setVariable("objectId", "18502074103");
}
else if(pincode != null && pincode =='27919902474212')
{
  context.setVariable("objectId", "18172910029");
}
else if(pincode != null && pincode =='32081934564768')
{
  context.setVariable("objectId", "14043251100");
}
else if(pincode != null && pincode =='91134790279357')
{
  context.setVariable("objectId", "12142058807");
}
else if(pincode != null && pincode =='57454708687117')
{
  context.setVariable("objectId", "18052007723");
}
else if(pincode != null && pincode =='13542536902873')
{
  context.setVariable("objectId", "12142058802");
}
else 
{
  context.setVariable("objectId", "2061123467");
}
