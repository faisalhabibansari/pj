/**

Purpose: Script to return rep mock profile data for given repNTId from BaaS.

Developer: Supriya.Datta4@T-Mobile.com

Revisions: 15 June 2015 | Added Script
  
**/

var request_payload = context.targetRequest.body.asJSON;

var baseURL = 'https://api.usergrid.com/louis.lim5/sandbox/'

var url1 = baseURL+'token';

var headers = {'Content-Type' : 'application/json'};

var bodyObj = {
    "grant_type": "client_credentials",
    "client_id" : "b3U6dd51SnHaEeSq-NMfwW6bZw",
    "client_secret" : "b3U6AcLUMvYFlO2AznL2OJEBjHqbG5U"
}; 

var getTokenResponse = postRequest(url1,headers,bodyObj);

var url2 = baseURL+"mocks?ql=select * where id='"+request_payload.repNTId+"' and dataType='postMockRepProfile'";

var getDataResponse = getRequest(url2,headers);

if(getTokenResponse!=null && getDataResponse!=null && getDataResponse.entities.length!=0)
{
  var access_token = getTokenResponse.access_token;

  var uuid = getDataResponse.entities[0].uuid;
  var data = getDataResponse.entities[0].mockData;

  var url3 = baseURL+"mocks/"+uuid+"?access_token="+access_token;

  var deleteDataResponse = deleteRequest(url3,headers);

  if(deleteDataResponse)
  {
  var url4 = baseURL+"mocks?access_token="+access_token;

  var newData = data;
  newData.customerInFocus=request_payload.customerInFocus;

  var newMockData ={"id":request_payload.repNTId, "dataType":"postMockRepProfile", "mockData":newData};

  var addDataResponse = postRequest(url4,headers,newMockData);
  
  context.proxyResponse.content = JSON.stringify(newData); 
  }
}



function postRequest(url,headers,bodyObj)
{
var myRequest = new Request(url, "POST", headers, JSON.stringify(bodyObj));
var req = httpClient.send(myRequest);
req.waitForComplete();
req.waitForComplete();
  if (req.isSuccess())
  {
  var reqResponse = req.getResponse().content.asJSON;
  return reqResponse;
  }
  else
  {
    return null;
  }  
}


function getRequest(url,headers)
{
var myRequest = new Request(url, "GET", headers);
var req = httpClient.send(myRequest);
req.waitForComplete();
  if (req.isSuccess())
  {
  var reqResponse = req.getResponse().content.asJSON;
  return reqResponse;
  }
  else
  {
    return null;
  } 
}

function deleteRequest(url,headers)
{
var myRequest = new Request(url, "DELETE", headers, JSON.stringify({}));
var req = httpClient.send(myRequest);
req.waitForComplete();
  if (req.isSuccess())
  {
  return true;
  }
  else
  {
  return false;
  }
}