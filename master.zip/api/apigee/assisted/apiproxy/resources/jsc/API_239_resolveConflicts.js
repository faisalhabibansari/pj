var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null)
{
  context.setVariable('dataType', 'resolveConflicts');
  
  if(reqPayLoad.accountId=="" && reqPayLoad.msisdn=="2068611111")
  {
      context.setVariable("objectId", "001");
    
  }else if(reqPayLoad.accountId=="" && reqPayLoad.msisdn=="2068602222")
  {
      context.setVariable("objectId", "002");
  }else if(reqPayLoad.accountId=="" && reqPayLoad.msisdn=="2068603333")
  {
      context.setVariable("objectId", "003");
  }else if(reqPayLoad.accountId=="" && reqPayLoad.msisdn=="2061234567")
  {
      context.setVariable("objectId", "004");
  }else{
      context.setVariable("objectId", "000");
  }
    
}else{
      context.setVariable("objectId", "000");
  }
