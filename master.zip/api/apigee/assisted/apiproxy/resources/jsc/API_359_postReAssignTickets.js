var reqPayLoad = context.targetRequest.body.asJSON;
var token = context.getVariable('request.header.token')
context.setVariable("dataType","postReAssignTickets");

if(reqPayLoad!=null && reqPayLoad!='' && (token=='00x34frsdc' || token=='fx00wmdlxw0'))
{
context.setVariable("objectId","001");
}   
else
{
 context.setVariable("objectId","000");
}