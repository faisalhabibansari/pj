var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var accounts = request_payload.cancellation.accounts;

if(accounts!=null && accounts instanceof Array)
{
   context.setVariable("dataType","lineCancellation"); 
    if(accounts.length==1)
  { 
     if(accounts[0].id=="143143" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="3331234567")
      {
       context.setVariable("objectId", "001");
      }
     else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="1111234567")
     {
      context.setVariable("objectId", "002");
     }
    else if(accounts[0].id=="123123" && accounts[0].lines.length==2 && accounts[0].lines[0].id=="1111234567" && accounts[0].lines[1].id=="2221234567")
    {
     context.setVariable("objectId", "003");
    }
    else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="2221234567")
     {
      context.setVariable("objectId", "006");
     }
    else if(accounts[0].id=="153153" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="4441234567")
     {
      context.setVariable("objectId", "008");
     }
    else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="2061234568")
     {
      context.setVariable("objectId", "009");
     }
    else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="2061234569")
     {
      context.setVariable("objectId", "010");
     }
	else if(accounts[0].id=="123123790" && accounts[0].lines.length==2 && accounts[0].lines[0].id=="123190" && accounts[0].lines[1].id=="123191")
     {
      context.setVariable("objectId", "011");
     }
	else if(accounts[0].id=="123123790" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="123191")
     {
      context.setVariable("objectId", "012");
     }
	else if(accounts[0].id=="123123790" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="123190")
     {
      context.setVariable("objectId", "013");
     }
  }
  else if(accounts.length==2)
  { 
    if(accounts[0].id=="123123" && accounts[0].lines.length==2 && accounts[0].lines[0].id=="1111234567" && accounts[0].lines[1].id=="2221234567" && accounts[1].id=="143143" && accounts[1].lines[0].id=="3331234567")
    {
     context.setVariable("objectId", "004");
    }

   else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="1111234567" && accounts[1].id=="143143" && accounts[1].lines[0].id=="3331234567")
    {
     context.setVariable("objectId", "005");
    }
   
    else if(accounts[0].id=="123123" && accounts[0].lines.length==1 && accounts[0].lines[0].id=="2221234567" && accounts[1].id=="143143" && accounts[1].lines[0].id=="3331234567")
    {
     context.setVariable("objectId", "007");
    }
  }  
 /*  if(accounts[0].id=="143143" && accounts[0].lines[0].id=="3331234567")
   {
    context.setVariable("dataType","lineCancellation"); 
    context.setVariable("objectId", "001");
   }*/
}

