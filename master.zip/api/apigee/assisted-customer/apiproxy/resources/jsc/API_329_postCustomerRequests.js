var request_payload = '';
if(context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var type = request_payload.type;
context.setVariable("dataType", "postCustomerRequests");
if(type =='adjustment') {      
	context.setVariable("objectId", "1001");
	
}else if(type =='credit') {
	context.setVariable("objectId", "1002");
	
}else if(type =='Payment Dispute') {
	context.setVariable("objectId", "1003");

}else if(type =='hold collection'|| type =='Misapplied Payment' || type =='Bill Copy') {
	context.setVariable("objectId", "1004");

}
else if(type =='Negative File Request') {
	context.setVariable("objectId", "1005");

}
else if(type =='Fraud Routing') {
	context.setVariable("objectId", "1006");

}
else if(type =='Missing Payment') {
	context.setVariable("objectId", "1007");

}	