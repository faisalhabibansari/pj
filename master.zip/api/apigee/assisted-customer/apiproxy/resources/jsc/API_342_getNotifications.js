var customerId = context.getVariable("customerId");

context.setVariable("dataType", "getNotifications");

if (customerId == '425435')
{
	context.setVariable("objectId", "002");
}
else if (customerId == '500000001')
{
	context.setVariable("objectId", "003");
}
else if (customerId == '500000002')
{
	context.setVariable("objectId", "004");
}
else if (customerId == '741852')
{
	context.setVariable("objectId", "005");
}
else if (customerId == '1241')
{
	context.setVariable("objectId", "006");
}
else
{
	context.setVariable("objectId", "001");
}
