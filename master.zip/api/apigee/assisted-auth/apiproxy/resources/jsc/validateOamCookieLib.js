var settings = context.getVariable('settingsObject');
var utilities = context.getVariable('utilities');

//////////////////SparkMD5 - https://raw.githubusercontent.com/satazor/SparkMD5/master/spark-md5.js ////////////////

var self = this;

(function(g){if("object"===typeof exports)module.exports=g();else if("function"===typeof define&&define.amd)define(g);else{var n;try{n=window}catch(h){n=self}n.SparkMD5=g()}})(function(g){var n=function(f,d){return f+d&4294967295},h=function(f,d,a,b,e,c){d=n(n(d,f),n(b,c));return n(d<<e|d>>>32-e,a)},k=function(f,d,a,b,e,c,g){return h(d&a|~d&b,f,d,e,c,g)},l=function(f,d,a,b,e,c,g){return h(d&b|a&~b,f,d,e,c,g)},m=function(f,d,a,b,e,c,g){return h(a^(d|~b),f,d,e,c,g)},p=function(f,d){var a=f[0],b=f[1],
e=f[2],c=f[3],a=k(a,b,e,c,d[0],7,-680876936),c=k(c,a,b,e,d[1],12,-389564586),e=k(e,c,a,b,d[2],17,606105819),b=k(b,e,c,a,d[3],22,-1044525330),a=k(a,b,e,c,d[4],7,-176418897),c=k(c,a,b,e,d[5],12,1200080426),e=k(e,c,a,b,d[6],17,-1473231341),b=k(b,e,c,a,d[7],22,-45705983),a=k(a,b,e,c,d[8],7,1770035416),c=k(c,a,b,e,d[9],12,-1958414417),e=k(e,c,a,b,d[10],17,-42063),b=k(b,e,c,a,d[11],22,-1990404162),a=k(a,b,e,c,d[12],7,1804603682),c=k(c,a,b,e,d[13],12,-40341101),e=k(e,c,a,b,d[14],17,-1502002290),b=k(b,e,
c,a,d[15],22,1236535329),a=l(a,b,e,c,d[1],5,-165796510),c=l(c,a,b,e,d[6],9,-1069501632),e=l(e,c,a,b,d[11],14,643717713),b=l(b,e,c,a,d[0],20,-373897302),a=l(a,b,e,c,d[5],5,-701558691),c=l(c,a,b,e,d[10],9,38016083),e=l(e,c,a,b,d[15],14,-660478335),b=l(b,e,c,a,d[4],20,-405537848),a=l(a,b,e,c,d[9],5,568446438),c=l(c,a,b,e,d[14],9,-1019803690),e=l(e,c,a,b,d[3],14,-187363961),b=l(b,e,c,a,d[8],20,1163531501),a=l(a,b,e,c,d[13],5,-1444681467),c=l(c,a,b,e,d[2],9,-51403784),e=l(e,c,a,b,d[7],14,1735328473),b=
l(b,e,c,a,d[12],20,-1926607734),a=h(b^e^c,a,b,d[5],4,-378558),c=h(a^b^e,c,a,d[8],11,-2022574463),e=h(c^a^b,e,c,d[11],16,1839030562),b=h(e^c^a,b,e,d[14],23,-35309556),a=h(b^e^c,a,b,d[1],4,-1530992060),c=h(a^b^e,c,a,d[4],11,1272893353),e=h(c^a^b,e,c,d[7],16,-155497632),b=h(e^c^a,b,e,d[10],23,-1094730640),a=h(b^e^c,a,b,d[13],4,681279174),c=h(a^b^e,c,a,d[0],11,-358537222),e=h(c^a^b,e,c,d[3],16,-722521979),b=h(e^c^a,b,e,d[6],23,76029189),a=h(b^e^c,a,b,d[9],4,-640364487),c=h(a^b^e,c,a,d[12],11,-421815835),
e=h(c^a^b,e,c,d[15],16,530742520),b=h(e^c^a,b,e,d[2],23,-995338651),a=m(a,b,e,c,d[0],6,-198630844),c=m(c,a,b,e,d[7],10,1126891415),e=m(e,c,a,b,d[14],15,-1416354905),b=m(b,e,c,a,d[5],21,-57434055),a=m(a,b,e,c,d[12],6,1700485571),c=m(c,a,b,e,d[3],10,-1894986606),e=m(e,c,a,b,d[10],15,-1051523),b=m(b,e,c,a,d[1],21,-2054922799),a=m(a,b,e,c,d[8],6,1873313359),c=m(c,a,b,e,d[15],10,-30611744),e=m(e,c,a,b,d[6],15,-1560198380),b=m(b,e,c,a,d[13],21,1309151649),a=m(a,b,e,c,d[4],6,-145523070),c=m(c,a,b,e,d[11],
10,-1120210379),e=m(e,c,a,b,d[2],15,718787259),b=m(b,e,c,a,d[9],21,-343485551);f[0]=n(a,f[0]);f[1]=n(b,f[1]);f[2]=n(e,f[2]);f[3]=n(c,f[3])},t=function(f){var d=[],a;for(a=0;64>a;a+=4)d[a>>2]=f.charCodeAt(a)+(f.charCodeAt(a+1)<<8)+(f.charCodeAt(a+2)<<16)+(f.charCodeAt(a+3)<<24);return d},u=function(f){var d=[],a;for(a=0;64>a;a+=4)d[a>>2]=f[a]+(f[a+1]<<8)+(f[a+2]<<16)+(f[a+3]<<24);return d},r=function(f){var d=f.length,a=[1732584193,-271733879,-1732584194,271733878],b,e,c;for(b=64;b<=d;b+=64)p(a,t(f.substring(b-
64,b)));f=f.substring(b-64);e=f.length;c=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(b=0;b<e;b+=1)c[b>>2]|=f.charCodeAt(b)<<(b%4<<3);c[b>>2]|=128<<(b%4<<3);if(55<b)for(p(a,c),b=0;16>b;b+=1)c[b]=0;d=(8*d).toString(16).match(/(.*?)(.{0,8})$/);f=parseInt(d[2],16);d=parseInt(d[1],16)||0;c[14]=f;c[15]=d;p(a,c);return a},v="0123456789abcdef".split(""),q=function(f){var d;for(d=0;d<f.length;d+=1){for(var a=d,b=f[d],e="",c=void 0,c=0;4>c;c+=1)e+=v[b>>8*c+4&15]+v[b>>8*c&15];f[a]=e}return f.join("")};g=function(){this.reset()};
"5d41402abc4b2a76b9719d911017c592"!==q(r("hello"))&&(n=function(f,d){var a=(f&65535)+(d&65535);return(f>>16)+(d>>16)+(a>>16)<<16|a&65535});g.prototype.append=function(f){/[\u0080-\uFFFF]/.test(f)&&(f=unescape(encodeURIComponent(f)));this.appendBinary(f);return this};g.prototype.appendBinary=function(f){this._buff+=f;this._length+=f.length;f=this._buff.length;var d;for(d=64;d<=f;d+=64)p(this._state,t(this._buff.substring(d-64,d)));this._buff=this._buff.substr(d-64);return this};g.prototype.end=function(f){var d=
this._buff,a=d.length,b,e=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(b=0;b<a;b+=1)e[b>>2]|=d.charCodeAt(b)<<(b%4<<3);this._finish(e,a);f=f?this._state:q(this._state);this.reset();return f};g.prototype._finish=function(f,d){var a=d,b;f[a>>2]|=128<<(a%4<<3);if(55<a)for(p(this._state,f),a=0;16>a;a+=1)f[a]=0;b=8*this._length;b=b.toString(16).match(/(.*?)(.{0,8})$/);a=parseInt(b[2],16);b=parseInt(b[1],16)||0;f[14]=a;f[15]=b;p(this._state,f)};g.prototype.reset=function(){this._buff="";this._length=0;this._state=
[1732584193,-271733879,-1732584194,271733878];return this};g.prototype.destroy=function(){delete this._state;delete this._buff;delete this._length};g.hash=function(f,d){/[\u0080-\uFFFF]/.test(f)&&(f=unescape(encodeURIComponent(f)));var a=r(f);return d?a:q(a)};g.hashBinary=function(f,d){var a=r(f);return d?a:q(a)};g.ArrayBuffer=function(){this.reset()};g.ArrayBuffer.prototype.append=function(f){var d=this._concatArrayBuffer(this._buff,f),a=d.length;this._length+=f.byteLength;for(f=64;f<=a;f+=64)p(this._state,
u(d.subarray(f-64,f)));this._buff=f-64<a?d.subarray(f-64):new Uint8Array(0);return this};g.ArrayBuffer.prototype.end=function(f){var d=this._buff,a=d.length,b=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],e;for(e=0;e<a;e+=1)b[e>>2]|=d[e]<<(e%4<<3);this._finish(b,a);f=f?this._state:q(this._state);this.reset();return f};g.ArrayBuffer.prototype._finish=g.prototype._finish;g.ArrayBuffer.prototype.reset=function(){this._buff=new Uint8Array(0);this._length=0;this._state=[1732584193,-271733879,-1732584194,271733878];
return this};g.ArrayBuffer.prototype.destroy=g.prototype.destroy;g.ArrayBuffer.prototype._concatArrayBuffer=function(f,d){var a=f.length,b=new Uint8Array(a+d.byteLength);b.set(f);b.set(new Uint8Array(d),a);return b};g.ArrayBuffer.hash=function(f,d){var a=new Uint8Array(f),b=a.length,e=[1732584193,-271733879,-1732584194,271733878],c,g,h;for(c=64;c<=b;c+=64)p(e,u(a.subarray(c-64,c)));a=c-64<b?a.subarray(c-64):new Uint8Array(0);g=a.length;h=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(c=0;c<g;c+=1)h[c>>2]|=
a[c]<<(c%4<<3);h[c>>2]|=128<<(c%4<<3);if(55<c)for(p(e,h),c=0;16>c;c+=1)h[c]=0;b=(8*b).toString(16).match(/(.*?)(.{0,8})$/);a=parseInt(b[2],16);b=parseInt(b[1],16)||0;h[14]=a;h[15]=b;p(e,h);return d?e:q(e)};return g});

var SparkMD5 = self.SparkMD5;

////////////////// httpUtility object, containing helper functions

  var http = (function(api, window, document, undefined) {

      var _private = api._private = api._private || {};

      _private.merge = function(obj1, obj2) {
          var obj3 = {};
          for (var attrname in obj1) {
              obj3[attrname] = obj1[attrname];
          }
          for (var attrname in obj2) {
              obj3[attrname] = obj2[attrname];
          }
          return obj3;
      };

      api.parseUrl = function(uri) {
        url=/^(?:(.*?):\/\/?)?\/?(?:[^\/\.]+\.)*?([^\/\.]+)\.?([^\/]*)(?:([^?]*)?(?:\?(‌​[^#]*))?)?(.*)?/;
        var output = url.exec(uri);
        // [uri, protocol, subdomain, domain, path, undefined, queryString]
        //context.setVariable('raw uri parts', JSON.stringify(output));

        return {
          protocol: output[1]+"://",
          subdomain: output[2],
          domain: output[3],
          host: output[2]+'.'+output[3],
          path: output[4],
          queryString: output[5]
        };
      };

      api.call = function(options) {

          var defaults = {
              step: 0,
              protocol: 'https://',
              host: 'www.cbs.com',
              path: '/index.html',
              method: 'GET',
              headers: {
                  "Cookie": "myCookie=myvalue"
              },
              callback: function(x) {
                  //context.setVariable('http.call.defaultCallback' + options.step, JSON.stringify(x));
              },
              data: ""
          };

          var options = _private.merge(defaults, options);

          var url = options.protocol + options.host + options.path;

          var req = new Request(url, options.method, options.headers);

          var response = httpClient.send(req);

          // Wait for the asynchronous GET request to finish
          response.waitForComplete(30000); // hardcode timeout of 30000 for now...

          if (response.isSuccess()) {

              // get the response object from the response
              response = response.getResponse();

              context.setVariable('http.call.response' + options.step, JSON.stringify(response));

              if (options.callback) {
                  options.callback(response);
              }

          } else {
              context.setVariable('http.call.error' + options.step, JSON.stringify(response.getError()));
              throw new Error('error:: '+ JSON.stringify(response.getError()));
          }


      };

      return api;

  } (http || {}, {}, {}, undefined)); // no window or doc, running in node.js

////////////////////////////////////////////////////////////////////////

//2. request protected resource w/ cookie

  function requestProtectedResource()
  {

  	var protected_resource_parts = http.parseUrl(protected_resource);

  	var options =
  	{
  		step : 1,
  		headers :
  		{
  			"Cookie" : cookie
  		},
  		protocol : protected_resource_parts.protocol,
  		host : protected_resource_parts.host,
  		path : protected_resource_parts.path,
  		method : 'GET',
  		data : '',
  		callback : function(oamServerResponse)
  		{
  			context.setVariable('requestProtectedResource', JSON.stringify(oamServerResponse));
  			processResponse(oamServerResponse);
  		}
  	};
  	http.call(options);
  };

  function processResponse(oamServerResponse)
  {

  	// 3. if successful issue token, else deny
  	// to issue token, oauth_external_authorization_status has to be set to
  	// true...
  	// context.setVariable('step','validateOamCookie');
  	// context.setVariable('oauth_external_authorization_status',true);

  	// if res.status.code = 200 return auth token
  	if (parseInt(oamServerResponse.status.code) === parseInt(200))
  	{
  		// success
  		context.setVariable('oauth_external_authorization_status', true);
  		var authCookie = context.getVariable('oam_auth_cookie');
  		var token = SparkMD5.hash(authCookie) + "." + Math.floor(Date.now() / 1000);
  		context.setVariable('oam_auth_cookie', token);

  	}
  	else
  	{

  		context.setVariable('oam_auth_cookie', "***FAILED*** " + JSON.stringify(
  			[
  				oamServerResponse
  			]));
  		context.setVariable('oauth_external_authorization_status', false);
  	}
  };