/**
 * Purpose: Script to integrate getProductReviews facade API with Bazzarvoice APIs.
 *
 * Developer: sungho.maeung2@T-Mobile.com
 *
 * Revisions: 7/28/2015
 */

/**
 * defile constant variables for Product Reviews
 *
 * @type {string}
 */
var LANDING_PAGE = 'landing';
var DETAILS_PAGE = 'details';
var LIMIT_DEFAULT_VALUE = 4;
var OFFSET_DEFAULT_VALUE = 0;
var SORT_MOST_HELPFUL = 'Most helpful';
var SORT_HIGHTEST_RATING = 'Highest rating';
var SORT_LOWEST_RATING = 'Lowest rating';
var SORT_NEEWST = 'Newest';
var SORT_OLDEST = 'Oldest';
var BAZAARVOICE_BASE_URL = 'http://rebelliondev-dev01.apigee.net/web-pass-thru/v1/bazaarvoice/data/';

/**
 * Extracting queries and variables from Facade URL and set up default values
 * if it has undefined or null or empty string.
 */
var productId = context.getVariable("productId");
var type = context.proxyRequest.queryParams['type'];
var limit = context.proxyRequest.queryParams['limit'];
var offset = context.proxyRequest.queryParams['offset'];
var search = context.proxyRequest.queryParams['search'];
var sort = context.proxyRequest.queryParams['sort'];
var filter = context.proxyRequest.queryParams['filter'];

print("ProductId:"+ productId + " type:"+ type +" limit :"+ limit + ", offset:"+offset +", search:"+ search +", sort:"+ sort+ ", filter:"+filter);

if(limit === null || limit === '' || limit === undefined || isNaN(limit)){
    limit = LIMIT_DEFAULT_VALUE;

}


processProductReviews(whichPage(type));

/**
 * Retrieves Query Parameters and put them into map structure.
 * @return string (key and value) structure : key = query key
 */
function whichPage(type) {
    // default value as landing page
    var isLanding = LANDING_PAGE;
    if( type == DETAILS_PAGE ) {
        isLanding = DETAILS_PAGE;
    }
    return isLanding;
}

/**
 * process processProductReviews pages
 *     http://rebelliondev-dev01.apigee.net/web-pass-thru/v1/bazaarvoice/data/reviews.json
 *     ?product=iphone&Include=Products&Stats=Reviews
 *
 */
function processProductReviews(pageType){

    var facadeResponse = {};

    // construct Bazaar voice URL
    var bazaar_voiceURL = buildBazaarVoiceURL(pageType);

    var httpOptions = {
        headers : {},
        requestBody: {},
        method: 'GET'
    };
    // call Bazaar Voice URL
    var responseMsg = executeBazaarVoiceCall(bazaar_voiceURL, httpOptions);

    // convert to Facade response
    buildFacadeResponse(responseMsg, facadeResponse);

    // set the response to Apigee response
    processFacadeResponseMsg( facadeResponse, 200);

    print("processLandingPage():"+ JSON.stringify(facadeResponse));
}

/**
 * process Response message for Facade Apigee
 *
 */
function processFacadeResponseMsg(facadeResponse, responseStatus){
    context.proxyResponse.content = JSON.stringify(facadeResponse);
    context.proxyResponse.status = responseStatus;
}
/**
 * build facade response
 * @param bazaarVoiceResponseMsg - response message as JSON from Bazaar voice.
 * @return facade resposne message.
 * @param facadeResponse
 */
function buildFacadeResponse(bazaarVoiceResponseMsg, facadeResponse) {

    facadeResponse.totalReviews = bazaarVoiceResponseMsg.Includes.Products[productId].TotalReviewCount;
    facadeResponse.totalReviewsRate = bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.AverageOverallRating;
    facadeResponse.reviewsRecommendRate = (parseInt(bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.RecommendedCount) / parseInt(bazaarVoiceResponseMsg.Includes.Products[productId].TotalReviewCount)) * 100;

    facadeResponse.productName = bazaarVoiceResponseMsg.Includes.Products[productId].Name;
    facadeResponse.productImageUrl = bazaarVoiceResponseMsg.Includes.Products[productId].ImageUrl;

    facadeResponse.rateStaticstics = buildRateStaticstics(bazaarVoiceResponseMsg);


    facadeResponse.searchOptions ={};
    facadeResponse.searchOptions.closeFilter = {};
    buildSearchOptions(facadeResponse, bazaarVoiceResponseMsg);


    facadeResponse.reviews = [];

    var reviewCounts = bazaarVoiceResponseMsg.Results.length;
    for(var i = 0; i < reviewCounts; i++){
        var review = {};
        review.id = bazaarVoiceResponseMsg.Results[i].Id;
        review.reviewRate = bazaarVoiceResponseMsg.Results[i].Rating;
        review.reviewRateSummary = bazaarVoiceResponseMsg.Results[i].Title;
        // date format
        var date =  new Date(bazaarVoiceResponseMsg.Results[i].LastModificationTime);
        review.reviewDate = date.getMonth()+"/"+date.getDay()+"/"+ date.getFullYear();
        review.reviewUserName = bazaarVoiceResponseMsg.Results[i].UserNickname;

        review.rateStaticstics = [];

        if( typeof bazaarVoiceResponseMsg.Results[i].SecondaryRatings.EaseOfUse !== 'undefined'){
            review.rateStaticstics.push({
                categoryName  : bazaarVoiceResponseMsg.Results[i].SecondaryRatings.EaseOfUse.Label,
                categoryValue : bazaarVoiceResponseMsg.Results[i].SecondaryRatings.EaseOfUse.Value});
        }
        if( typeof bazaarVoiceResponseMsg.Results[i].SecondaryRatings.Features !== 'undefined'){
            review.rateStaticstics.push({
                categoryName: bazaarVoiceResponseMsg.Results[i].SecondaryRatings.Features.Label,
                categoryValue : bazaarVoiceResponseMsg.Results[i].SecondaryRatings.Features.Value});
        }
        if( typeof bazaarVoiceResponseMsg.Results[i].SecondaryRatings.BatteryLife !== 'undefined'){
            review.rateStaticstics.push({
                categoryName: bazaarVoiceResponseMsg.Results[i].SecondaryRatings.BatteryLife.Label,
                categoryValue : bazaarVoiceResponseMsg.Results[i].SecondaryRatings.BatteryLife.Value});
        }
        if( typeof bazaarVoiceResponseMsg.Results[i].SecondaryRatings.CallQuality !== 'undefined'){
            review.rateStaticstics.push({
                categoryName: bazaarVoiceResponseMsg.Results[i].SecondaryRatings.CallQuality.Label,
                categoryValue : bazaarVoiceResponseMsg.Results[i].SecondaryRatings.CallQuality.Value});
        }

        review.reviewText = bazaarVoiceResponseMsg.Results[i].ReviewText;
        review.pros = [];
        if( typeof  bazaarVoiceResponseMsg.Results[i].TagDimensions.Pro !== 'undefined'){
            bazaarVoiceResponseMsg.Results[i].TagDimensions.Pro.Values.forEach(function(element){
                review.pros.push(element);
            });
        }

        review.cons = [];
        if( typeof  bazaarVoiceResponseMsg.Results[i].TagDimensions.Con !== 'undefined'){
            bazaarVoiceResponseMsg.Results[i].TagDimensions.Con.Values.forEach(function(element){
                review.cons.push(element);
            });
        }

        review.recommendToFriend = bazaarVoiceResponseMsg.Results[i].IsRecommended;
        review.helpful = bazaarVoiceResponseMsg.Results[i].TotalPositiveFeedbackCount;
        review.unhelpful = bazaarVoiceResponseMsg.Results[i].TotalNegativeFeedbackCount;
        review.photos = [];
        bazaarVoiceResponseMsg.Results[i].Photos.forEach(function (photo) {
            // make sure the photo data structure existed.
            if (typeof photo.Caption !== 'undefined') {
                review.photos.push(photo);
            }
        });

        review.videos = [];
        bazaarVoiceResponseMsg.Results[i].Videos.forEach(function (video){
            review.videos.push(video);
        });

        facadeResponse.reviews.push(review);
    }
}
/**
 * build search options data strucure of facade response
 * @param facadeResponse
 * @param bazaarVoiceResponseMsg
 */
function buildSearchOptions(facadeResponse, bazaarVoiceResponseMsg){
    var ratingCounts = bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.RatingDistribution.length;
    var ratingObject;
    for(var i = 0; i < ratingCounts; i++){
        ratingObject = bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.RatingDistribution[i];
        switch(ratingObject.RatingValue){
            case 5:
                facadeResponse.searchOptions.closeFilter.fiveStartCounts = ratingObject.Count;
                break;
            case 4:
                facadeResponse.searchOptions.closeFilter.fourStartCounts = ratingObject.Count;
                break;
            case 3:
                facadeResponse.searchOptions.closeFilter.threeStartCounts = ratingObject.Count;
                break;
            case 2:
                facadeResponse.searchOptions.closeFilter.twoStartCounts = ratingObject.Count;
                break;
            case 1:
                facadeResponse.searchOptions.closeFilter.oneStartCounts = ratingObject.Count;
                break;
            default:
        }

    }
}
/**
 * build rate staticstics
 */
function buildRateStaticstics(bazaarVoiceResponseMsg){
    var arrays =[];
    if( typeof bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.EaseOfUse !== 'undefined'){
        arrays.push({
                categoryName  : "Ease Of Use",
                categoryValue : bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.EaseOfUse.AverageRating}
        );
    }
    if( typeof bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.features !== 'undefined'){
        arrays.push({
            categoryName  : "Features",
            categoryValue : bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.features.AverageRating});
    }
    if( typeof bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.batteryLife !== 'undefined'){
        arrays.push({
            categoryName  : "Battery Life",
            categoryValue : bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.batteryLife.AverageRating});
    }
    if( typeof bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.callQuality !== 'undefined'){
        arrays.push({
            categoryName  : "Call Quality",
            categoryValue : bazaarVoiceResponseMsg.Includes.Products[productId].ReviewStatistics.SecondaryRatingsAverages.callQuality.AverageRating});
    }
    return arrays;
}
/**
 * Execute Bazaar Voice Call and return a response message.
 *
 * @param url - a full url for bazaar voice
 * @param httpOptions - http options for REST call.
 * @return string Voice Response message , otherwise errors
 */
function executeBazaarVoiceCall(url, httpOptions) {
    var bazaarVoiceResponse = '';
    //Calling core URL
    var myRequest = new Request(url, httpOptions.method, httpOptions.headers);
    var req1 = httpClient.send(myRequest);
    req1.waitForComplete();

    if (req1.isSuccess()) {
        var bazaarVoiceStatus = req1.getResponse().status;
        // TODO remove DEBUG statement
        context.setVariable("debug_bazaarVoiceStatus ", bazaarVoiceStatus);
        if (bazaarVoiceStatus == 200) {
            bazaarVoiceResponse = req1.getResponse().content.asJSON;
            print("bazaarVoiceResponse: " + JSON.stringify(bazaarVoiceResponse));
        }
    } else if (req1.isError()) {
        processErrorMessage(500, "Internal Service Error", "Error calling BazaarVoice service " + url + ": " + JSON.stringify(req1.getError()));
    }
    return bazaarVoiceResponse;
}

/**
 * error handling to Apigee Proxy
 */
function processErrorMessage(status, message, content){
    context.proxyResponse.status = status;
    context.proxyResponse.status.message =message;
    context.proxyResponse.content = content;
}
/**
 * builder Bazaar voice
 * http://rebelliondev-dev01.apigee.net/web-pass-thru/v1/bazaarvoice/data/reviews.json
 *     ?product=iphone&Include=Products&Stats=Reviews
 *
 * @param  pageType - landing or detail page
 * @return string bazaar voice URL
 */
function buildBazaarVoiceURL(pageType){

    var url = BAZAARVOICE_BASE_URL;
    url += 'reviews.json?Include=Products&Stats=Reviews&Filter=ProductId:'+productId;
    switch(pageType){
        case LANDING_PAGE:
            url += '&Limit='+limit;
            url += '&Sort=TotalPositiveFeedbackCount:desc';
            break;
        case DETAILS_PAGE:
            if(search !== null && search !== '' && search !== undefined && !isNaN(search)){
                url += '&Search_reviews='+ search;
            }
            if(filter !== null && filter !== '' && !isNaN(filter) && filter !== undefined){
                url += '&Filter=Rating:eq:'+filter;
            }
            if(sort !== null && sort !== '' && sort !== undefined && !isNaN(sort)){
                switch(sort){
                    case SORT_MOST_HELPFUL:
                        url += '&Sort=TotalPositiveFeedbackCount:desc';
                        break;
                    case SORT_HIGHTEST_RATING:
                        url += '&Sort=Rating:desc';
                        break;
                    case SORT_LOWEST_RATING:
                        url += '&Sort=Rating:asc';
                        break;
                    case SORT_NEEWST:
                        url += '&Sort=SubmissionTime:desc';
                        break;
                    case SORT_OLDEST:
                        url += '&Sort=SubmissionTime:asc';
                        break;
                    default:
                }
            }
            if(limit !== null && limit !== '' && limit !== undefined && !isNaN(limit)){
                url += '&Limit='+limit;
                if(offset !== null && offset !== '' && offset !== undefined && !isNaN(offset)){
                    url += '&Offset='+offset;
                }
            }

            break;
        default:
    }

    print("buildBazaarVoiceURL:"+ url);
    return url;
}
