/**
 * Purpose: Script to integrate getProductReviews facade API with Bazzarvoice APIs.
 *
 * Developer: sungho.maeung2@T-Mobile.com
 *
 * Revisions: 7/28/2015
 */

/**
 * Extracting request post body , otherwise, throw error messages.
 */
var contentType = context.targetRequest.body.asJSON.ContentType;
var photo = context.targetRequest.body.asJSON.Photo;
var filename = context.targetRequest.body.asJSON.FileName;

/**
 * set up bazaar voice end point for uploading photo.
 */
var utilities = context.getVariable('utilities');
var settingsObject = context.getVariable('settingsObject');
var BAZARRVOICE_BASE_URL = utilities.safePath.get(settingsObject, 'bazaarvoice.bazaarEndpoint');
var BAZARRVOICE_QUERYIES = parseBazaarKeysValues( utilities.safePath.get(settingsObject, 'bazaarvoice.bazaarAppendString'));



print("contentType:"+ contentType);
print("photo:"+ photo);
print("bazarrvoice queries:"+ JSON.stringify(BAZARRVOICE_QUERYIES));


processUploadPhoto(contentType, photo);

/**
 * parse the pass key and api version
 * @param bazzarQueryKeysValues
 * bazaarAppendString : "&PassKey=8rzubp9jv3sekq3gkkxghk9m&ApiVersion=5.4"
 *
 * @return { PassKey : '......',
 *           ApiVersion : '5.4'}
 */
function parseBazaarKeysValues(bazzarQueryKeysValues){
    var parsed = bazzarQueryKeysValues.substring(1);
    var values = parsed.split('&');
    var passkeyValue = values[0].split('=');
    var apiVersionKeyValue = values[1].split('=');

    print("passkey:"+ passkeyValue + ", apiVersion:"+ apiVersionKeyValue);

    var rObj = {};
    rObj[passkeyValue[0]] = passkeyValue[1];
    rObj[apiVersionKeyValue[0]] = apiVersionKeyValue[1];
    return rObj;
}

/**
 * process Upload Photo to Bazaar Voice
 */
function processUploadPhoto(contentType, photo) {

    // construct Bazaar voice URL
    var bazaar_upload_voiceURL = BAZARRVOICE_BASE_URL+'/data/uploadphoto.json';

    var boundary = 'ThisIsBzaarVoiceBoundary1234567890';

    var formData = createFormDataImage(contentType, photo, boundary);

    print("formdataString:"+ formData);

    var httpOptions = {
        headers : {
            'Content-Type':'multipart/form-data; boundary="'+boundary+'"'
        },
        requestBody: formData,
        method: 'POST'
    };

    print("BazaaarVoiceURL:"+ bazaar_upload_voiceURL);
    print("httpOptions:"+ JSON.stringify(httpOptions));

    // call Bazaar Voice URL
    var responseMsg = executeBazaarVoiceCall(bazaar_upload_voiceURL, httpOptions);

    // set the response to Apigee response
    processResponseMsg( responseMsg, 200);

    print("processUploadPhoto():"+ JSON.stringify(responseMsg));
}

/**
 * create multipart/form-data for photo
 *
 * reference
 * http://chxo.com/be2/20050724_93bf.html
 *
 *
 * @param contentType
 * @param photo
 * @param boundary
 */
function createFormDataImage(contentType, photo, boundary){
    var formData = '--'+boundary + '\r\n';
    formData += 'Content-Disposition: form-data; name="apiversion"\r\n\r\n';
    formData += BAZARRVOICE_QUERYIES.ApiVersion + '\r\n';
    formData += '--'+boundary + '\r\n';
    formData += 'Content-Disposition: form-data; name="passkey"\r\n\r\n';
    formData += BAZARRVOICE_QUERYIES.PassKey + '\r\n';
    formData += '--'+boundary + '\r\n';
    formData += 'Content-Disposition: form-data; name="contenttype"\r\n\r\n';
    formData += 'Review' + '\r\n';
    formData += '--'+boundary + '\r\n';
    formData += 'Content-Disposition: form-data; name="photo"; filename="'+ filename + '"\r\n';
    formData += 'Content-Type: image/png\r\n';
    formData += 'Content-Transfer-Encoding: base64\r\n\r\n';
    formData += photo;
    formData += '\r\n';
    formData += '--'+boundary + '--\r\n';
    return formData;
}
/**
 * process Response message for Facade Apigee
 *
 */
function processResponseMsg(response, responseStatus){
    context.proxyResponse.content = JSON.stringify(response);
    context.proxyResponse.status = responseStatus;
}
/**
 * Execute Bazaar Voice Call and return a response message.
 *
 * @param url - a full url for bazaar voice
 * @param httpOptions - http options for REST call.
 * @return string Voice Response message , otherwise errors
 */
function executeBazaarVoiceCall(url, httpOptions) {
    var bazaarVoiceResponse = '';
    //Calling core URL
    var myRequest = new Request(url, httpOptions.method, httpOptions.headers, httpOptions.requestBody);
    var req1 = httpClient.send(myRequest);
    req1.waitForComplete();

    if (req1.isSuccess()) {
        var bazaarVoiceStatus = req1.getResponse().status;
        // TODO remove DEBUG statement
        context.setVariable("debug_bazaarVoiceStatus ", bazaarVoiceStatus);
        if (bazaarVoiceStatus == 200) {
            bazaarVoiceResponse = req1.getResponse().content.asJSON;
            print("executeBazaarVoiceCall(): 200 status")
        }
    } else if (req1.isError()) {
        processErrorMessage(500, "Internal Service Error", "Error calling BazaarVoice service " + url + ": " + JSON.stringify(req1.getError()));
    }
    return bazaarVoiceResponse;
 }

/**
 * error handling to Apigee Proxy
 */
function processErrorMessage(status, message, content){
    context.proxyResponse.status = status;
    context.proxyResponse.status.message =message;
    context.proxyResponse.content = content;
}