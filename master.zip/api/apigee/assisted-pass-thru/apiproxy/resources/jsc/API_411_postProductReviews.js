/**
 * Purpose: Script to integrate postProductReviews facade API with Bazzarvoice APIs.
 *
 * Developer: sungho.maeung2@T-Mobile.com
 *
 * Revisions: 8/2/2015
 */

/**
 * constant values Bazaarvoice submit
 */

var HOSTEDAUTHENTICATION_AUTHENTICATIONEMAIL_VALUE= 'Thomas.Manion3@T-Mobile.com';
var HOSTEDAUTHENTICATION_CALLBACKURL_VALUE = 'http://t-mobile.com';
var HOSTEDAUTHENTICATION_AUTHENTICATIONEMAIL_KEY= 'hostedauthentication_authenticationemail';
var HOSTEDAUTHENTICATION_CALLBACKURL_KEY = 'HostedAuthentication_CallbackUrl';
var ISRATINGONLY_KEY = 'isratingsonly';
var ISRATINGONLY_VALUE = 'false';

/**
 * set up bazaar voice end point for uploading photo.
 */
var utilities = context.getVariable('utilities');
var settingsObject = context.getVariable('settingsObject');
//var BAZAARVOICE_BASE_URL = 'http://rebelliondev-dev01.apigee.net/web-pass-thru/v1/bazaarvoice/data/';
var BAZAARVOICE_BASE_URL = 'http://stg.api.bazaarvoice.com/data/';
var BAZARRVOICE_QUERYIES = parseBazaarKeysValues411( utilities.safePath.get(settingsObject, 'bazaarvoice.bazaarAppendString'));

/**
 * Extracting request post body , otherwise, throw error messages.
 */
var requestBody  = context.targetRequest.body.asJSON;
/**
 * map for key and value, so that we can generate form data using map object.
 *
 * @type {{}}
 */
var map = {};

print("Facade Request JSON:"+ JSON.stringify(requestBody));

// create map for submission
createRequestBodyForReview(map, requestBody);
// process feedback page based on the type of feedback
processReviewSubmit( );

/**
 * generate a list of form data as request body
 */
function createRequestBodyForReview(map, requestBody) {

    // Rating secondary
    requestBody.rateStaticstics.forEach(function (rating) {
        if (rating.easeOfUse !== undefined) {
            map["rating_EaseOfUse"] = rating.easeOfUse;
        }
        if (rating.features !== undefined) {
            map["rating_Features"] = rating.features;
        }
        if (rating.batteryLife !== undefined) {
            map["rating_BatteryLife"] = rating.batteryLife;
        }
        if (rating.callQuality !== undefined) {
            map["rating_callQuality"] = rating.callQuality;
        }
    });

    if( requestBody.reviewRateSummary !== undefined){
        map["title"] = requestBody.reviewRateSummary;
    }

    map["reviewText"] = requestBody.reviewText;

    requestBody.pros.forEach(function(pro, index, array){
        var tagProField = "tag_Pro_"+(index+1);
        map[tagProField] = pro;
    });

    requestBody.cons.forEach(function(con, index){
        var tagConField = "tag_Con_"+(index+1);
        map[tagConField] = con;
    });


    requestBody.photos.forEach(function(photo, index){
        var photoField = "photocaption_"+(index+1);
        map[photoField] = photo.photoCaption;

        var photoUrlField = "photourl_"+(index+1);
        map[photoUrlField] = photo.photoUrl;
    } );

    if(requestBody.video.caption !== undefined){
        map["videocaption_1"] = requestBody.video.caption;
        map["videourl_1"] = requestBody.video.videoUrl;
    }


    if(requestBody.userNickName !== undefined){
        map["usernickname"] = requestBody.userNickName;
    }

    // BazaarVoice usernickname must only have letters and numbers.
    if(requestBody.wirelessExperience !== undefined){
        map["usernickname"] =  requestBody.userNickName;
    }

    if(requestBody.email !== undefined){
        map["useremail"] = requestBody.email;
    }

    if(requestBody.sendEmailAlertWhenPublished !== undefined){
        map["sendemailalertwhenpublished"]= requestBody.sendEmailAlertWhenPublished;
    }

    // required fields:
    map[HOSTEDAUTHENTICATION_AUTHENTICATIONEMAIL_KEY] = HOSTEDAUTHENTICATION_AUTHENTICATIONEMAIL_VALUE;
    map[HOSTEDAUTHENTICATION_CALLBACKURL_KEY] = HOSTEDAUTHENTICATION_CALLBACKURL_VALUE;
    map[ISRATINGONLY_KEY] = ISRATINGONLY_VALUE;
    // required field
    map["isrecommended"] = requestBody.isRecommended;
    map["passkey"] = BAZARRVOICE_QUERYIES.PassKey;
    map["apiversion"] = BAZARRVOICE_QUERYIES.ApiVersion;
    map["productid"] = requestBody.productId;
    map["rating"] = requestBody.rating;
    map["action"]= "submit";

}

/**
 * process submittion for request of Bazaarvoice
 */
function processReviewSubmit(){

    var facadeResponse = {};

    // construct Bazaar voice URL
    var bazaar_submitURL = BAZAARVOICE_BASE_URL+'submitreview.json';

    var formData = createFormData(map);

    print("formdataString:"+ formData);


    var httpOptions = {
        headers : {
            'Content-Type':'application/x-www-form-urlencoded'
        },
        requestBody: formData,
        method: 'POST'
    };

    print("BazaaarVoiceURL:"+ bazaar_submitURL);
    print("httpOptions:"+ JSON.stringify(httpOptions));

    // call Bazaar Voice URL
    var responseMsg = executeBazaarVoiceCall(bazaar_submitURL, httpOptions);

    buildFacadeRespnose(facadeResponse, responseMsg);

    // set the response to Apigee response
    processResponseMsg( facadeResponse, 200);

    print("processReviewSubmit():"+ JSON.stringify(facadeResponse));

}
/**
 * build Facade Resosne JSON structure based on BazaarVoice.
 *
 */
function buildFacadeRespnose(facadeResponse, responseMsg){
    if(typeof responseMsg.SubmissionId !== 'undefined'){
        facadeResponse.submissionId = responseMsg.SubmissionId;
    }

    if(typeof responseMsg.Errors !== 'undefined'){
        facadeResponse.errors = responseMsg.Errors;
    }
}
/**
 * parse the pass key and api version
 * @param bazzarQueryKeysValues
 * bazaarAppendString : "&PassKey=8rzubp9jv3sekq3gkkxghk9m&ApiVersion=5.4"
 *
 * @return { PassKey : '......',
 *           ApiVersion : '5.4'}
 */
function parseBazaarKeysValues411(bazzarQueryKeysValues){
    var parsed = bazzarQueryKeysValues.substring(1);
    var values = parsed.split('&');
    var passkeyValue = values[0].split('=');
    var apiVersionKeyValue = values[1].split('=');

    print("passkey:"+ passkeyValue + ", apiVersion:"+ apiVersionKeyValue);

    var rObj = {};
    rObj[passkeyValue[0]] = passkeyValue[1];
    rObj[apiVersionKeyValue[0]] = apiVersionKeyValue[1];
    return rObj;
}


/**
 * create a list of form data based on the give Map (key , value)
 * @param formstring - a list of form string
 */
function createFormData(map){
    var formdataString = '';

    for(var key in map ){
        formdataString += key +"=" + encodeURIComponent(map[key]) +"&";
    }
    // remove at the end of &
    formdataString = formdataString.slice(0,formdataString.length -1);
    return formdataString;
}


/**
 * process Response message for Facade Apigee
 *
 */
function processResponseMsg(response, responseStatus){
    context.proxyResponse.content = JSON.stringify(response);
    context.proxyResponse.status = responseStatus;
}
/**
 * Execute Bazaar Voice Call and return a response message.
 *
 * @param url - a full url for bazaar voice
 * @param httpOptions - http options for REST call.
 * @return string Voice Response message , otherwise errors
 */
function executeBazaarVoiceCall(url, httpOptions) {
    var bazaarVoiceResponse = '';
    //Calling core URL
    var myRequest = new Request(url, httpOptions.method, httpOptions.headers, httpOptions.requestBody);
    var req1 = httpClient.send(myRequest);
    req1.waitForComplete();

    if (req1.isSuccess()) {
        var bazaarVoiceStatus = req1.getResponse().status;
        // TODO remove DEBUG statement
        context.setVariable("debug_bazaarVoiceStatus ", bazaarVoiceStatus);
        if (bazaarVoiceStatus == 200) {
            bazaarVoiceResponse = req1.getResponse().content.asJSON;
            print("bazaarVoiceResponse"+ JSON.stringify(bazaarVoiceResponse));
        }
    } else if (req1.isError()) {
        processErrorMessage(500, "Internal Service Error", "Error calling BazaarVoice service " + url + ": " + JSON.stringify(req1.getError()));
    }
    return bazaarVoiceResponse;
}

/**
 * error handling to Apigee Proxy
 */
function processErrorMessage(status, message, content){
    context.proxyResponse.status = status;
    context.proxyResponse.status.message =message;
    context.proxyResponse.content = content;
}