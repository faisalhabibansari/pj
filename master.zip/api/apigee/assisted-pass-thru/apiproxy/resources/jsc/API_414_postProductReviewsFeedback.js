/**
 * Purpose: Script to integrate postProductReviewsFeedback facade API with Bazzarvoice APIs.
 *
 * Developer: sungho.maeung2@T-Mobile.com
 *
 * Revisions: 7/28/2015
 */

var HELPFULNESS_PAGE = 'helpfulness';
var INAPPROPRIATE_PAGE = 'inappropriate';


/**
 * Extracting request post body , otherwise, throw error messages.
 */
var contentId = context.targetRequest.body.asJSON.reviewId;
var reasonText = context.targetRequest.body.asJSON.reasonText;
var feedbackType = context.targetRequest.body.asJSON.feedbackType;

/**
 * set up bazaar voice end point for uploading photo.
 */
var utilities = context.getVariable('utilities');
var settingsObject = context.getVariable('settingsObject');
var BAZAARVOICE_BASE_URL = 'http://rebelliondev-dev01.apigee.net/web-pass-thru/v1/bazaarvoice/data/';
var BAZARRVOICE_QUERYIES = parseBazaarKeysValues414( utilities.safePath.get(settingsObject, 'bazaarvoice.bazaarAppendString'));



print("contentId:"+ contentId);
print("reasonText:"+ reasonText);
print("feedbackType:"+ feedbackType);

// process feedback page based on the type of feedback
processFeedbackPage( whichPageHelpfulness(feedbackType) );


/**
 * parse the pass key and api version
 * @param bazzarQueryKeysValues
 * bazaarAppendString : "&PassKey=8rzubp9jv3sekq3gkkxghk9m&ApiVersion=5.4"
 *
 * @return { PassKey : '......',
 *           ApiVersion : '5.4'}
 */
function parseBazaarKeysValues414(bazzarQueryKeysValues){
    var parsed = bazzarQueryKeysValues.substring(1);
    var values = parsed.split('&');
    var passkeyValue = values[0].split('=');
    var apiVersionKeyValue = values[1].split('=');

    print("passkey:"+ passkeyValue + ", apiVersion:"+ apiVersionKeyValue);

    var rObj = {};
    rObj[passkeyValue[0]] = passkeyValue[1];
    rObj[apiVersionKeyValue[0]] = apiVersionKeyValue[1];
    return rObj;
}

/**
 * find out which feedback type was.
 *
 * @param feedbackType - inappropriate or helpfulness
 * @return string of inappropriate or helpfulness
 */
function whichPageHelpfulness(feedbackType){
    // default value as landing page
    var whichPage;
    whichPage = HELPFULNESS_PAGE;
    if( feedbackType == INAPPROPRIATE_PAGE ) {
        whichPage = INAPPROPRIATE_PAGE;
    }

    print("whichPageHelpfulness:"+ whichPage);
    return whichPage;
}

/**
 * create a list of form data based on the give feedback type
 * @param feedbackType - helpfulness or inappropriate
 */
function createFormData(feedbackType){
    var formdataString = '';
    switch(feedbackType){
        case HELPFULNESS_PAGE:
            formdataString += "Vote="+context.targetRequest.body.asJSON.vote+"&";
            print("helpfulness form vote:"+ formdataString);
            break;
        case INAPPROPRIATE_PAGE:
            formdataString += "ReasonText="+reasonText+"&";
            break;
        default:
            break;
    }
    formdataString += "ContentId="+contentId+"&";
    formdataString += "ContentType=review&FeedbackType="+feedbackType+"&";
    formdataString += "passkey="+BAZARRVOICE_QUERYIES.PassKey+"&apiversion="+BAZARRVOICE_QUERYIES.ApiVersion;
    return formdataString;
}
/**
 * process Upload Photo to Bazaar Voice
 * @param feedbackType - helefulness or inappropriate
 *
 */
function processFeedbackPage(feedbackType) {

    // construct Bazaar voice URL
    var bazaar_feedbackURL = BAZAARVOICE_BASE_URL+'submitfeedback.json';

    var formData = createFormData(feedbackType);

    print("formdataString:"+ formData);

    var httpOptions = {
        headers : {
            'Content-Type':'application/x-www-form-urlencoded'
        },
        requestBody: formData,
        method: 'POST'
    };

    print("BazaaarVoiceURL:"+ bazaar_feedbackURL);
    print("httpOptions:"+ JSON.stringify(httpOptions));

    // call Bazaar Voice URL
    var responseMsg = executeBazaarVoiceCall(bazaar_feedbackURL, httpOptions);

    // set the response to Apigee response
    processResponseMsg( responseMsg, 200);

    print("processHelpfulnessPage():"+ JSON.stringify(responseMsg));
}

/**
 * process Response message for Facade Apigee
 *
 */
function processResponseMsg(response, responseStatus){
    context.proxyResponse.content = JSON.stringify(response);
    context.proxyResponse.status = responseStatus;
}
/**
 * Execute Bazaar Voice Call and return a response message.
 *
 * @param url - a full url for bazaar voice
 * @param httpOptions - http options for REST call.
 * @return string Voice Response message , otherwise errors
 */
function executeBazaarVoiceCall(url, httpOptions) {
    var bazaarVoiceResponse = '';
    //Calling core URL
    var myRequest = new Request(url, httpOptions.method, httpOptions.headers, httpOptions.requestBody);
    var req1 = httpClient.send(myRequest);
    req1.waitForComplete();

    if (req1.isSuccess()) {
        var bazaarVoiceStatus = req1.getResponse().status;
        // TODO remove DEBUG statement
        context.setVariable("debug_bazaarVoiceStatus ", bazaarVoiceStatus);
        if (bazaarVoiceStatus == 200) {
            bazaarVoiceResponse = req1.getResponse().content.asJSON;
            print("executeBazaarVoiceCall(): 200 status")
        }
    } else if (req1.isError()) {
        processErrorMessage(500, "Internal Service Error", "Error calling BazaarVoice service " + url + ": " + JSON.stringify(req1.getError()));
    }
    return bazaarVoiceResponse;
 }

/**
 * error handling to Apigee Proxy
 */
function processErrorMessage(status, message, content){
    context.proxyResponse.status = status;
    context.proxyResponse.status.message =message;
    context.proxyResponse.content = content;
}