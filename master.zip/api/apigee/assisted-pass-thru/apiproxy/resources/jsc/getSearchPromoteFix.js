// Script Name:
//				getSearchPromoteFix.js
//
// Author:
//				Stephan Cossette
//
// Last Rev. Date:
//				05/15/2015
//
// Synopsis:
//				This JavaScript file strips "\search-promote\" from the "proxy.pathsuffix",
//				then creates/assigns the newTargetUrl and passes it to "rewriteTargetURL.js".
//
//				NOTE: URL must have a '/' after the endpoint criterion!!!
//				      (e.g.  must be "/search-promote/?q=apple&do=json&type=product"
//						     **NOT** "/search-promote?q=apple&do=json&type=product"
//                                                   ^ 
//                                                   ^ 

var settings = context.getVariable('settingsObject');
var utilities = context.getVariable('utilities');

var originalQueryString = context.getVariable("request.querystring");
var strippedProxyPathsuffix = context.getVariable("proxy.pathsuffix").replace("\/search-promote\/", "");

var endPoint = utilities.safePath.get(settings, 'searchAndPromote.searchAndPromoteEndpoint');
var newTargetUrl = endPoint + "/" + strippedProxyPathsuffix + "?" + originalQueryString;

context.setVariable("newTargetUrl", newTargetUrl);