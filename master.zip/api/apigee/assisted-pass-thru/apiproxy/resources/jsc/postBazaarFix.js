// Script Name:
//				getBazaarFix.js
//
// Author:
//				Stephan Cossette
//
// Last Rev. Date:
//				05/15/2015
//
// Synopsis:
//				This JavaScript file strips "\bazaarvoice\" from the "proxy.pathsuffix",
//				appends the specific PassKey/ApiVersion string to the "request.formstring",
//				and then creates/assigns the newFormString and newTargetUrl, then passes
//				it to "rewriteTargetURL.js".
//
//				NOTE: URL must have a '/' after the endpoint criterion!!!
//				      (e.g.  must be "/bazaarvoice/?q=apple&do=json&type=product"
//						     **NOT** "/bazaarvoice?q=apple&do=json&type=product"
//                                                   ^ 
//   

var settings = context.getVariable('settingsObject');
var utilities = context.getVariable('utilities');

var originalFormString = context.getVariable("request.formstring");
var strippedProxyPathsuffix = context.getVariable("proxy.pathsuffix").replace("\/bazaarvoice\/", "");

var endPoint = utilities.safePath.get(settings, 'bazaarvoice.bazaarEndpoint');
var appendString = utilities.safePath.get(settings, 'bazaarvoice.bazaarAppendString');

var newTargetUrl = endPoint + "/" + strippedProxyPathsuffix;
var newFormString = originalFormString + appendString;

context.setVariable("newTargetUrl", newTargetUrl);
context.setVariable("newFormString", newFormString);