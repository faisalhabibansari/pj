var utilities = context.getVariable('utilities');
var settings = context.getVariable('settingsObject');

var dataType = "mock-line";
var id = context.getVariable("msisdn");

var headers =
{
	'Content-Type' : 'application/json'
};

utilities.commonMockRequest(settings.routes.getMockEndpoint, id, dataType, "GET", headers, null, null, function(response)
{
	context.proxyResponse.content = JSON.stringify(response);
}, function(error)
{
	context.proxyResponse.status = 500;
	context.proxyResponse.status.message = "Internal Service Error";
	context.proxyResponse.content = JSON.stringify(error);
});