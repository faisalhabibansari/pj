var reqPayLoad = context.targetRequest.body.asJSON
var cartId = context.getVariable("cartId");


if(reqPayLoad!=null && reqPayLoad!= '')
{
 context.setVariable('dataType', 'deleteCartItem');
 if(cartId=='1300')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==4)
  {
   context.setVariable("objectId", "001");
  }
  else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1)
  {
   context.setVariable("objectId", "002");
  }
   else
  {
   context.setVariable("objectId", cartId);
  }
 }
 else if(cartId=='1501')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==2 && reqPayLoad.items[0].id == "14" && reqPayLoad.items[1].id == "15")
  {
   context.setVariable("objectId", "003");
  }
   else if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==3 && reqPayLoad.items[0].id == "14" && reqPayLoad.items[1].id == "15" && reqPayLoad.items[2].id == "16") 
 {
   context.setVariable("objectId", "005");
  }
     }
 else if(cartId=='1502')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].id == "16")
  {
   context.setVariable("objectId", "004");
  }
 }
  else if(cartId=='1506')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==3 && reqPayLoad.items[0].id == "14" && reqPayLoad.items[1].id == "15" && reqPayLoad.items[2].id == "16")
  {
   context.setVariable("objectId", "006");
  }
 }
  else if(cartId=='1521')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==5 && reqPayLoad.items[0].id == "1" && reqPayLoad.items[1].id == "2" && reqPayLoad.items[2].id == "3" && reqPayLoad.items[3].id == "4" && reqPayLoad.items[4].id == "5")
  {
   context.setVariable("objectId", "012");
  }
 }
  else if(cartId=='460000')
 {
  if(reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].id == "22222")
  {
   context.setVariable("objectId", "008");
  }
 }
  else if(cartId=='460001'){
  if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].id == "11111")
   {
 context.setVariable("objectId", "009");
     }
 }
  else if(cartId=='460006'){
  if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].id == "11111")
   {
 context.setVariable("objectId", "010");
     }
 }
  else if(cartId=='1522'){
  if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==5 && reqPayLoad.items[0].id == "16")
   {
 context.setVariable("objectId", "011");
     }
 }
  else if(cartId=='1234'){
  if (reqPayLoad.items instanceof Array && reqPayLoad.items.length==1 && reqPayLoad.items[0].id == "2")
   {
 context.setVariable("objectId", "013");
     }
 }
  else
 {
  context.setVariable("objectId", cartId);
 }
}