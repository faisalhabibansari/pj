var pageCategory = context.proxyRequest.queryParams['pageCategory'];
var pageType = context.proxyRequest.queryParams['pageType'];
if(pageCategory=='login' && pageType=='termsAndCondition'){
context.setVariable("dataType","TermsConditions");
context.setVariable("objectId","001");
}
else {context.setVariable("objectId","000");}
