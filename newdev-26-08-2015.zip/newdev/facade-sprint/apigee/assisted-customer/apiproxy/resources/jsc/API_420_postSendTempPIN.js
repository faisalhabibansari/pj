var reqPayLoad = context.targetRequest.body.asJSON
var customerId= reqPayLoad.customerId;
var type = reqPayLoad.method.type;

//Setting dataType
context.setVariable('dataType','postSendTempPIN');

context.setVariable('objectId',"CI_"+customerId+"_TP_"+type);