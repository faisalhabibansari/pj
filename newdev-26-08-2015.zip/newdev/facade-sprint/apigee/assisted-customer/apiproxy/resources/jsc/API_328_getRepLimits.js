var repId=context.getVariable("repId");
var amount=context.getVariable("request.queryparam.amount");

context.setVariable("dataType",'getRepLimits');

context.setVariable("objectId","001");
