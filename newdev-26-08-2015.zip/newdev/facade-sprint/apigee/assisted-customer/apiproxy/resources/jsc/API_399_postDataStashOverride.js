var reqPayLoad = context.targetRequest.body.asJSON
if(reqPayLoad!=null && reqPayLoad!='')
{
  context.setVariable("dataType",'postDataStashOverride');
  
 if(reqPayLoad.repId=='12345' && reqPayLoad.actionCode=='Add')
 {
   context.setVariable("objectId","001");
 }
 else if(reqPayLoad.repId=='Rcross' && reqPayLoad.actionCode=='Add')
 {
  context.setVariable("objectId","002");
 }
  else if(reqPayLoad.repId=='Rcross' && reqPayLoad.actionCode=='Remove')
 {
  context.setVariable("objectId","003");
 }
  else if(reqPayLoad.repId=='JDaniel123' && reqPayLoad.actionCode=='Add')
 {
  context.setVariable("objectId","005");
 }
   else if(reqPayLoad.repId=='JDaniel123' && reqPayLoad.actionCode=='Remove')
 {
  context.setVariable("objectId","006");
 }
}
else
{
  context.setVariable("objectId","000");
}