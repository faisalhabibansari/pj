var req_payload = context.targetRequest.body.asJSON
var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
// var lineId=context.getVariable("lineId");

context.setVariable("dataType", "BanEligibility");
// context.setVariable("objectId", "0000")

if (req_payload != null)
{
	if (req_payload.accountId == '56556')
	{
		context.setVariable("objectId", '56556');
	}
	else if (customerId == '234234328' && req_payload.accountId == '123123')
	{
		context.setVariable("objectId", '123123');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000001'
			&& req_payload.numberOfLines == '1')
	{
		context.setVariable("objectId", '004');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000001')
	{
		context.setVariable("objectId", '021');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000001'
			&& req_payload.eips[0].id == '12345')
	{
		context.setVariable("objectId", '022');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000001')
	{
		context.setVariable("objectId", '005');
	}

	else if (customerId == '500000001' && req_payload.accountId == '123125' && req_payload.newCustomerId == '500000001')
	{
		context.setVariable("objectId", '006');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123125' && req_payload.numberOfLines == '3')
	{
		context.setVariable("objectId", '019')
	}
	else if (customerId == '500000001' && req_payload.accountId == '123127' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '010');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123127' && req_payload.newCustomerId == '')
	{
		context.setVariable("objectId", '020');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123333' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '011');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '012');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000004')
	{
		context.setVariable("objectId", '013');
	}
	else if (customerId == '500000001' && req_payload.accountId == '999987' && req_payload.lines[0].msisdn == '2061255555')
	{
		context.setVariable("objectId", '014');
	}
	else if (req_payload.newCustomerId == '500000003' && req_payload.accountId == '999987' && req_payload.lines[0].msisdn == '2061255555')
	{
		// steve added (8/18/2015)
		context.setVariable("objectId", 'SC01');
	}
	else if (customerId == '500000001' && req_payload.accountId == '999987' && req_payload.lines[0].msisdn == '6021234934')
	{
		context.setVariable("objectId", '017');
	}
	else if (customerId == '500000001' && req_payload.accountId == '999987' && req_payload.lines[0].msisdn == '6021234600')
	{
		context.setVariable("objectId", '018');
	}
	else if (customerId == '500000001' && req_payload.accountId == '999988' && req_payload.lines[0].msisdn == '6021234600')
	{
		context.setVariable("objectId", '015');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123127' && req_payload.lines[0].msisdn == '2062234567')
	{
		context.setVariable("objectId", '016');
	}
	else if (customerId == '500000001' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000001'
			&& req_payload.numberOfLines == '0')
	{
		context.setVariable("objectId", '0023');
	}
	else if (customerId == '500000002' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000002')
	{
		context.setVariable("objectId", '001');
	}
	else if (customerId == '500000002' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000002')
	{
		context.setVariable("objectId", '008');
	}
	else if (customerId == '500000002' && req_payload.accountId == '123129' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '032');
	}
	else if (customerId == '500000002' && req_payload.accountId == '123128' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '009');
	}
	else if (customerId == '500000006' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0010');
	}
	else if (customerId == '500000005' && req_payload.accountId == '123333' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0011');
	}
	else if (customerId == '500000010' && req_payload.accountId == '123127' && req_payload.newCustomerId == '500000004')
	{
		context.setVariable("objectId", '0012');
	}
	else if (customerId == '500000009' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000009')
	{
		context.setVariable("objectId", '0013');
	}
	else if (customerId == '500000008' && req_payload.accountId == '123127' && req_payload.newCustomerId == '500000004')
	{
		context.setVariable("objectId", '0014');
	}
	else if (customerId == '500000008' && req_payload.accountId == '123127' && req_payload.newCustomerId == '')
	{
		context.setVariable("objectId", '0015');
	}
	else if (customerId == '500000007' && req_payload.accountId == '123124' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0016');
	}
	else if (customerId == '500000014' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000004')
	{
		context.setVariable("objectId", '0017');
	}
	else if (customerId == '500000013' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0018');
	}
	else if (customerId == '500000012' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0019');
	}
	else if (customerId == '500000011' && req_payload.accountId == '123123' && req_payload.newCustomerId == '500000003')
	{
		context.setVariable("objectId", '0020');
	}
	else if (customerId == '500000011' && req_payload.accountId == '123123' && req_payload.newCustomerId == '')
	{
		context.setVariable("objectId", '0021');
	}
	else if (customerId == '500000015' && req_payload.accountId == '123123' && req_payload.newCustomerId == '')
	{
		context.setVariable("objectId", '0022');
	}
	else if (customerId == '741852' && req_payload.accountId == '123123789' && req_payload.lines[0].msisdn == '4251234567'
			&& req_payload.newCustomerId == '741852')
	{
		context.setVariable("objectId", '0024');
	}
	else if (customerId == '741852' && req_payload.accountId == '123123789' && req_payload.lines[0].msisdn == '6021238367'
			&& req_payload.newCustomerId == '741852')
	{
		context.setVariable("objectId", '0025');
	}
	else if (customerId == '741852' && req_payload.accountId == '123123789' && req_payload.lines[0].msisdn == '6021238367'
			&& req_payload.newCustomerId == '963852')
	{
		context.setVariable("objectId", '0026');
	}
	else if (customerId == '741852' && req_payload.accountId == '123123790' && req_payload.lines[0].msisdn == '4251234570'
			&& req_payload.newCustomerId == '741852')
	{
		context.setVariable("objectId", '0040');
	}
	else if (customerId == '555555555' && req_payload.accountId == '456785' && req_payload.lines[0].msisdn == '2424242424'
			&& req_payload.newCustomerId == '555555555')
	{
		context.setVariable("objectId", '0027');
	}
	else if (customerId == '555555555' && req_payload.accountId == '456786' && req_payload.lines[0].msisdn == '2727272727'
			&& req_payload.newCustomerId == '555555555')
	{
		context.setVariable("objectId", '0028');
	}
	else if (customerId == '555555555' && req_payload.accountId == '456787' && req_payload.lines[0].msisdn == '2929292929'
			&& req_payload.newCustomerId == '555555555')
	{
		context.setVariable("objectId", '0029');
	}
	else if (customerId == '555555555' && req_payload.accountId == '456786' && req_payload.lines[0].msisdn == '2424242424'
			&& req_payload.newCustomerId == '555555555')
	{
		context.setVariable("objectId", '0030');
	}
	else if (customerId == '555555555' && req_payload.accountId == '456786' && req_payload.lines[0].msisdn == '2727272727'
			&& req_payload.newCustomerId == '555555555')
	{
		context.setVariable("objectId", '0031');
	}

	/* else if(customerId=='500000003' && req_payload.accountId=='123127')
	{
	    context.setVariable("objectId",'002');
	}
	else if(customerId=='500000003' && req_payload.accountId=='123128')
	{
	    context.setVariable("objectId",'003');
	}
	else if(customerId=='500000003' && req_payload.accountId=='123333')
	{
	    context.setVariable("objectId",'0002');
	}
	else if(customerId!='500000003' && req_payload.accountId=='123127')
	{
	    context.setVariable("objectId",'123127');
	}
	else if(customerId=='500000003' && req_payload.accountId=='123124')
	{
	    context.setVariable("objectId",'0003');
	}
	else if(customerId=='500000004' && req_payload.accountId=='123123')
	{
	    context.setVariable("objectId",'0001');
	} */
	else if (req_payload.accountId == '123456')
	{
		context.setVariable("objectId", '123456');
	}
	else if (req_payload.accountId == '123126')
	{
		context.setVariable("objectId", '123126');
	}
	else
	{
		context.setVariable("objectId", "0000");
	}
}