var customerId  = context.getVariable('customerId');
var accountId  = context.getVariable('accountId');

context.setVariable('dataType', 'getBillDetails');

context.setVariable('objectId', "001");  
