var reqPayLoad = context.targetRequest.body.asJSON
var customerId = context.getVariable("objectId");


if(reqPayLoad!=null && reqPayLoad!='')
{
 var type = reqPayLoad.type;
 var isValid = reqPayLoad.isValid;
 var value = reqPayLoad.value;

 if(customerId=='1241' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='12345' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='33456' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='425123' && type=='photoID')
 {
  context.setVariable("objectId","999");
 }
 else if(customerId=='741852' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='1241' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='12345' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='33456' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='741852' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='425435' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='963852' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='963852' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='425435' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='963852' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='234234328' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='234234328' && type=='photoID')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='425436' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='425437' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='741856' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
  else if(customerId=='425436' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='425437' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(customerId=='741856' && type=='pin')
 {
  context.setVariable("objectId","001");
 }
 else if(type=='login')
 {
   if(customerId=='1234')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='23456')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22245')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22246')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22247')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22248')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22249')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22250')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22251')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22252')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22253')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22254')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22255')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22256')
   {
    context.setVariable("objectId","001");
   }
}
 else if(type=='photoID')
 {
   if(customerId=='1234')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='23456')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22245')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22246')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22247')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22248')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22249')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22250')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22251')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22252')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22253')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22254')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='22255')
   {
    context.setVariable("objectId","001");
   }
    else if(customerId=='22256')
   {
    context.setVariable("objectId","001");
   }
   else if(customerId=='982333')
   {
    context.setVariable("objectId","001");
   }
     else if(customerId=='12015')
   {
    context.setVariable("objectId","001");
   }
}
else if(type=='pin')
{
  if(customerId=='500000001')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000002')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000003')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000011')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000015')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='555555555')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='234234328')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='8900781')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='2345678')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234566')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234567')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234569')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234570')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='9876543210' && value==7070)
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='8900781')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='2345678')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234566')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234567')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234569')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234570')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='9876543210' && value==7070)
  {
    context.setVariable("objectId","001");
  }
}
  else if(type=='photoId')
{
  if(customerId=='500000001')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000002')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000003')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000011')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='500000015')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='555555555')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='234234328')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='8900781')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='2345678')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234566')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234567')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234569')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='1234570')
  {
    context.setVariable("objectId","001");
  }
  else if(customerId=='9876543210' && isValid==true)
  {
   context.setVariable("objectId","001");
  }
}
  else if(
(customerId=='500000015' || customerId=='500000011' || customerId=='500000003' || customerId=='500000002' || customerId=='500000001' || customerId=='111222333' || customerId=='222333444' || customerId=='333444555' || customerId=='444555666' || customerId=='666777888' || customerId=='888999111'
           || customerId=='888999222' || customerId=='888999333' || customerId=='888999444' || customerId=='888999555' || customerId=='888999666')
           && (type=='pin' || type=='photoID')
    )
    
  {
  context.setVariable("objectId","001");
 }
  
 else
 {
  context.setVariable("objectId",customerId);
 }

}
