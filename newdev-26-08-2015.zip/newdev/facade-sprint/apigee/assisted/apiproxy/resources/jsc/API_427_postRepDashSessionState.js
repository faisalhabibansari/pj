var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postRepDashSessionState");

if(reqPayLoad!=null)
{
  if(reqPayLoad.repId=="" && reqPayLoad.sessionKey=="")
  {
    context.setVariable("objectId","001");
  }
  else
  {
   context.setVariable("objectId","000");
  }
}
else
{
  context.setVariable("objectId","000");
}