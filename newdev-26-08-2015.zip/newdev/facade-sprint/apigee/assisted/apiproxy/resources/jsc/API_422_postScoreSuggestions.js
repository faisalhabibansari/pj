var req_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
req_payload = JSON.parse(context.getVariable('request.content'));

}

context.setVariable("dataType", "postScoreSuggestions");
var a=null;

if(req_payload.lines instanceof Array && req_payload.lines.length==1 && JSON.stringify(req_payload).indexOf("devices,accessories")!= -1)
{
    if(req_payload.lines[0].lineId == '55556')
        {
        context.setVariable("objectId","011");
    }
    else if(req_payload.lines[0].lineId == '55554' && req_payload.lines[0].selectedDeviceId == '101')
    {
        context.setVariable("objectId","015");
    } 
    else if(req_payload.lines[0].lineId == '55554')
    {
        context.setVariable("objectId","001");
    }
    
}
else if (req_payload.lines instanceof Array && req_payload.lines.length == 2 && JSON.stringify(req_payload).indexOf("devices,accessories") != -1) {

    if (req_payload.lines[0].selectedDeviceId == null && req_payload.lines[1].selectedDeviceId == null) {
        context.setVariable("objectId", "006");
    } else if (req_payload.lines[0].selectedDeviceId !=null && req_payload.lines[1].selectedDeviceId == null) {
        context.setVariable("objectId", "007");
    } else if (req_payload.lines[0].selectedDeviceId != null && req_payload.lines[1].selectedDeviceId != null) {
        context.setVariable("objectId", "005");
    } }
else if(req_payload.lines instanceof Array && req_payload.lines.length==3 && JSON.stringify(req_payload).indexOf("devices,accessories")!= -1)
{
    
    if(req_payload.lines[0].selectedDeviceId != null && req_payload.lines[1].selectedDeviceId != null && req_payload.lines[2].selectedDeviceId != null)
      {
        context.setVariable("objectId","004");
        }
    else if(req_payload.lines[0].selectedDeviceId!= null && req_payload.lines[1].selectedDeviceId != null && req_payload.lines[2].selectedDeviceId== null)
      {
        context.setVariable("objectId","003");
        }
    else if(req_payload.lines[0].selectedDeviceId != null && req_payload.lines[1].selectedDeviceId== null && req_payload.lines[2].selectedDeviceId== null)
        {
            context.setVariable("objectId","002");
        }
    else if(req_payload.lines[0].selectedDeviceId== null && req_payload.lines[1].selectedDeviceId== null && req_payload.lines[2].selectedDeviceId== null)
        {
            context.setVariable("objectId","009");
        }
}