context.setVariable("dataType","getRefillCards");
context.setVariable("objectId","000");