var reqPayLoad = context.targetRequest.body.asJSON;

if((reqPayLoad!==null) && (reqPayLoad!==''))
{
    if((reqPayLoad.toNumber=='425-999-1234'))
    {
        context.setVariable("sendSmsTo","425-999-1234");    
    }
    else if((reqPayLoad.toNumber=='425-999-9999'))
    {
        context.setVariable("sendSmsTo","425-999-9999");    
    }
    else if((reqPayLoad.toNumber=='555-123-0987'))
    {
        context.setVariable("sendSmsTo","555-123-0987");    
    }
    else if((reqPayLoad.toNumber=='5551234575'))
    {
        context.setVariable("sendSmsTo","123-123-4567");    
    }
    else if((reqPayLoad.toNumber=='5551234568'))
    {
        context.setVariable("sendSmsTo","123-123-4568");    
    }
    else
    {
        context.setVariable("sendSmsTo","");  
    }
}