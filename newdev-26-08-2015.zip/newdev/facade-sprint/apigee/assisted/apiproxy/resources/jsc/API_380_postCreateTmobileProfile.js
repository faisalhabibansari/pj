var reqPayLoad = context.targetRequest.body.asJSON
context.setVariable("dataType","postCreateTmobileProfile");
if(reqPayLoad!=null && reqPayLoad!='')
  {
context.setVariable("objectId","001");
}
