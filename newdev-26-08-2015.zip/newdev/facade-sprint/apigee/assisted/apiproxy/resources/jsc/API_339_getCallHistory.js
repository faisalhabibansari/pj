var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");
var usageType=context.getVariable("request.queryparam.usageType");
var filter=context.getVariable("request.queryparam.filter");
var limit=context.getVariable("request.queryparam.limit");
var offset=context.getVariable("request.queryparam.offset");
var line=context.getVariable("request.queryparam.line");
var startDate=context.getVariable("request.queryparam.startDate");
var endDate=context.getVariable("request.queryparam.endDate");
var phoneNumber=context.getVariable("request.queryparam.phoneNumber");
var destination=context.getVariable("request.queryparam.destination");
var type=context.getVariable("request.queryparam.type");

context.setVariable("dataType","getCallHistory");

if (accountId == '12341234') {
 context.setVariable("objectId", "12341234");
}
else if (accountId=='55555' && sort=='date' && filter==undefined)
{
 context.setVariable("objectId", "003");
}
else if(accountId=='55555' && sort=='duration' && filter==undefined)
{
 context.setVariable("objectId","004");
}
else if(accountId=='55555' && sort=='cost')
{
 context.setVariable("objectId","005");
}
else if(accountId=='55555' && sort=='duration')
{
 context.setVariable("objectId","006");
}
else if(accountId=='55555' && sort=='date')
{
 context.setVariable("objectId","007");
}
else if(accountId=='55555')
{
 context.setVariable("objectId","55555");
}
else if(accountId=='123456678'&& filter=='line=4567239871')
{
 context.setVariable("objectId","008");
}
else if(accountId=='123456678'&& filter=='phoneNumber=8765439877')
{
 context.setVariable("objectId","009");
}
else if(accountId=='123456678'&& filter=='type=Wi-Fi Call')
{
 context.setVariable("objectId","010");
}
else if(accountId=='123456678'&& filter=='startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","011");
}
else if(accountId=='123456678'&& filter=='startDate=01/01/2014,endDate=06/30/2014')
{
 context.setVariable("objectId","012");
}
else if(accountId=='123456678'&& filter=='line=4567239871,phoneNumber=8765439877,type=Wi-Fi Call,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","013");
}
else if(accountId=='123456678'&& filter=='phoneNumber=8765439876,8765439877')
{
 context.setVariable("objectId","014");
}
else if(accountId=='123456678'&& filter=='type=Wi-Fi Call, Domestic roaming')
{
 context.setVariable("objectId","015");
}
else if(accountId=='123456678'&& filter=='line=4567239871,type=Wi-Fi Call,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","016");
}
else if(accountId=='123456678'&& filter=='line=4567239871,startDate=01/01/2015,endDate=06/30/2015')
{
 context.setVariable("objectId","017");
}
else if(accountId=='123456678'&& filter=='destination=Seattle, WA')
{
 context.setVariable("objectId","018");
}
else if(customerId=='425435' && accountId=='123456678')
{
	if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && type=='Domestic roaming' && usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis008");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && type=='Domestic roaming' && usageType=='talk' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis009");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis010");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && type=='Data Stash' && usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis011");
	}
	else if(line=='4567239871,4567239872,4567239873' && startDate=='05/01/2015' && endDate=='08/10/2015' && type=='Data Stash' && usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis021");
	}
	else if(line=='4567239871,4567239872' && startDate=='05/01/2015' && endDate=='08/10/2015' && usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis012");
	}
	else if(line=='4567239871,4567239872' && startDate=='05/01/2015' && endDate=='08/10/2015' && usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis013");
	}
	else if(usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis005");
	}
	else if(usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis006");
	}
	else if(usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis001");
	}
	else if(usageType=='talk' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis002");
	}
	else if(usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis003");
	}
	else if(usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis004");
	}
	else if(usageType=='talk,text' && sort=='cost' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis007");
	}
	else if(usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis014");
	}
	else if(usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis015");
	}
	else if(usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis016");
	}
	else if(usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis017");
	}
	else if(usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis018");
	}
	else if(usageType=='talk,text' && sort=='cost' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Francis019");
	}
	else if(usageType=='data' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis020");
	}
  	else if(usageType=='talk,text' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis022");
	}
    else if(usageType=='talk' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis023");
    }
    else if(usageType=='text' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis024");
    }
    else if(usageType=='tmobile purchases' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis025");
    }
    else if(usageType=='third party purchases' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Francis026");
    }
}
else if(customerId=='982564' && accountId=='123457788')
{
	if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && type=='Domestic roaming' && usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane008");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && type=='Domestic roaming' && usageType=='talk' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane009");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && phoneNumber=='8765439876,8765439877,8765439874,8765439871' && destination=='New York, NY' && usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane010");
	}
	else if(line=='4567239871,4567239872,4567239873,4567239874' && startDate=='05/01/2015' && endDate=='08/10/2015' && type=='Data Stash' && usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane011");
	}
	else if(line=='4567239871,4567239872,4567239873' && startDate=='05/01/2015' && endDate=='08/10/2015' && type=='Data Stash' && usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane021");
	}
	else if(line=='4567239871,4567239872' && startDate=='05/01/2015' && endDate=='08/10/2015' && usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane012");
	}
	else if(line=='4567239871,4567239872' && startDate=='05/01/2015' && endDate=='08/10/2015' && usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane013");
	}
	else if(usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane005");
	}
	else if(usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane006");
	}
	else if(usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane001");
	}
	else if(usageType=='talk' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane002");
	}
	else if(usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane003");
	}
	else if(usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane004");
	}
	else if(usageType=='talk,text' && sort=='cost' && sortOrder=='desc' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane007");
	}
	else if(usageType=='talk,text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane014");
	}
	else if(usageType=='text' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane015");
	}
	else if(usageType=='data' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane016");
	}
	else if(usageType=='tmobile purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane017");
	}
	else if(usageType=='third party purchases' && sort=='date' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane018");
	}
	else if(usageType=='talk,text' && sort=='cost' && sortOrder=='desc' && limit=='50' && offset=='50')
	{
		context.setVariable("objectId","Jane019");
	}
	else if(usageType=='data' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","Jane020");
	}
    else if(usageType=='talk,text' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","jane022");
	}
  
    else if(usageType=='talk' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","jane023");
    }
    else if(usageType=='text' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","jane024");
    }
    else if(usageType=='tmobile purchases' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","jane025");
    }
    else if(usageType=='third party purchases' && limit=='50' && offset=='0')
	{
		context.setVariable("objectId","jane026");
    }

}
else {
  context.setVariable("objectId",customerId);
}