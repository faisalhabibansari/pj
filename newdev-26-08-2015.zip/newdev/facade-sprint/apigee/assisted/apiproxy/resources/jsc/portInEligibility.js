var request_payload = '';
if (context.getVariable('request.content') != null && context.getVariable('request.content') != '')
{
	request_payload = JSON.parse(context.getVariable('request.content'));
}

// var request_payload = JSON.parse(context.getVariable('request.content'));

if (request_payload.msisdns != null)
{
	if (request_payload.msisdns.length == 1)
	{
		context.setVariable("objectId", request_payload.msisdns[0]);
	}
	else if (request_payload.msisdns.length > 1 && request_payload.msisdns[0] == '3125550000' && request_payload.msisdns[1] == '3125555555'
			&& request_payload.msisdns[2] == '3155556543' && request_payload.msisdns[3] == '5675675670'
			&& request_payload.msisdns[4] == '6786786780')
	{
		context.setVariable("objectId", "0000000002");
	}
	else if (request_payload.msisdns.length > 1)
	{
		context.setVariable("objectId", "0000000000");
	}
}
else
{
	if (request_payload.length == 1)
	{
		context.setVariable("objectId", request_payload[0]);
	}
	else if (request_payload.length > 1)
	{
		context.setVariable("objectId", "0000000001");
	}
}
