var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null){ 
  	
    context.setVariable("objectId", "12345");
}
else
{
    context.setVariable("objectId","0000");
}
context.setVariable("dataType","postPreOrder");