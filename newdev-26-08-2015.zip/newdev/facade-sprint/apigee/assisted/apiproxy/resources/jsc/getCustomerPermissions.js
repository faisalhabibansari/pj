var utilities = context.getVariable('utilities');
var settings = context.getVariable('settingsObject');

var originalQueryString = context.getVariable("request.querystring");

if (originalQueryString != "")
{
	var parameterObj = utilities.splitQueryString(originalQueryString);

	context.setVariable("debug_parameterObj", JSON.stringify(parameterObj));

	var mockId = "000";

	var custId, accountId, lineId;

	if (parameterObj.custId != undefined && parameterObj.accountId != undefined)
	{
		custId = parameterObj.custId.value;
		accountId = parameterObj.accountId.value;
		mockId = "001";
	}
	else if (parameterObj.custId != undefined && parameterObj.lineId != undefined)
	{
		custId = parameterObj.custId.value;
		lineId = parameterObj.lineId.value;
		mockId = "002";
	}
	else if (parameterObj.lineId != undefined && parameterObj.accountId != undefined)
	{
		lineId = parameterObj.lineId.value;
		accountId = parameterObj.accountId.value;
		mockId = "003";
	}

	context.setVariable("debug_mockId", "'" + mockId + "'");

	context.setVariable("debug_custId", "'" + custId + "'");
	context.setVariable("debug_accountId", "'" + lineId + "'");
	context.setVariable("debug_mockId", "'" + mockId + "'");

	var dataType = "getCustomerPermissionsData";

	if (mockId != "000")
	{

		var headers =
		{
			'Content-Type' : 'application/json'
		};

		utilities.commonMockRequest(settings.routes.getMockEndpoint, mockId, dataType, "GET", headers, null, null, function(response)
		{
			context.proxyResponse.content = JSON.stringify(response);
		}, function(error)
		{
			context.proxyResponse.status = 500;
			context.proxyResponse.status.message = "Internal Service Error";
			context.proxyResponse.content = JSON.stringify(error);
		});

	}
	else
	{
		context.proxyResponse.content = "Invalid case";
	}

}
else
{
	context.proxyResponse.content = "Parameter(s) missing";
}

/*

{"id":"001","dataType":"getCustomerPermissionsData","mockData":
{
  "permissions": {
    "role": "account-viewer",
    "uiElements": {
      "/payments": {
        "deleteAccountButton1": "hidden",
        "flagAccountButton1": "disabled",
        "secretInfoField1": "enabled"
      }
    }
  }
}
}

{"id":"002","dataType":"getCustomerPermissionsData","mockData":
{
  "permissions": {
    "role": "line-subscriber",
    "uiElements": {
      "/payments": {
        "deleteAccountButton2": "hidden",
        "flagAccountButton2": "disabled",
        "secretInfoField2": "enabled"
      }
    }
  }
}
}

{"id":"003","dataType":"getCustomerPermissionsData","mockData":
{
  "permissions": {
    "role": "account-owner",
    "uiElements": {
      "/payments": {
        "deleteAccountButton3": "hidden",
        "flagAccountButton3": "disabled",
        "secretInfoField3": "enabled"
      }
    }
  }
}
}

*/
