var zipCode=context.getVariable("request.queryparam.zipCode");
var areaCode=context.getVariable("request.queryparam.areaCode");
var limit=context.getVariable("request.queryparam.limit");
context.setVariable("dataType","getAreaExchangeCode");
if(zipCode=='98101')
{
  context.setVariable('objectId','001');
}
else if(areaCode=='206')
{
  context.setVariable('objectId','002');
}
else if(zipCode=='98015')
{
  context.setVariable('objectId','003');
}
else if(areaCode=='425' && limit=='1')
{
  context.setVariable('objectId','007');
}
else if(areaCode=='425')
{
  context.setVariable('objectId','004');
}
else if(zipCode=='98073')
{
  context.setVariable('objectId','005');
}
else if(zipCode=='98072')
{
  context.setVariable('objectId','006');
}
else
{
  context.setVariable('objectId','000');
}